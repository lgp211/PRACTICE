package com.contract;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyContractTestingApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyContractTestingApplication.class, args);
    }

}
