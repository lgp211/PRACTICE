package com.service.provider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceProviderApplicationTests {

    @Test
    void contextLoads() {
    }

}
