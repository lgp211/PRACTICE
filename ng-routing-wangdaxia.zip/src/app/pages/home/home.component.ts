import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private router : Router) { }

  ngOnInit(): void {
  }

  jump(){
    //this.router.navigateByUrl("/notfound");
    //this.router.navigate(["/notfound"]);
    this.router.navigate(["/notfound", "lgp"], {
      queryParams: {
        name: "sfdf"
      }
    });
  }

}
