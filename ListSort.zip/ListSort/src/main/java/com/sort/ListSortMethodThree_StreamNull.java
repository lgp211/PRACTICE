package com.sort;

import com.domain.NewPerson;
import com.domain.Person;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ListSortMethodThree_StreamNull {
  public static void main(String[] args) {

    // 创建并初始化 List
    List<NewPerson> list = new ArrayList<NewPerson>() {{
      add(new NewPerson(30, "北京"));
      add(new NewPerson(10, "西安"));
      add(new NewPerson(40, "上海"));
      add(new NewPerson(null, "上海")); // 年龄为 null 值
    }};

    // 使用 Stream 排序
    /*list = list.stream().sorted(Comparator.comparing(Person::getAge).reversed())
      .collect(Collectors.toList());*/
    /*list = list.stream().sorted(Comparator.comparing(NewPerson::getAge, Comparator.nullsLast(Integer::compareTo)))
      .collect(Collectors.toList());*/
    list = list.stream().sorted(Comparator.comparing(NewPerson::getAge, Comparator.nullsFirst(Integer::compareTo)))
      .collect(Collectors.toList());

    // 打印 list 集合
    list.forEach(p -> {
      System.out.println(p);
    });
  }
}
