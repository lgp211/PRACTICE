package com.sort;

import com.domain.Person;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ListSortMethodTwo_ComparatorAnonymous {
  public static void main(String[] args) {

    // 创建并初始化 List
    List<Person> list = new ArrayList<Person>() {{
      add(new Person(1, 30, "北京"));
      add(new Person(2, 20, "西安"));
      add(new Person(3, 40, "上海"));
    }};

    // 使用 Comparator 比较器排序
    Collections.sort(list, new Comparator<Person>(){
      @Override
      public int compare(Person o1, Person o2) {
        return o1.getAge() - o2.getAge();
      }
    });

    // 打印 list 集合
    list.forEach(p -> {
      System.out.println(p);
    });
  }
}
