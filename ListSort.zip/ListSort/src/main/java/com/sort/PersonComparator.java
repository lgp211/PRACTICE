package com.sort;

import com.domain.Person;

import java.util.Comparator;

/**
 * 新建 Person 比较器
 */
class PersonComparator implements Comparator<Person> {
  @Override
  public int compare(Person p1, Person p2) {
    //return p2.getAge() - p1.getAge();
    return p1.getAge() - p2.getAge();
  }
}
