package com.sort;

import com.domain.Person;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ListSortMethodThree_Stream {
  public static void main(String[] args) {

    // 创建并初始化 List
    List<Person> list = new ArrayList<Person>() {{
      add(new Person(1, 30, "北京"));
      add(new Person(2, 20, "西安"));
      add(new Person(3, 40, "上海"));
    }};

    // 使用 Stream 排序
    /*list = list.stream().sorted(Comparator.comparing(Person::getAge).reversed())
      .collect(Collectors.toList());*/
    list = list.stream().sorted(Comparator.comparing(Person::getAge))
      .collect(Collectors.toList());

    // 打印 list 集合
    list.forEach(p -> {
      System.out.println(p);
    });
  }
}
