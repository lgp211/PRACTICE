package com.sort;

import com.domain.Person;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class ListSortMethodOne_Comparable {
  public static void main(String[] args) throws InterruptedException {
    List<Person> list = new ArrayList<Person>() {
      {
        add(new Person(1, 30, "Xianning"));
        add(new Person(2, 20, "Guanxian"));
        add(new Person(2, 40, "Guanxian"));
      }
    };

    Collections.sort(list);

    for (Person person : list) {
      System.out.println(person);
    }

    Integer a1 = 31;
    Integer a2 = 51;
    int result1 = a1.compareTo( a2 );

    System.out.println( result1 );

    String s1 = "spring";
    String s2 = "autumn";
    int result2 = s1.compareTo( s2 );

    System.out.println( result2 );

    Date d1 = new Date();

    Thread.sleep( 1000 );

    Date d2 = new Date();
    int result3 = d1.compareTo( d2 );

    System.out.println( result3 );


  }
}
