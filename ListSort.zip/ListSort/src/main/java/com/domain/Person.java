package com.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Person implements Comparable<Person>{
  private int id;
  private int age;
  private String name;

  @Override
  public int compareTo(Person p) {
    //return p.getAge() - this.getAge();
    return this.getAge() - p.getAge();
  }
}
