package com.example.springbootmongo;

import com.example.springbootmongo.dao.StudentRepository;
import com.example.springbootmongo.model.Address;
import com.example.springbootmongo.model.Gender;
import com.example.springbootmongo.model.Student;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@SpringBootApplication
public class SpringbootmongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootmongoApplication.class, args);
	}

	@Bean
	CommandLineRunner commandLineRunner(StudentRepository studentRepository, MongoTemplate mongoTemplate){
		return args -> {
			Address address = new Address(
					"Singapore",
					"Singapore",
					"130010"
			);

			String email = "lgp211@gmail.com";
			Student student = new Student(
					"Bruce",
					"Lau",
					"lgp211@gmail.com",
					Gender.MALE,
					address,
					List.of(
							"English",
							"Math",
							"IT"
					),
					BigDecimal.TEN,
					LocalDateTime.now()
			);

			//usingMongoTemplateAndQuery(studentRepository, mongoTemplate, email, student);

			studentRepository.findStudentByEmail(email)
					.ifPresentOrElse(s->{
						System.out.println(student + "already exists");
					}, ()->{
						System.out.println("Inserting student: " + student);
						//studentRepository.save(student);
						studentRepository.insert(student);
					});
		};
	}

	private void usingMongoTemplateAndQuery(StudentRepository studentRepository, MongoTemplate mongoTemplate, String email, Student student) {
		Query query = new Query();
		query.addCriteria(Criteria.where("email").is("lgp211@gmail.com"));
		List<Student> students = mongoTemplate.find(query, Student.class);

		try {
			if (students.size() > 0) {
				System.out.println("STUDENT SIZE: " + students.size());
				throw new IllegalStateException("Found existing student with email: " + email);
			}
		}catch(Exception e){
			//e.printStackTrace();
		}

		if(students.isEmpty()) {
			System.out.println("Inserting student: " + student);
			//studentRepository.save(student);
			studentRepository.insert(student);
		}else{
			System.out.println(student + "already exists");
		}
	}
}
