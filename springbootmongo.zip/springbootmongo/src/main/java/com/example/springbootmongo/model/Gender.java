package com.example.springbootmongo.model;

import lombok.AllArgsConstructor;

public enum Gender {
    MALE, FEMALE
}
