import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { envs } from './../env.const';

@Component({
  selector: 'app-env-select',
  templateUrl: './env-select.component.html',
  styleUrls: ['./env-select.component.scss'],
})
export class EnvSelectComponent implements OnInit {
  envs: string[] = envs;

  constructor(private router: Router) {}

  ngOnInit(): void {}

  getCurrentEnv() {
    return this.envs.find((val) => {
      return this.router.url.indexOf(val) > 0;
    });
  }
}
