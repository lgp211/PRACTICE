import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EnvSelectComponent } from './env-select.component';

describe('EnvSelectComponent', () => {
  let component: EnvSelectComponent;
  let fixture: ComponentFixture<EnvSelectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EnvSelectComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EnvSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
