export const env = {
  dev: {
    name: 'dev',
    authPortalUrl: 'https://mfcblobsgisnonprodsea01.z23.web.core.windows.net/',
    apiUrl: 'localhost:8080'
  } as Env,

  sit: {
    name: 'sit',
    authPortalUrl: 'https://mfcblobsgisnonprodsea01.z23.web.core.windows.net/',
    apiUrl: 'siturl'
  } as Env,

  uat: {
    name: 'uat',
    authPortalUrl: 'https://mfcblobsgisnonprodsea01.z23.web.core.windows.net/',
    apiUrl: 'uaturl'
  } as Env
}

export const envs: string[] = [
  env.dev.name,
  env.sit.name,
  env.uat.name
]

export interface Env {
  name: string;
  authPortalUrl: string;
  apiUrl: string;
}
