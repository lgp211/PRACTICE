import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-policy-details',
  templateUrl: './policy-details.component.html',
  styleUrls: ['./policy-details.component.scss']
})
export class PolicyDetailsComponent implements OnInit {
  private _json='';
  @Input()
  set data(json: string) {
    this._json = json;
  }

  get data() {
    return JSON.parse(this._json);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
