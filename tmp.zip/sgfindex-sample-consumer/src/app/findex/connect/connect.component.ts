import { Env } from './../../env.const';
import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-connect',
  templateUrl: './connect.component.html',
  styleUrls: ['./connect.component.scss']
})
export class ConnectComponent implements OnInit {

  @Input()
  env: Env = {} as Env;

  constructor() { }

  ngOnInit(): void {
  }

  connect() {
    window.location.href=this.env.authPortalUrl;
  }

  revoke() {
    console.log('revoke');
  }
}
