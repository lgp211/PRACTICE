import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FindexComponent } from './findex.component';

const routes: Routes = [{ path: '', component: FindexComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FindexRoutingModule { }
