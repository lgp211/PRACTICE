import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { ConnectComponent } from './connect/connect.component';
import { FindexRoutingModule } from './findex-routing.module';
import { FindexComponent } from './findex.component';
import { PolicyDetailsComponent } from './policy-details/policy-details.component';

@NgModule({
  declarations: [FindexComponent, PolicyDetailsComponent, ConnectComponent],
  imports: [
    CommonModule,
    FindexRoutingModule,
    MatButtonModule,
    MatDividerModule,
    MatExpansionModule,
    MatInputModule,
    MatIconModule
  ],
})
export class FindexModule {}
