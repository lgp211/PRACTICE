import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AuthorizationService } from './../authorization.service';
import { Env } from './../env.const';

@Component({
  selector: 'app-findex',
  templateUrl: './findex.component.html',
  styleUrls: ['./findex.component.scss'],
})
export class FindexComponent implements OnInit, OnDestroy {
  json: string =
    '{ "timestamp": "2020-05-13T09:49:47.602Z", "fispName": "ABC Insurance Pte Ltd", "fisp": "I230D", "respCode": "0000", "respMessage": "The request fields have missing mandatory or contain invalid parameters.", "asOfMonthEndDate": "2021-07-31", "policies": [ { "productClass": "Participating", "productType": "WholeLife", "policyNo": "12345678", "surrenderValue": "550000.00", "surrenderValuedate": "2021-07-31", "nav": "40000.00", "navDate": "2021-07-25", "policyMaturityDate": "2105-10-31", "policyHolder": "123HU 321KU", "jointPolicyHolder": "NA", "lifeInsured": [ "XYZ XYZ XYZ", "LMN LMN LMN" ], "jointLifeInsured": [ "NA" ], "secondaryLifeInsured": [ "GIJK GIJK", "PQRST", "PQRVT" ], "beneficaryIndicator": "YES", "payer": [ "JHTK45", "FRTYR33", "MNW29" ], "exclusionIndicator": "NO", "premiumModeFrequency": "Monthly", "nextPremiumDueDate": "2021-10-31", "nextPremiumAmount": "5000.00", "totalPremiumPaid": "25000.00", "totalAccumulatedIncomeAmount": [ "NA" ], "guaranteedValueAtMaturity": "500000.00", "fundsIndicator": "Yes", "payoutIndicator": "Yes", "plans": [ { "planType": "Basic", "productName": "SG Easy Protect", "currencyType": "SGD", "sumInsured": "300000.00", "deathSumInsured": "30000.00", "tpdSumInsured": "NA", "ciSumInsured": "NA", "accidentalDeathSumInsured": "NA", "coverageEffectiveDate": "2021-05-22", "coverageExpiryDate": "2105-10-31", "coveragePremiumAmount": "2000", "premiumPaymentTerm": "20", "paymentMethod": [ "Autopay(Giro)" ], "hospitalBenefits": { "roomBoardPerDay": "NA", "maxLimitPerYear": "NA", "maxLimitPerLife": "NA", "wardEntitlement": "NA" }, "payouts": [ { "dateFirstIncomePayout": "2021-07-20", "dateLastIncomePayout": "2021-07-20", "lastIncomePayoutAmount": "45777.00", "payoutFrequency": "Quarterly", "payoutReinvest": "Yes" }, { "dateFirstIncomePayout": "2020-07-20", "dateLastIncomePayout": "2020-07-20", "lastIncomePayoutAmount": "25000", "payoutFrequency": "Annual", "payoutReinvest": "No" } ] }, { "planType": "Rider", "productName": "SG Easy Protect Critical", "currencyType": "SGD", "sumInsured": "20000.00", "deathSuminsured": "NA", "tpdSumInsured": "NA", "ciSumInsured": "20000.00", "accidentalDeathSumInsured": "NA", "coverageEffectiveDate": "2021-05-22", "coverageExpiryDate": "2105-10-31", "coveragePremiumAmount": "2000.00", "premiumPaymentTerm": "20", "paymentMethod": [ "Autopay(Giro)" ], "hospitalBenefits": { "roomBoardPerDay": "100", "maxLimitPerYear": "2000", "maxLimitPerLife": "25000", "wardEntitlement": "NA" }, "payouts": [ { "dateFirstIncomePayout": "2021-07-20", "dateLastIncomePayout": "2021-07-20", "lastIncomePayoutAmount": "45777.00", "payoutFrequency": "Quarterly", "payoutReinvest": "Yes" } ] }, { "planType": "Rider", "productName": "SG Easy Protect Disability", "currencyType": "SGD", "sumInsured": "10000.00", "deathSumInsured": "NA", "tpdSumInsured": "10000.00", "ciSumInsured": "NA", "accidentalDeathSumInsured": "NA", "coverageEffectiveDate": "2021-05-22", "coverageExpiryDate": "2105-10-31", "coveragePremiumAmount": "2000.00", "premiumPaymentTerm": "20", "paymentMethod": [ "Autopay(Giro)" ], "hospitalBenefits": { "roomBoardPerDay": "NA", "maxLimitPerYear": "NA", "maxLimitPerLife": "NA", "wardEntitlement": "NA" }, "payouts": [ { "dateFirstIncomePayout": "NA", "dateLastIncomePayout": "NA", "lastIncomePayoutAmount": "NA", "payoutFrequency": "NA", "payoutReinvest": "NA" } ] } ], "funds": [ { "fundName": "SDRT :ASEAN FUND", "fundCurrency": "SGD", "fundCashvalue": "45777.00", "fundLastPricedDate": "2021-07-22" }, { "fundName": "DSRT : sg smart", "fundCurrency": "SGD", "fundCashValue": "5677.00", "fundLastPricedDate": "2021-07-20" } ] } ]}';
  connected: boolean = this.authorizationService.connected;
  env: Env = {} as Env;

  constructor(
    private route: ActivatedRoute,
    protected authorizationService: AuthorizationService
  ) {}

  ngOnInit(): void {
    this.route.data.subscribe((data) => {
      this.env = data.env;
    });
  }

  ngOnDestroy(): void {}
}
