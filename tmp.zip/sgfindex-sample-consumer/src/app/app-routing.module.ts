import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { env } from './env.const';

const routes: Routes = [
  {
    path: env.dev.name,
    loadChildren: () =>
      import('./findex/findex.module').then((m) => m.FindexModule),
    data: { env: env.dev },
  },
  {
    path: env.sit.name,
    loadChildren: () =>
      import('./findex/findex.module').then((m) => m.FindexModule),
    data: { env: env.sit },
  },
  {
    path: env.uat.name,
    loadChildren: () =>
      import('./findex/findex.module').then((m) => m.FindexModule),
    data: { env: env.uat },
  },
  { path: '**', redirectTo: env.dev.name },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
