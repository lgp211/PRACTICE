package com.graphql.bank.domain;

public enum Currency {
  CHF,
  USD
}
