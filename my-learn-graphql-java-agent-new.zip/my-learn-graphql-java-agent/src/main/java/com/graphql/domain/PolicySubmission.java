package com.graphql.domain;

import lombok.Builder;
import lombok.Value;

@Builder
@Value
public class PolicySubmission {
    String date;
    PolicySubmissionType type;
}
