package com.graphql.domain;

import lombok.Builder;
import lombok.Value;

@Builder
@Value
public class PolicyStatus {
    String code;
    String description;
}
