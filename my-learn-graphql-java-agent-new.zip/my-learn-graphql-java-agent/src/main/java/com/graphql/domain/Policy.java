package com.graphql.domain;

import lombok.Builder;
import lombok.Value;

@Builder
@Value
public class Policy {
    String policyNumber;
    PolicyStatus status;
    PolicyCurrency currency;
    String effectiveDate;
    String terminationDate;
    String sliActivationDate;
    PolicySubmission submission;
    String paidToDate;
    String lastAnniversaryDate;
}
