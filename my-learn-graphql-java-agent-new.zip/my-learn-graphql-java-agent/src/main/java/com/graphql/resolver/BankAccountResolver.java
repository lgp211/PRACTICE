package com.graphql.resolver;

import com.graphql.agent.domain.Agent;
import com.graphql.agent.domain.AgentName;
import com.graphql.bank.domain.BankAccount;
import com.graphql.bank.domain.Currency;
import com.graphql.domain.*;
import graphql.kickstart.tools.GraphQLQueryResolver;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Slf4j
@Component
public class BankAccountResolver implements GraphQLQueryResolver {
    /*public BankAccount bankAccount(UUID id){
        log.info("Retrievning data for this ID: {}", id);

        return BankAccount.builder().id(id).currency(Currency.USD).name("Gongping").build();
    }*/

    public Agent agentById(String id){
        log.info("Retrievning Agent INFO for this agent: {}", id);
        return Agent.builder().agentCode(id).name(AgentName.builder().fullName("Gongping").build()).build();
    }

    public Policy policyById(String policyNumber){
        log.info("Retrievning Policy INFO for this agent: {}", policyNumber);
        return Policy.builder()
                .policyNumber(policyNumber)
                .status(PolicyStatus.builder().code("code").description("good").build())
                .currency(PolicyCurrency.builder().code("SGD").description("Singapore Dollar").build())
                .effectiveDate("Jan 1, 2001")
                .terminationDate("Feb 11, 1991")
                .sliActivationDate("Oct 8, 2021")
                .submission(
                        PolicySubmission.builder()
                                .date("Oct 8, 2021")
                                .type(
                                        PolicySubmissionType.builder()
                                                .code("NNN")
                                                .description("SubmissionType")
                                                .build()
                                )
                                .build()
                )
                .paidToDate("Oct 8, 2021")
                .lastAnniversaryDate("Oct 8, 2021")
                .build();
    }

    public Policy policies(String[] policyNumbers){
        log.info("Retrievning Policy INFO for this agent: {}", policyNumbers);
        return Policy.builder()
                .policyNumber(policyNumbers[0])
                .status(PolicyStatus.builder().code("code").description("good").build())
                .currency(PolicyCurrency.builder().code("SGD").description("Singapore Dollar").build())
                .effectiveDate("Jan 1, 2001")
                .terminationDate("Feb 11, 1991")
                .sliActivationDate("Oct 8, 2021")
                .submission(
                        PolicySubmission.builder()
                                .date("Oct 8, 2021")
                                .type(
                                        PolicySubmissionType.builder()
                                                .code("NNN")
                                                .description("SubmissionType")
                                                .build()
                                )
                                .build()
                )
                .paidToDate("Oct 8, 2021")
                .lastAnniversaryDate("Oct 8, 2021")
                .build();
    }
}
