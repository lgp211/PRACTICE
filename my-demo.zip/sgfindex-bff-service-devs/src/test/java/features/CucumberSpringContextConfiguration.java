package features;

import com.manulife.ap.Application;
import com.manulife.ap.testutil.TestSuite;
import io.cucumber.java.Before;
import io.cucumber.spring.CucumberContextConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

/**
 * Class to use Spring application context while running cucumber
 */
@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = Application.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("cucumber")
@CucumberContextConfiguration
@Slf4j
@Tag(TestSuite.ACCEPTANCE_TEST)
public class CucumberSpringContextConfiguration {

  @Before
  public void setup() {
    log.info("-------------- Spring Context Initialized For Executing Cucumber Tests --------------");
  }
}