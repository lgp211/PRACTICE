package features;

import com.manulife.ap.common.mapper.LocalDateMapping;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.math.NumberUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@NoArgsConstructor
@Slf4j
public class CucumberTestClass {

  /**
   * ISO Date format: YYYY-MM-dd
   *
   * @param isoDateInString date in ISO format
   * @return {@link LocalDate} instance if date if parsable; otherwise null.
   */
  public LocalDate getLocalDate(final String isoDateInString) {
    try {
      return LocalDate.parse(Objects.toString(isoDateInString, ""));
    } catch (DateTimeParseException e) {
      log.error("DateTimeParseException: {}", e.getMessage());
      return null;
    }
  }

  /**
   * ISO Date Time format: YYYY-MM-dd HH:mm:ss
   *
   * @param isoDateTimeInString date in ISO format
   * @return {@link LocalDateTime} instance if date if parsable; otherwise null.
   */
  public LocalDateTime getLocalDateTime(final String isoDateTimeInString) {
    try {
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
      return LocalDateTime.parse(Objects.toString(isoDateTimeInString, ""), formatter);
    } catch (DateTimeParseException e) {
      log.error("DateTimeParseException: {}", e.getMessage());
      return null;
    }
  }

  /**
   * Return true if given boolean in string in any of following:
   * 1. Y or y
   * 2. True (case insensitive)
   * 3. T or t
   *
   * @param booleanInString boolean in string
   * @return <code>true</code> if match any string of above; otherwise <code>false</code>.
   */
  public boolean getBoolean(final String booleanInString) {
    return Stream.of("Y", "True", "T")
      .anyMatch(matchingBoolean -> Objects.toString(booleanInString, "").equals(matchingBoolean.toUpperCase()));
  }

  /**
   * Return double if Sting value provided:
   * If provided Sting is not null or empty then return parsed double value
   * If provided Sting is null or empty return 0.0d
   *
   * @param doubleInString double in sting
   * @return double
   */
  public double getDouble(final String doubleInString) {
    return NumberUtils.toDouble(doubleInString);
  }

  /**
   * Return double if Sting value provided:
   * If provided Sting is not null or empty then return parsed double value
   * If provided Sting is null or empty return 0.0d
   *
   * @param doubleInString double in sting
   * @return Double
   */
  public Double getDoubleObj(final String doubleInString) {
    return NumberUtils.toDouble(doubleInString);
  }

  /**
   * Return Integer if Sting value provided:
   * If provided Sting is not null or empty then return parsed Integer value
   * If provided Sting is null or empty return 0
   *
   * @param integerInString integer in sting
   * @return Integer
   */
  public Integer getIntegerObj(final String integerInString) {
    return NumberUtils.toInt(integerInString);
  }

  public List<LocalDate> toLocalDateList(final List<String> stringDateList) {
    return stringDateList.stream()
        .map(s -> getLocalDate(s))
        .collect(Collectors.toList());
  }
}
