package features.stepdefs.policy.details;

import com.manulife.ap.core.policy.PolicyManager;
import com.manulife.ap.core.policy.PolicyRepository;
import com.manulife.ap.core.policy.PolicyService;
import com.manulife.ap.core.policy.domain.PolicyAggregate;
import com.manulife.ap.core.policy.domain.PolicyDetails;
import com.manulife.ap.external.api.policy.InMemoryPolicyRepository;
import features.CucumberTestClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@Slf4j
public class ModelPolicyDetails extends CucumberTestClass {

    private PolicyService policyService;

    private PolicyRepository policyRepository;

    private List<PolicyAggregate> policyAggregateList;
    private String errorResponseMessage;

    @BeforeEach
    public void setup(){
        //this.policyRepository = new InMemoryPolicyRepository();
        //this.policyService = new PolicyManager(policyRepository);
    }

    @Given("following policy details exist policy api service")
    public void following_policy_details_exist_policy_api_service(io.cucumber.datatable.DataTable dataTable) {
        //policyService = new PolicyManager(policyRepository);
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        List<PolicyDetails> policyDetailsList =
                rows.stream()
                        .map(row ->
                                PolicyDetails.builder()
                                        .policyNumber(row.get("Policy Number"))
                                        .productClass(row.get("Product Class"))
                                        .productType(row.get("Product Type"))
                                        .surrenderValue(row.get("Surrender Value"))
                                        .surrenderValueDate(this.getLocalDate(row.get("Surrender Value Date")))
                                        .nav(row.get("Nav"))
                                        .navDate(this.getLocalDate(row.get("Nav Date")))
                                        .policyMaturityDate(this.getLocalDate(row.get("Policy Maturity Date")))
                                        .policyHolder(row.get("Policy Holder"))
                                        .jointPolicyHolder(row.get("Joint Policy Holder"))
                                        .lifeInsured(Arrays.asList(row.get("Life Insured").split(",").clone()))
                                        .jointLifeInsured(Arrays.asList(row.get("Joint Life Insured").split(",").clone()))
                                        .secondaryLifeInsured(Arrays.asList(row.get("Secondary Life Insured").split(",").clone()))
                                        .beneficiary(row.get("Beneficiary"))
                                        .payer(Arrays.asList(row.get("Payer").split(",").clone()))
                                        .exclusion(row.get("Exclusion"))
                                        .premiumModeFrequency(row.get("Premium Mode Frequency"))
                                        .nextPremiumDueDate(this.getLocalDate(row.get("Next Premium Due Date")))
                                        .nextPremiumAmount(row.get("Next Premium Amount"))
                                        .totalPremiumPaid(row.get("Total Premium Paid"))
                                        .dateFirstIncomePayout(this.toLocalDateList(Arrays.asList(row.get("Date First Income Payout").split(",").clone())))
                                        .dateLastIncomePayout(this.toLocalDateList(Arrays.asList(row.get("Date Last Income Payout").split(",").clone())))
                                        .lastIncomePayoutAmount(Arrays.asList(row.get("Last Income Payout Amount").split(",").clone()))
                                        .totalAccumulatedIncomeAmount(Arrays.asList(row.get("Total Accumulated Income Amount").split(",").clone()))
                                        .payoutFrequency(Arrays.asList(row.get("Payout Frequency").split(",").clone()))
                                        .payoutReinvest(Arrays.asList(row.get("Payout Reinvest").split(",").clone()))
                                        .guaranteedValueAtMaturity(row.get("Guaranteed Value At Maturity"))
                                        .fundsIndicator(row.get("Funds Indicator"))
                                        .build()
                        )
                        .collect(Collectors.toList());


        policyRepository = new InMemoryPolicyRepository().addAll(policyDetailsList);
        policyService = new PolicyManager(policyRepository);
        //((InMemoryPolicyRepository) this.policyRepository).addAll(policyDetailsList);
        log.info("PolicyDetailsList: {}", policyDetailsList);
    }

    @When("I get policy details using policy number {string}")
    public void i_get_policy_details_using_policy_number(String policyNumber) {
        try {
            policyAggregateList = policyService.getPolicies(Arrays.asList(policyNumber));
            System.out.println("++++++++++++++++++++++: " + policyAggregateList);
        } catch (Exception ex) {
            errorResponseMessage = ex.getMessage();
            System.out.println("--------------------: " + errorResponseMessage);
        }
    }

    @Then("I should receive a response message {string}")
    public void i_should_receive_a_response_message(String expectedErrorMessage) {
        //assertTrue(errorResponseMessage.contains(expectedErrorMessage));
        assertNull(policyAggregateList);
    }

    @Then("I should receive a response object")
    public void i_should_receive_a_response_object(io.cucumber.datatable.DataTable dataTable) {
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        List<PolicyDetails> expectedPolicyDetailsList =
                rows.stream()
                        .map(row ->
                                PolicyDetails.builder()
                                        .policyNumber(row.get("Policy Number"))
                                        .productClass(row.get("Product Class"))
                                        .productType(row.get("Product Type"))
                                        .surrenderValue(row.get("Surrender Value"))
                                        .surrenderValueDate(this.getLocalDate(row.get("Surrender Value Date")))
                                        .nav(row.get("Nav"))
                                        .navDate(this.getLocalDate(row.get("Nav Date")))
                                        .policyMaturityDate(this.getLocalDate(row.get("Policy Maturity Date")))
                                        .policyHolder(row.get("Policy Holder"))
                                        .jointPolicyHolder(row.get("Joint Policy Holder"))
                                        .lifeInsured(Arrays.asList(row.get("Life Insured").split(",").clone()))
                                        .jointLifeInsured(Arrays.asList(row.get("Joint Life Insured").split(",").clone()))
                                        .secondaryLifeInsured(Arrays.asList(row.get("Secondary Life Insured").split(",").clone()))
                                        .beneficiary(row.get("Beneficiary"))
                                        .payer(Arrays.asList(row.get("Payer").split(",").clone()))
                                        .exclusion(row.get("Exclusion"))
                                        .premiumModeFrequency(row.get("Premium Mode Frequency"))
                                        .nextPremiumDueDate(this.getLocalDate(row.get("Next Premium Due Date")))
                                        .nextPremiumAmount(row.get("Next Premium Amount"))
                                        .totalPremiumPaid(row.get("Total Premium Paid"))
                                        .dateFirstIncomePayout((row.get("Date First Income Payout") == null) ? null : this.toLocalDateList(Arrays.asList(row.get("Date First Income Payout").split(",").clone())))
                                        .dateLastIncomePayout((row.get("Date Last Income Payout") == null) ? null : this.toLocalDateList(Arrays.asList(row.get("Date Last Income Payout").split(",").clone())))
                                        .lastIncomePayoutAmount(Arrays.asList(row.get("Last Income Payout Amount").split(",").clone()))
                                        .totalAccumulatedIncomeAmount((row.get("Total Accumulated Income Amount") == null) ? null : Arrays.asList(row.get("Total Accumulated Income Amount").split(",").clone()))
                                        .payoutFrequency((row.get("Payout Frequency") == null) ? null : Arrays.asList(row.get("Payout Frequency").split(",").clone()))
                                        .payoutReinvest((row.get("Payout Reinvest") == null) ? null : Arrays.asList(row.get("Payout Reinvest").split(",").clone()))
                                        .guaranteedValueAtMaturity(row.get("Guaranteed Value At Maturity"))
                                        .fundsIndicator(row.get("Funds Indicator"))
                                        .build()
                        )
                        .collect(Collectors.toList());

        policyAggregateList.forEach(policyAggregate -> {
            PolicyDetails actualPolicyDetails = policyAggregate.getPolicy();
            PolicyDetails expectedPolicyDetails = expectedPolicyDetailsList.stream()
                    .filter(policyDetails -> policyDetails.getPolicyNumber().equalsIgnoreCase(actualPolicyDetails.getPolicyNumber()))
                    .findAny()
                    .orElse(null);

            assertEquals(expectedPolicyDetails.getPolicyNumber(), actualPolicyDetails.getPolicyNumber());
            assertEquals(expectedPolicyDetails.getProductClass(), actualPolicyDetails.getProductClass());
            assertEquals(expectedPolicyDetails.getProductType(), actualPolicyDetails.getProductType());
            assertEquals(expectedPolicyDetails.getSurrenderValue(), actualPolicyDetails.getSurrenderValue());
            assertEquals(expectedPolicyDetails.getSurrenderValueDate(), actualPolicyDetails.getSurrenderValueDate());
            assertEquals(expectedPolicyDetails.getNav(), actualPolicyDetails.getNav());
            assertEquals(expectedPolicyDetails.getNavDate(), actualPolicyDetails.getNavDate());
            assertEquals(expectedPolicyDetails.getPolicyMaturityDate(), actualPolicyDetails.getPolicyMaturityDate());
            assertEquals(expectedPolicyDetails.getPolicyHolder(), actualPolicyDetails.getPolicyHolder());
            assertEquals(expectedPolicyDetails.getJointPolicyHolder(), actualPolicyDetails.getJointPolicyHolder());
            assertEquals(expectedPolicyDetails.getLifeInsured(), actualPolicyDetails.getLifeInsured());
            assertEquals(expectedPolicyDetails.getJointLifeInsured(), actualPolicyDetails.getJointLifeInsured());
            assertEquals(expectedPolicyDetails.getSecondaryLifeInsured(), actualPolicyDetails.getSecondaryLifeInsured());
            assertEquals(expectedPolicyDetails.getBeneficiary(), actualPolicyDetails.getBeneficiary());
            assertEquals(expectedPolicyDetails.getPayer(), actualPolicyDetails.getPayer());
            assertEquals(expectedPolicyDetails.getExclusion(), actualPolicyDetails.getExclusion());
            assertEquals(expectedPolicyDetails.getPremiumModeFrequency(), actualPolicyDetails.getPremiumModeFrequency());
            assertEquals(expectedPolicyDetails.getNextPremiumDueDate(), actualPolicyDetails.getNextPremiumDueDate());
            assertEquals(expectedPolicyDetails.getNextPremiumAmount(), actualPolicyDetails.getNextPremiumAmount());
            assertEquals(expectedPolicyDetails.getTotalPremiumPaid(), actualPolicyDetails.getTotalPremiumPaid());
            assertEquals(expectedPolicyDetails.getDateFirstIncomePayout(), actualPolicyDetails.getDateFirstIncomePayout());
            assertEquals(expectedPolicyDetails.getDateLastIncomePayout(), actualPolicyDetails.getDateLastIncomePayout());
            assertEquals(expectedPolicyDetails.getTotalAccumulatedIncomeAmount(), actualPolicyDetails.getTotalAccumulatedIncomeAmount());
            assertEquals(expectedPolicyDetails.getPayoutFrequency(), actualPolicyDetails.getPayoutFrequency());
            assertEquals(expectedPolicyDetails.getPayoutReinvest(), actualPolicyDetails.getPayoutReinvest());
            assertEquals(expectedPolicyDetails.getGuaranteedValueAtMaturity(), actualPolicyDetails.getGuaranteedValueAtMaturity());
            assertEquals(expectedPolicyDetails.getFundsIndicator(), actualPolicyDetails.getFundsIndicator());
        });
    }
}
