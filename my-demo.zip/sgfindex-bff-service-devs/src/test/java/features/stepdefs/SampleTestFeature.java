package features.stepdefs;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SampleTestFeature {

  @Given("test given feature")
  public void test_given_feature(io.cucumber.datatable.DataTable dataTable) {
    // Write code here that turns the phrase above into concrete actions
    // For automatic transformation, change DataTable to one of
    // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
    // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
    // Double, Byte, Short, Long, BigInteger or BigDecimal.
    //
    // For other transformations you can register a DataTableType.
//    throw new io.cucumber.java.PendingException();
  }

  @When("test when scenario")
  public void test_when_scenario() {
    // Write code here that turns the phrase above into concrete actions
//    throw new io.cucumber.java.PendingException();
  }

  @Then("test param {int} with {string}")
  public void test_param_with(Integer int1, String string) {
    // Write code here that turns the phrase above into concrete actions
//    throw new io.cucumber.java.PendingException();
  }


}
