package com.manulife.ap.ui.delegate;

import com.manulife.ap.common.mapper.LocalDateMapping;
import com.manulife.ap.core.policy.PolicyManager;
import com.manulife.ap.core.policy.domain.PolicyAggregate;
import com.manulife.ap.core.policy.domain.PolicyDetails;
import com.manulife.ap.swagger.model.ConsumerResponse;
import com.manulife.ap.testutil.TestSuite;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyList;

@DisplayName("Unit Test - Findex Api Delegate Impl")
@ExtendWith(MockitoExtension.class)
class FindexApiDelegateImplTest {
    private FindexApiDelegateImpl findexApiDelegate;

    @Mock
    private PolicyManager policyManager;

    @BeforeEach
    void setup() {
        this.findexApiDelegate = new FindexApiDelegateImpl(policyManager);
    }

    @Test
    @Tag(TestSuite.UNIT_TEST)
    @DisplayName("Should return instance not null")
    void shouldReturnNonNullObject() {
        assertNotNull(this.findexApiDelegate);
    }

    @Test
    @Tag(TestSuite.UNIT_TEST)
    @DisplayName("Class should be annotated as Spring Component")
    void classShouldBeAnnotatedAsEmbeddable() {
        // When
        Component component = FindexApiDelegateImpl.class.getAnnotation(Component.class);
        // Then
        assertNotNull(component);
    }

    @Nested
    @DisplayName("Test Get Policy Details Method")
    class TestGetPolicyDetailsMethod {

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should return consumer response")
        void shouldReturnConsumerResponse() {
            // Given
            String consumer = "randomconsumer";

            Mockito.when(policyManager.getPolicies(anyList()))
                    .thenReturn(Arrays.asList(
                            PolicyAggregate.builder()
                                    .policy(PolicyDetails.builder()
                                            .policyNumber("1234567890")
                                            .productClass("Participating")
                                            .productType("WholeLife")
                                            .surrenderValue("550000.00")
                                            .surrenderValueDate(LocalDateMapping.stringToLocalDate("2021-07-31"))
                                            .nav("40000.00")
                                            .navDate(LocalDateMapping.stringToLocalDate("2021-07-25"))
                                            .policyMaturityDate(LocalDateMapping.stringToLocalDate("2105-10-31"))
                                            .policyHolder("123HU 321KU")
                                            .jointPolicyHolder("NA")
                                            .lifeInsured(Arrays.asList(
                                                    "XYZ XYZ XYZ",
                                                    "LMN LMN LMN"
                                            ))
                                            .jointLifeInsured(Arrays.asList(
                                                    "NA"
                                            ))
                                            .secondaryLifeInsured(Arrays.asList(
                                                    "GIJK GIJK",
                                                    "PQRST",
                                                    "PQRVT"
                                            ))
                                            .beneficiary("YES")
                                            .payer(Arrays.asList(
                                                    "JHTK45",
                                                    "FRTYR33",
                                                    "MNW29"
                                            ))
                                            .exclusion("NO")
                                            .premiumModeFrequency("Monthly")
                                            .nextPremiumDueDate(LocalDateMapping.stringToLocalDate("2021-10-31"))
                                            .nextPremiumAmount("5000.00")
                                            .totalPremiumPaid("25000.00")
                                            .dateFirstIncomePayout(Arrays.asList(
                                                    LocalDateMapping.stringToLocalDate("2021-10-31"),
                                                    LocalDateMapping.stringToLocalDate("2025-10-31")
                                            ))
                                            .dateLastIncomePayout(Arrays.asList(
                                                    LocalDateMapping.stringToLocalDate("2021-10-31"),
                                                    LocalDateMapping.stringToLocalDate("2022-10-31")
                                            ))
                                            .lastIncomePayoutAmount(Arrays.asList(
                                                    "NA"
                                            ))
                                            .totalAccumulatedIncomeAmount(Arrays.asList(
                                                    "NA"
                                            ))
                                            .payoutFrequency(Arrays.asList(
                                                    "Annually",
                                                    "Quarterly"
                                            ))
                                            .payoutReinvest(Arrays.asList(
                                                    "Yes",
                                                    "No"
                                            ))
                                            .guaranteedValueAtMaturity("500000.00")
                                            .fundsIndicator("Yes")
                                            .build())
                                    .build()
                    ));

            // When
            ResponseEntity<ConsumerResponse> consumerResponse = findexApiDelegate.getPolicyDetails(consumer, "", "", "", "");

            // Then
            assertNotNull(consumerResponse);
            assertEquals(HttpStatus.OK, consumerResponse.getStatusCode());
            assertNotNull(consumerResponse.getBody());
        }
    }
}
