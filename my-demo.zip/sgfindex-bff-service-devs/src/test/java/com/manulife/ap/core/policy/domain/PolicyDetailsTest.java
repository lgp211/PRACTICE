package com.manulife.ap.core.policy.domain;

import com.manulife.ap.common.mapper.LocalDateMapping;
import com.manulife.ap.testutil.TestSuite;
import contracts.ContractBaseTestClass;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@DisplayName("Unit Test - Policy Details")
class PolicyDetailsTest extends ContractBaseTestClass {

    @Test
    @Tag(TestSuite.UNIT_TEST)
    @DisplayName("Should return non-null object for default constructor")
    void shouldReturnNonNullObjectForDefaultConstructor() {
        //When
        PolicyDetails policyDetails = new PolicyDetails();
        //Then
        assertNotNull(policyDetails);
    }

    @Test
    @Tag(TestSuite.UNIT_TEST)
    @DisplayName("Should return non-null object for builder constructor")
    void shouldAbleToBuild() {
        //When
        PolicyDetails policyDetails = PolicyDetails.builder().build();
        //Then
        assertNotNull(policyDetails);
    }

    @Test
    @Tag(TestSuite.UNIT_TEST)
    @DisplayName("Should return fields with getter")
    void shouldReturnFieldsWithGetter() {
        //When
        PolicyDetails policyDetails =
                PolicyDetails.builder()
                        .policyNumber("1234567890")
                        .productClass("Participating")
                        .productType("WholeLife")
                        .surrenderValue("550000.00")
                        .surrenderValueDate(LocalDateMapping.stringToLocalDate("2021-07-31"))
                        .nav("40000.00")
                        .navDate(LocalDateMapping.stringToLocalDate("2021-07-25"))
                        .policyMaturityDate(LocalDateMapping.stringToLocalDate("2105-10-31"))
                        .policyHolder("123HU 321KU")
                        .jointPolicyHolder("NA")
                        .lifeInsured(Arrays.asList(
                                "XYZ XYZ XYZ",
                                "LMN LMN LMN"
                        ))
                        .jointLifeInsured(Arrays.asList(
                                "NA"
                        ))
                        .secondaryLifeInsured(Arrays.asList(
                                "GIJK GIJK",
                                "PQRST",
                                "PQRVT"
                        ))
                        .beneficiary("YES")
                        .payer(Arrays.asList(
                                "JHTK45",
                                "FRTYR33",
                                "MNW29"
                        ))
                        .exclusion("NO")
                        .premiumModeFrequency("Monthly")
                        .nextPremiumDueDate(LocalDateMapping.stringToLocalDate("2021-10-31"))
                        .nextPremiumAmount("5000.00")
                        .totalPremiumPaid("25000.00")
                        .dateFirstIncomePayout(Arrays.asList(
                                LocalDateMapping.stringToLocalDate("2021-10-31"),
                                LocalDateMapping.stringToLocalDate("2025-10-31")
                        ))
                        .dateLastIncomePayout(Arrays.asList(
                                LocalDateMapping.stringToLocalDate("2021-10-31"),
                                LocalDateMapping.stringToLocalDate("2022-10-31")
                        ))
                        .lastIncomePayoutAmount(Arrays.asList(
                                "NA"
                        ))
                        .totalAccumulatedIncomeAmount(Arrays.asList(
                                "NA"
                        ))
                        .payoutFrequency(Arrays.asList(
                                "Annually",
                                "Quarterly"
                        ))
                        .payoutReinvest(Arrays.asList(
                                "Yes",
                                "No"
                        ))
                        .guaranteedValueAtMaturity("500000.00")
                        .fundsIndicator("Yes")
                        .build();

        //Then
        assertAll(
                () -> assertEquals("1234567890", policyDetails.getPolicyNumber()),
                () -> assertEquals("Participating", policyDetails.getProductClass()),
                () -> assertEquals("WholeLife", policyDetails.getProductType())
        );
    }
}
