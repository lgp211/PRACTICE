package com.manulife.ap.testutil;

import org.apache.commons.io.IOUtils;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class ResourceFileReader {
  public static String read(final String location) throws IOException {
    return IOUtils.toString(new ClassPathResource(location).getInputStream(), StandardCharsets.UTF_8);
  }
}
