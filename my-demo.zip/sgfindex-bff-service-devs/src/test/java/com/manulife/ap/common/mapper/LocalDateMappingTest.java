package com.manulife.ap.common.mapper;

import com.manulife.ap.testutil.TestSuite;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Unit Test - LocalDateMapping")
class LocalDateMappingTest {

  @Nested
  @DisplayName("Test Method - stringToLocalDate")
  class TestStringToLocalDate {

    @ParameterizedTest
    @Tag(TestSuite.UNIT_TEST)
    @NullAndEmptySource
    @DisplayName("Should return null when date in string is invalid")
    void shouldReturnNullWhenDateInStringIsNullOrEmpty(String dateString) {
      // When
      LocalDate localDate = LocalDateMapping.stringToLocalDate(dateString);

      // Then
      assertNull(localDate);
    }

    @ParameterizedTest
    @Tag(TestSuite.UNIT_TEST)
    @ValueSource(strings = {"12:30:00", "01/02/2020", "2020-01", "2020-13-01", "2020/01/31"})
    @DisplayName("Should return null when date in string is invalid")
    void shouldReturnNullWhenDateInStringIsInvalid(String dateString) {
      // When
      LocalDate localDate = LocalDateMapping.stringToLocalDate(dateString);

      // Then
      assertNull(localDate);
    }

    @ParameterizedTest
    @Tag(TestSuite.UNIT_TEST)
    @ValueSource(strings = {"2020-01-01", "2020-02-29", "2020-02-29 00:00:00", "2021-07-31", "2105-10-31"})
    @DisplayName("Should return non-null date object when date in string is valid ISO local date format")
    void shouldReturnNonNullDateObjectWhenDateInStringIsValidIsoLocalDateFormat(String dateString) {
      // When
      LocalDate localDate = LocalDateMapping.stringToLocalDate(dateString);

      // Then
      assertNotNull(localDate);
    }
  }
}
