package com.manulife.ap.core.policy.domain;

import com.manulife.ap.testutil.TestSuite;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@DisplayName("Unit Test - Policy Aggregate")
class PolicyAggregateTest {

    @Test
    @Tag(TestSuite.UNIT_TEST)
    @DisplayName("Should return non-null object for default constructor")
    void shouldReturnNonNullObjectForDefaultConstructor() {
        //When
        PolicyAggregate policyAggregate = new PolicyAggregate();
        //Then
        assertNotNull(policyAggregate);
    }

    @Test
    @Tag(TestSuite.UNIT_TEST)
    @DisplayName("Should return non-null object for builder constructor")
    void shouldReturnNonNullObjectForBuilderConstructor() {
        //When
        PolicyAggregate policyAggregate = PolicyAggregate.builder().build();
        //Then
        assertNotNull(policyAggregate);
    }

    @Test
    @Tag(TestSuite.UNIT_TEST)
    @DisplayName("Should return fields with getter")
    void shouldReturnFieldsWithGetter() {
        //When
        PolicyAggregate policyAggregate =
                PolicyAggregate.builder()
                        .policy(PolicyDetails.builder()
                                .build())
                        .build();
        //Then
        assertNotNull(policyAggregate.getPolicy());
    }
}
