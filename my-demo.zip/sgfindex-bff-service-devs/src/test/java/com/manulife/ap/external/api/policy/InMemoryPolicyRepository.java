package com.manulife.ap.external.api.policy;

import com.manulife.ap.common.mapper.LocalDateMapping;
import com.manulife.ap.core.policy.PolicyRepository;
import com.manulife.ap.core.policy.domain.PolicyDetails;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * Initial PolicyRepository Impl
 * This should be moved to test package once we have actual PolicyRepositoryImpl
 */
public class InMemoryPolicyRepository implements PolicyRepository {
  private List<PolicyDetails> policyDetailsList = new ArrayList<>();

  public InMemoryPolicyRepository() {
    String policyNumber = "P000001";
    policyDetailsList.add(
        PolicyDetails.builder()
            .policyNumber(policyNumber)
            .productClass("Participating")
            .productType("WholeLife")
            .surrenderValue("550000.00")
            .surrenderValueDate(LocalDateMapping.stringToLocalDate("2021-07-31"))
            .nav("40000.00")
            .navDate(LocalDateMapping.stringToLocalDate("2021-07-25"))
            .policyMaturityDate(LocalDateMapping.stringToLocalDate("2105-10-31"))
            .policyHolder("123HU 321KU")
            .jointPolicyHolder("NA")
            .lifeInsured(Arrays.asList(
                "XYZ XYZ XYZ",
                "LMN LMN LMN"
            ))
            .jointLifeInsured(Arrays.asList(
                "NA"
            ))
            .secondaryLifeInsured(Arrays.asList(
                "GIJK GIJK",
                "PQRST",
                "PQRVT"
            ))
            .beneficiary("YES")
            .payer(Arrays.asList(
                "JHTK45",
                "FRTYR33",
                "MNW29"
            ))
            .exclusion("NO")
            .premiumModeFrequency("Monthly")
            .nextPremiumDueDate(LocalDateMapping.stringToLocalDate("2021-12-31"))
            .nextPremiumAmount("5000.00")
            .totalPremiumPaid("25000.00")
            .dateFirstIncomePayout(Arrays.asList(
                LocalDateMapping.stringToLocalDate("2021-10-31"),
                LocalDateMapping.stringToLocalDate("2025-10-31")
            ))
            .dateLastIncomePayout(Arrays.asList(
                LocalDateMapping.stringToLocalDate("2022-10-31"),
                LocalDateMapping.stringToLocalDate("2023-10-31")
            ))
            .lastIncomePayoutAmount(Arrays.asList(
                "NA"
            ))
            .totalAccumulatedIncomeAmount(Arrays.asList(
                "NA"
            ))
            .payoutFrequency(Arrays.asList(
                "Annually",
                "Quarterly"
            ))
            .payoutReinvest(Arrays.asList(
                "Yes",
                "No"
            ))
            .guaranteedValueAtMaturity("500000.00")
            .fundsIndicator("Yes")
            .build()
    );
  }

  public InMemoryPolicyRepository addAll(List<PolicyDetails> policyDetails) {
    policyDetailsList.addAll(policyDetails);
    return this;
  }

  @Override
  public Optional<PolicyDetails> getPolicyDetails(String policyNumber) {
    return policyDetailsList.stream()
        .filter(policyDetails -> policyDetails.getPolicyNumber().equalsIgnoreCase(policyNumber))
        .findAny();
  }

    @Override
    public PolicyDetails getPolicyById(String policyNumber) {
        return null;
    }
}
