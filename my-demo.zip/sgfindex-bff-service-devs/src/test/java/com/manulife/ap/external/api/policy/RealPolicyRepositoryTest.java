package com.manulife.ap.external.api.policy;

import com.graphql.spring.boot.test.GraphQLResponse;
import com.graphql.spring.boot.test.GraphQLTest;
import com.graphql.spring.boot.test.GraphQLTestTemplate;
import com.manulife.ap.core.policy.domain.PolicyDetails;
import com.manulife.ap.testutil.TestSuite;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static java.lang.String.format;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@DisplayName("Unit Test - Real Policy Repository Test")
@ExtendWith(MockitoExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
//@GraphQLTest
/*@ExtendWith(SpringExtension.class)
@TestPropertySource("classpath:application.yml")
@ComponentScan("com.manulife.ap")*/
public class RealPolicyRepositoryTest {

    //@Autowired
    //@Resource(name = "realPolicyRepository")
    /*private RealPolicyRepository realPolicyRepository;
    
    private String serverUrl = "https://sg-core-system-service-uat.apps.eas.pcf.manulife.com/graphql";*/

    @Autowired
    private GraphQLTestTemplate graphQLTestTemplate;

    @InjectMocks
    private RealPolicyRepository realPolicyRepository;

    @BeforeEach
    @DisplayName("Setup")
    void setup() throws IOException {
        //this.realPolicyRepository = new RealPolicyRepository(serverUrl); 
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(realPolicyRepository, "serverUrl", "https://sg-core-system-service-uat.apps.eas.pcf.manulife.com/graphql");

        GraphQLResponse response =
                graphQLTestTemplate.postForResource("graphql/system-api/queryPolicy.graphql");

        System.out.println("---------: " + response.getRawResponse().getBody());
    }

    @Test
    @Tag(TestSuite.UNIT_TEST)
    @DisplayName("Should return non-null object with constructor")
    void shouldReturnNonNullObjectWithConstructor() {
        assertNotNull(this.realPolicyRepository);
    }


    @Nested
    @DisplayName("Test Method - getPolicyDetails")
    class TestGetPolicyDetails {

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should return IllegalArgumntException with null value of policy number")
        void shouldReturnIllegalArgumentExceptionWithNullValueOfPolicyNumber() {
            //Given
            String policyNumber = null;
            //When
            //Then
            assertThrows(IllegalArgumentException.class, () -> realPolicyRepository.getPolicyDetails(policyNumber));
        }

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should return IllegalArgummentException with empty value of policy number")
        void shouldReturnIllegalArgumentExceptionWithEmptyValueOfPolicyNumber(){
            //Given
            String policyNumber = "";
            //When
            //Then
            assertThrows(IllegalArgumentException.class, () -> realPolicyRepository.getPolicyDetails(policyNumber));
        }

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should ")
        void shouldReturnListOfOnePolicyAggregateWithListOfOnePolicyNumber(){
            //Given
            /*String policyNumber = "P1234567890";
            *//*Mockito
                    .when(realPolicyRepository.getPolicyDetails(policyNumber))
                    .thenReturn(Optional.ofNullable(
                            PolicyDetails.builder()
                                            .policyNumber("P1234567890")
                                    .build()
                    ));*//*
            //When
            Optional<PolicyDetails> policyDetails = realPolicyRepository.getPolicyDetails(policyNumber);
            //Then
            assertNotNull(policyDetails);*/
        }
    }
}
