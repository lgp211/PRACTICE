package com.manulife.ap.testutil;

public class TestSuite {
  public static final String UNIT_TEST = "unit-test";
  public static final String INTEGRATION_TEST = "integration-test";
  public static final String ACCEPTANCE_TEST = "acceptance-test";
}
