package com.manulife.ap.ui.delegate;

import com.manulife.ap.common.mapper.LocalDateMapping;
import com.manulife.ap.core.policy.PolicyManager;
import com.manulife.ap.core.policy.domain.PolicyAggregate;
import com.manulife.ap.core.policy.domain.PolicyDetails;
import com.manulife.ap.testutil.TestSuite;
import org.junit.jupiter.api.*;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import java.util.Arrays;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.ArgumentMatchers.anyList;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(FindexApiDelegateImpl.class)
class FindexApiDelegateImplIntegrationTest {

  private final String consumer = "cusumer";
  private FindexApiDelegateImpl findexApiDelegate;
  @Autowired
  private MockMvc mockMvc;

  @MockBean
  private PolicyManager policyManager;

  @BeforeEach
  void setup() {
    this.findexApiDelegate = new FindexApiDelegateImpl(policyManager);
  }

  @Nested
  @DisplayName("Test Get Policy Details Method")
  class TestGetPolicyDetailsMethod {

    @Test
    @Tag(TestSuite.INTEGRATION_TEST)
    @DisplayName("Should return consumer response")
    void shouldReturnConsumerResponse() throws Exception {
      // Given
      Mockito.when(policyManager.getPolicies(anyList()))
        .thenReturn(Arrays.asList(
          PolicyAggregate.builder()
            .policy(PolicyDetails.builder()
              .policyNumber("1234567890")
              .productClass("Participating")
              .productType("WholeLife")
              .surrenderValue("550000.00")
              .surrenderValueDate(LocalDateMapping.stringToLocalDate("2021-07-31"))
              .nav("40000.00")
              .navDate(LocalDateMapping.stringToLocalDate("2021-07-25"))
              .policyMaturityDate(LocalDateMapping.stringToLocalDate("2105-10-31"))
              .policyHolder("123HU 321KU")
              .jointPolicyHolder("NA")
              .lifeInsured(Arrays.asList(
                "XYZ XYZ XYZ",
                "LMN LMN LMN"
              ))
              .jointLifeInsured(Arrays.asList(
                "NA"
              ))
              .secondaryLifeInsured(Arrays.asList(
                "GIJK GIJK",
                "PQRST",
                "PQRVT"
              ))
              .beneficiary("YES")
              .payer(Arrays.asList(
                "JHTK45",
                "FRTYR33",
                "MNW29"
              ))
              .exclusion("NO")
              .premiumModeFrequency("Monthly")
              .nextPremiumDueDate(LocalDateMapping.stringToLocalDate("2021-10-31"))
              .nextPremiumAmount("5000.00")
              .totalPremiumPaid("25000.00")
              .dateFirstIncomePayout(Arrays.asList(
                LocalDateMapping.stringToLocalDate("2021-10-31"),
                LocalDateMapping.stringToLocalDate("2025-10-31")
              ))
              .dateLastIncomePayout(Arrays.asList(
                LocalDateMapping.stringToLocalDate("2021-10-31"),
                LocalDateMapping.stringToLocalDate("2022-10-31")
              ))
              .lastIncomePayoutAmount(Arrays.asList(
                "NA"
              ))
              .totalAccumulatedIncomeAmount(Arrays.asList(
                "NA"
              ))
              .payoutFrequency(Arrays.asList(
                "Annually",
                "Quarterly"
              ))
              .payoutReinvest(Arrays.asList(
                "Yes",
                "No"
              ))
              .guaranteedValueAtMaturity("500000.00")
              .fundsIndicator("Yes")
              .build())
            .build()
        ));

      // When
      // Then
      mockMvc.perform(MockMvcRequestBuilders
          .get("/findex/v1/123456789/policydetails")
          .header(HttpHeaders.AUTHORIZATION, "mock")
          .header("clientId", "mock")
          .header("country", "mock")
          .header("xforwardedFor", "mock")
          .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$", notNullValue()))
        .andExpect(jsonPath("$[0].policy.policyNumber", is("1234567890")))
        .andExpect(jsonPath("$[0].policy.productClass", is("Participating")))
        .andExpect(jsonPath("$[0].policy.productType", is("WholeLife")))
        .andExpect(jsonPath("$[0].policy.surrenderValue", is("550000.00")))
        .andExpect(jsonPath("$[0].policy.surrenderValueDate", is("2021-07-31")))
        .andExpect(jsonPath("$[0].policy.nav", is("40000.00")))
        .andExpect(jsonPath("$[0].policy.navDate", is("2021-07-25")))
        .andExpect(jsonPath("$[0].policy.policyMaturityDate", is("2105-10-31")))
        .andExpect(jsonPath("$[0].policy.policyHolder", is("123HU 321KU")))
        .andExpect(jsonPath("$[0].policy.jointPolicyHolder", is("NA")))
        .andDo(MockMvcResultHandlers.print());
    }
  }
}
