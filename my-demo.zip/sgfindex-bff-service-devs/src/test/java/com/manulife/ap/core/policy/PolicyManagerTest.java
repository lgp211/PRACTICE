package com.manulife.ap.core.policy;

import com.manulife.ap.core.policy.domain.PolicyAggregate;
import com.manulife.ap.core.policy.domain.PolicyDetails;
import com.manulife.ap.testutil.TestSuite;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;

@DisplayName("Unit Test - Policy Manager")
@ExtendWith(MockitoExtension.class)
class PolicyManagerTest {
    private PolicyManager policyManager;

    @Mock
    private PolicyRepository policyRepository;

    @BeforeEach
    @DisplayName("Setup")
    void setup() {
        this.policyManager = new PolicyManager(policyRepository);
    }

    @Test
    @Tag(TestSuite.UNIT_TEST)
    @DisplayName("Should return policy manager instance")
    void shouldReturnNonNullObject() {
        assertNotNull(this.policyManager);
    }

    @Test
    @Tag(TestSuite.UNIT_TEST)
    @DisplayName("Class should be annotated as Spring Service")
    void classShouldBeAnnotatedAsEmbeddable() {
        // When
        Service service = PolicyManager.class.getAnnotation(Service.class);
        // Then
        assertNotNull(service);
    }

    @Nested
    @DisplayName("Test Get Policy Details Method")
    class TestGetPolicyDetailsMethod {

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should throw illegal argument exception when list provided is null")
        void shouldThrowExceptionWhenListIsNull() {
            // When
            // Then
            assertThrows(IllegalArgumentException.class, () -> policyManager.getPolicies(null));
        }

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should throw illegal argument exception when list provided is empty")
        void shouldThrowExceptionWhenListIsEmpty() {
            // When
            // Then
            assertThrows(IllegalArgumentException.class, () -> policyManager.getPolicies(Arrays.asList()));
        }

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should throw illegal argument exception when policy number is null")
        void shouldThrowExceptionWhenPolicyNumberIsNull() {
            // Given
            String policyNumber = null;
            // When
            // Then
            assertThrows(IllegalArgumentException.class, () -> policyManager.getPolicies(Arrays.asList(policyNumber)));
        }

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should throw illegal argument exception when policy number is empty")
        void shouldThrowExceptionWhenPolicyNumberIsEmpty() {
            // Given
            String policyNumber = "";
            // When
            // Then
            assertThrows(IllegalArgumentException.class, () -> policyManager.getPolicies(Arrays.asList(policyNumber)));
        }

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should throw runtime exception when policy number is not found")
        void shouldThrowRuntimeException() {
            // Given
            String policyNumber = "P123456789";
            // When
            // Then
            assertThrows(RuntimeException.class, () -> policyManager.getPolicies(Arrays.asList(policyNumber)));
        }

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should return policy aggregate")
        void shouldReturnPolicyAggregate() {
            // Given
            String policyNumber = "P123456789";

            Mockito.when(policyRepository.getPolicyDetails(anyString()))
                    .thenReturn(Optional.ofNullable(
                            PolicyDetails.builder()
                                    .policyNumber(policyNumber)
                                    .build()
                    ));

            // When
            List<PolicyAggregate> policyAggregateList = policyManager.getPolicies(Arrays.asList(policyNumber));

            // Then
            assertNotNull(policyAggregateList);
            assertFalse(policyAggregateList.isEmpty());

            PolicyAggregate policyAggregate1 = policyAggregateList.get(0);
            assertEquals(policyNumber, policyAggregate1.getPolicy().getPolicyNumber());
        }

    }

    @Nested
    @DisplayName("Test Get Policy By Id Method")
    class TestGetPolicyByIdMethod {

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should throw runtime exception when policy number is null")
        void shouldThrowExceptionWhenPolicyNumberIsNull() {
            // Given
            String policyNumber = null;
            // When
            // Then
            assertThrows(IllegalArgumentException.class, () -> policyManager.getPolicyById(policyNumber));
        }

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should throw runtime exception when policy number is empty")
        void shouldThrowExceptionWhenPolicyNumberIsEmpty() {
            // Given
            String policyNumber = "";
            // When
            // Then
            assertThrows(IllegalArgumentException.class, () -> policyManager.getPolicyById(policyNumber));
        }

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should throw runtime exception when policy number is not found")
        void shouldThrowRuntimeException() {
            // Given
            String policyNumber = "P123456789";
            // When
            // Then
            assertThrows(RuntimeException.class, () -> policyManager.getPolicyById(policyNumber));
        }

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should return policy aggregate")
        void shouldReturnPolicyAggregate() {
            // Given
            String policyNumber = "P123456789";

            Mockito.when(policyRepository.getPolicyById(anyString()))
                    .thenReturn(
                            PolicyDetails.builder()
                                    .policyNumber(policyNumber)
                                    .build()
                    );

            // When
            PolicyAggregate policyAggregate = policyManager.getPolicyById(policyNumber);

            // Then
            assertNotNull(policyAggregate);

            assertEquals(policyNumber, policyAggregate.getPolicy().getPolicyNumber());
        }
    }
}
