package com.manulife.ap.controller;

import com.manulife.ap.controller.PolicyController;
import com.manulife.ap.core.policy.PolicyManager;
import com.manulife.ap.core.policy.domain.PolicyAggregate;
import com.manulife.ap.core.policy.domain.PolicyDetails;
import com.manulife.ap.testutil.TestSuite;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;

@DisplayName("Unit Test - Policy Controller")
@ExtendWith(MockitoExtension.class)
public class PolicyControllerTest {
    private PolicyController policyController;

    @Mock
    private PolicyManager policyManager;

    @BeforeEach
    void setup() {
        this.policyController = new PolicyController(policyManager);
    }

    @Test
    @Tag(TestSuite.UNIT_TEST)
    @DisplayName("Should return policy manager instance")
    void shouldReturnNonNullObject() {
        assertNotNull(this.policyController);
    }

    @Test
    @Tag(TestSuite.UNIT_TEST)
    @DisplayName("Class should be annotated as Spring Controller")
    void classShouldBeAnnotatedAsEmbeddable() {
        //When
        RestController restController = PolicyController.class.getAnnotation(RestController.class);
        //Then
        assertNotNull(restController);
    }

    @Nested
    @DisplayName("Test Get Policy Details Method")
    class TestGetPolicyDetailsMethod {

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should throw illegal argument exception when list provided is null")
        void shouldThrowExceptionWhenListIsNull() {
            // When
            // Then
            //assertThrows(IllegalArgumentException.class, () -> policyController.getPolicydetails(null));
        }

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should throw runtime exception when policy number is empty")
        void shouldThrowExceptionWhenPolicyNumberIsEmpty() {
            // Given
            String policyNumber = "";
            // When
            // Then
            //assertThrows(IllegalArgumentException.class, () -> policyController.getPolicydetails(policyNumber));
        }

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should throw runtime exception when policy number is not found")
        void shouldThrowRuntimeException() {
            // Given
            String policyNumber = "P123456789";
            // When
            // Then
            assertThrows(RuntimeException.class, () -> policyController.getPolicydetails(policyNumber));
        }

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should return policy aggregate")
        void shouldReturnPolicyAggregate() {
            // Given
            String policyNumber = "P123456789";

            Mockito.when(policyManager.getPolicies(anyList()))
                    .thenReturn(Arrays.asList(
                                    PolicyAggregate.builder()
                                            .policy(PolicyDetails.builder()
                                                    .policyNumber(policyNumber)
                                                    .build())
                                            .build()
                            )
                    );

            // When
            ResponseEntity<List<PolicyAggregate>> policyAggregateRes = policyController.getPolicydetails(policyNumber);

            // Then
            assertNotNull(policyAggregateRes);
            assertEquals(policyNumber, policyAggregateRes.getBody().get(0).getPolicy().getPolicyNumber());
        }
    }

    @Nested
    @DisplayName("Test Get Policy By Id Method")
    class TestGetPolicyByIdMethod {

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should throw illegal argument exception when policy number provided is null")
        void shouldThrowExceptionWhenPolicyNumberIsNull() {
            // Given
            String policyNumber = null;
            // When
            // Then
            //assertThrows(IllegalArgumentException.class, () -> policyController.getPolicydetails(policyNumber));
        }

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should throw runtime exception when policy number is empty")
        void shouldThrowExceptionWhenPolicyNumberIsEmpty() {
            // Given
            String policyNumber = "";
            // When
            // Then
            //assertThrows(IllegalArgumentException.class, () -> policyController.getPolicyById(policyNumber));
        }

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should throw runtime exception when policy number is not found")
        void shouldThrowRuntimeException() {
            // Given
            String policyNumber = "P123456789";
            // When
            // Then
            assertThrows(RuntimeException.class, () -> policyController.getPolicyById(policyNumber));
        }

        @Test
        @Tag(TestSuite.UNIT_TEST)
        @DisplayName("Should return policy aggregate")
        void shouldReturnPolicyAggregate() {
            // Given
            String policyNumber = "P123456789";

            Mockito.when(policyManager.getPolicyById(anyString()))
                    .thenReturn(
                            PolicyAggregate.builder()
                                    .policy(PolicyDetails.builder()
                                            .policyNumber(policyNumber)
                                            .build())
                                    .build()
                    );

            // When
            ResponseEntity<PolicyAggregate> policyAggregateRes = policyController.getPolicyById(policyNumber);

            // Then
            assertNotNull(policyAggregateRes);
            assertEquals(policyNumber, policyAggregateRes.getBody().getPolicy().getPolicyNumber());
        }
    }
}
