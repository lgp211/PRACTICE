package com.manulife.ap.ui.mapper;

import com.manulife.ap.core.policy.domain.PolicyAggregate;
import com.manulife.ap.core.policy.domain.PolicyDetails;
import com.manulife.ap.swagger.model.PolicyDetailsDto;
import com.manulife.ap.swagger.model.PolicyDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;


@Mapper
public interface PolicyAggregateMapper {
  static PolicyAggregateMapper get() {
    return PolicyAggregateMapperInstance.INSTANCE;
  }

  final class PolicyAggregateMapperInstance {
    private static final PolicyAggregateMapper INSTANCE = Mappers.getMapper(PolicyAggregateMapper.class);
    private PolicyAggregateMapperInstance() {}
  }

  @Mapping(target = "policyNo", source = "policyDetails.policyNumber")
  PolicyDetailsDto toDto(PolicyDetails policyDetails);

  PolicyDto toDto(PolicyAggregate policyAggregate);

  List<PolicyDto> toDtoList(List<PolicyAggregate> policyAggregateList);
}
