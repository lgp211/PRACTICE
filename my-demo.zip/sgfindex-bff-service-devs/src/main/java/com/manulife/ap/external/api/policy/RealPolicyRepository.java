package com.manulife.ap.external.api.policy;

import com.apollographql.apollo.ApolloCall;
import com.apollographql.apollo.ApolloClient;
import com.apollographql.apollo.api.Response;
import com.manulife.ap.core.policy.PolicyRepository;
import com.manulife.ap.core.policy.domain.PolicyDetails;
import com.manulife.sg.poc.graphql.client.QueryPolicyQuery;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Initial PolicyRepository Impl
 * This should be moved to test package once we have actual PolicyRepositoryImpl
 */
@Primary
@Service("realPolicyRepository")
public class RealPolicyRepository implements PolicyRepository {
    private List<PolicyDetails> policyDetailsList = new ArrayList<>();

    @Value("${apollo.client.url}")
    private String serverUrl;

    /*//@Value("${apollo.client.url}")
    private String serverUrl;

    public RealPolicyRepository(@Value("${apollo.client.url}") String serverUrl){
        this.serverUrl = serverUrl;
    }*/

    @Override
    public Optional<PolicyDetails> getPolicyDetails(String policyNumber) {
        if (Objects.isNull(policyNumber) || policyNumber.isEmpty()) {
            throw new IllegalArgumentException("Policy number list is null or empty");
        }

        ApolloClient client =
                ApolloClient.builder()
                        .serverUrl(serverUrl)
                        .build();

        final List<QueryPolicyQuery.Data> agentList = new ArrayList<>();
        Response res = (Response) ExtensionsUtil.toCompletableFuture((ApolloCall) client.query(new QueryPolicyQuery(policyNumber))).join();
        //System.out.println("res: " + res);
        QueryPolicyQuery.Data result = (QueryPolicyQuery.Data) res.data();

        List<QueryPolicyQuery.Role> roleList = result.policyById().roles();
        List<QueryPolicyQuery.Role> policyHolder = roleList.stream().filter(role -> role.type().code().equals("O")).collect(Collectors.toList());

        List<QueryPolicyQuery.Role> jointPolicyHolder = roleList.stream().filter(role -> role.type().code().equals("I")).collect(Collectors.toList());

        List<QueryPolicyQuery.Role> lifeInsured = roleList.stream().filter(role -> role.type().code().equals("I") || role.type().code().equals("T")).collect(Collectors.toList());
        List<QueryPolicyQuery.Role> jointLifeInsured = roleList.stream().filter(role -> role.type().code().equals("N")).collect(Collectors.toList());
        List<QueryPolicyQuery.Role> secondaryLifeInsured = roleList.stream().filter(role -> role.type().code().equals("S")).collect(Collectors.toList());
        List<QueryPolicyQuery.Role> payer = roleList.stream().filter(role -> role.type().code().equals("P") || role.type().code().equals("O")).collect(Collectors.toList());
        String beneficiary = (result.policyById().beneficiaries().isEmpty() == true ? "NO" : "YES");

        policyDetailsList.add(
                PolicyDetails.builder()
                        .policyNumber(result.policyById().policyNumber())
                        .surrenderValue(result.policyById().financial().surrenderValue().toString())
                        .policyHolder((policyHolder.stream().map(holder -> holder.customer().name().fullName()).collect(Collectors.toList())).stream().map(Object::toString)
                                .collect(Collectors.joining(", ")))
                        .jointPolicyHolder((jointPolicyHolder.stream().map(holder -> holder.customer().name().fullName()).collect(Collectors.toList())).stream().map(Object::toString)
                                .collect(Collectors.joining(", ")))
                        .lifeInsured(lifeInsured.stream().map(life -> life.customer().name().fullName()).collect(Collectors.toList()))
                        .jointLifeInsured(jointLifeInsured.stream().map(life -> life.customer().name().fullName()).collect(Collectors.toList()))
                        .secondaryLifeInsured(secondaryLifeInsured.stream().map(life -> life.customer().name().fullName()).collect(Collectors.toList()))
                        .beneficiary(beneficiary)
                        .payer(payer.stream().map(life -> life.customer().name().fullName()).collect(Collectors.toList()))
                        .nextPremiumDueDate(LocalDate.parse(result.policyById().paidToDate()))
                        .nextPremiumAmount(result.policyById().premium().discountAmount().toString())
                        .totalPremiumPaid((result.policyById().layers().stream().map(layer -> layer.premium().paidAmount()).collect(Collectors.toList())).stream().map(Object::toString).collect(Collectors.joining(", ")))
                        .build()
        );
        return policyDetailsList.stream()
                .filter(policyDetails -> policyDetails.getPolicyNumber().equalsIgnoreCase(policyNumber))
                .findAny();
    }

    @Override
    public PolicyDetails getPolicyById(String policyNumber) {
        //System.out.println("+++++--------------: " + policyNumber);
        ApolloClient client =
                ApolloClient.builder()
                        .serverUrl(serverUrl)
                        .build();

        final List<QueryPolicyQuery.Data> agentList = new ArrayList<>();
        Response res = (Response) ExtensionsUtil.toCompletableFuture((ApolloCall) client.query(new QueryPolicyQuery(policyNumber))).join();
        //System.out.println("res: " + res);
        QueryPolicyQuery.Data result = (QueryPolicyQuery.Data) res.data();

        List<QueryPolicyQuery.Role> roleList = result.policyById().roles();
        List<QueryPolicyQuery.Role> policyHolder = roleList.stream().filter(role -> role.type().code().equals("O")).collect(Collectors.toList());

        List<QueryPolicyQuery.Role> jointPolicyHolder = roleList.stream().filter(role -> role.type().code().equals("I")).collect(Collectors.toList());

        List<QueryPolicyQuery.Role> lifeInsured = roleList.stream().filter(role -> role.type().code().equals("I") || role.type().code().equals("T")).collect(Collectors.toList());
        List<QueryPolicyQuery.Role> jointLifeInsured = roleList.stream().filter(role -> role.type().code().equals("N")).collect(Collectors.toList());
        List<QueryPolicyQuery.Role> secondaryLifeInsured = roleList.stream().filter(role -> role.type().code().equals("S")).collect(Collectors.toList());
        List<QueryPolicyQuery.Role> payer = roleList.stream().filter(role -> role.type().code().equals("P") || role.type().code().equals("O")).collect(Collectors.toList());
        String beneficiary = (result.policyById().beneficiaries().isEmpty() == true ? "NO" : "YES");

        return PolicyDetails.builder()
                .policyNumber(result.policyById().policyNumber())
                .surrenderValue(result.policyById().financial().surrenderValue().toString())
                .policyHolder((policyHolder.stream().map(holder -> holder.customer().name().fullName()).collect(Collectors.toList())).stream().map(Object::toString)
                        .collect(Collectors.joining(", ")))
                .jointPolicyHolder((jointPolicyHolder.stream().map(holder -> holder.customer().name().fullName()).collect(Collectors.toList())).stream().map(Object::toString)
                        .collect(Collectors.joining(", ")))
                .lifeInsured(lifeInsured.stream().map(life -> life.customer().name().fullName()).collect(Collectors.toList()))
                .jointLifeInsured(jointLifeInsured.stream().map(life -> life.customer().name().fullName()).collect(Collectors.toList()))
                .secondaryLifeInsured(secondaryLifeInsured.stream().map(life -> life.customer().name().fullName()).collect(Collectors.toList()))
                .beneficiary(beneficiary)
                .payer(payer.stream().map(life -> life.customer().name().fullName()).collect(Collectors.toList()))
                .nextPremiumDueDate(LocalDate.parse(result.policyById().paidToDate()))
                .nextPremiumAmount(result.policyById().premium().discountAmount().toString())
                .totalPremiumPaid((result.policyById().layers().stream().map(layer -> layer.premium().paidAmount()).collect(Collectors.toList())).stream().map(Object::toString).collect(Collectors.joining(", ")))
                .build();
    }
}
