package com.manulife.ap.ui.delegate;

import com.manulife.ap.core.policy.PolicyManager;
import com.manulife.ap.core.policy.domain.PolicyAggregate;
import com.manulife.ap.swagger.api.FindexApiDelegate;
import com.manulife.ap.swagger.model.ConsumerResponse;
import com.manulife.ap.ui.mapper.PolicyAggregateMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
@RequiredArgsConstructor
public class FindexApiDelegateImpl implements FindexApiDelegate {
  private final PolicyManager policyManager;

  @Override
  public ResponseEntity<ConsumerResponse> getPolicyDetails(final String consumer, final String clientId, final String authorization, final String country, final String xforwardedFor) {
    //String policyNumber = "P000001";
    String policyNumber = "1490137092";
    List<PolicyAggregate> policyAggregateList = policyManager.getPolicies(Arrays.asList(policyNumber));

    return ResponseEntity.ok(
        new ConsumerResponse()
            .timestamp("2020-05-13T09:49:47.602Z")
            .insurerName("ABC Insurance Pte Ltd")
            .insurerCode("I230D")
            .respCode("0000")
            .respMessage("The request fields have missing mandatory or contain invalid parameters.")
            .policies(PolicyAggregateMapper.get().toDtoList(policyAggregateList))
    );
  }
}
