package com.manulife.ap.core.policy;


import com.google.common.base.Strings;
import com.manulife.ap.core.policy.domain.PolicyAggregate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class PolicyManager implements PolicyService {

    @Resource(name = "realPolicyRepository")
    private final PolicyRepository policyRepository;

    @Override
    public List<PolicyAggregate> getPolicies(final List<String> policyNumberList) {
        if (Objects.isNull(policyNumberList) || policyNumberList.isEmpty()) {
            throw new IllegalArgumentException("Policy number list is null or empty");
        }

        return policyNumberList
                .parallelStream()
                .map(policyNumber -> {
                    if (Strings.isNullOrEmpty(policyNumber)) {
                        throw new IllegalArgumentException("Invalid policy number");
                    }
                    return policyNumber;
                })
                .map(policyNumber ->
                        PolicyAggregate.builder()
                                .policy(
                                        policyRepository.getPolicyDetails(policyNumber)
                                                .orElseThrow(() -> new RuntimeException("Policy not found, policyNumber: " + policyNumber))
                                )
                                .build())
                .collect(Collectors.toList());
    }

    @Override
    public PolicyAggregate getPolicyById(String policyNumber) {
        if (Objects.isNull(policyNumber) || policyNumber.isEmpty()) {
            throw new IllegalArgumentException("Policy number list is null or empty");
        }

        return PolicyAggregate.builder()
                .policy(
                        Optional.ofNullable(policyRepository.getPolicyById(policyNumber))
                                .orElseThrow(() -> new RuntimeException("Policy not found, policyNumber: " + policyNumber))
                )
                .build();
    }
}
