package com.manulife.ap.core.policy;

import com.manulife.ap.core.policy.domain.PolicyAggregate;

import java.util.List;

public interface PolicyService {
    List<PolicyAggregate> getPolicies(List<String> policyNumberList);

    PolicyAggregate getPolicyById(String policyNumber);
}
