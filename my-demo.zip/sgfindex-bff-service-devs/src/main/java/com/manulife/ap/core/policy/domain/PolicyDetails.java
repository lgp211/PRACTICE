package com.manulife.ap.core.policy.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PolicyDetails {
  private String policyNumber;
  private String productClass;
  private String productType;
  private String surrenderValue;
  private LocalDate surrenderValueDate;
  private String nav;
  private LocalDate navDate;
  private LocalDate policyMaturityDate;
  private String policyHolder;
  private String jointPolicyHolder;

  private List<String> lifeInsured;
  private List<String> jointLifeInsured;
  private List<String> secondaryLifeInsured;

  private String beneficiary;
  private List<String> payer;

  private String exclusion;
  private String premiumModeFrequency;
  private LocalDate nextPremiumDueDate;
  private String nextPremiumAmount;
  private String totalPremiumPaid;

  private List<LocalDate> dateFirstIncomePayout;
  private List<LocalDate> dateLastIncomePayout;
  private List<String> lastIncomePayoutAmount;
  private List<String> totalAccumulatedIncomeAmount;
  private List<String> payoutFrequency;
  private List<String> payoutReinvest;

  private String guaranteedValueAtMaturity;
  private String fundsIndicator;
}
