package com.manulife.ap.controller;

import com.manulife.ap.core.policy.PolicyManager;
import com.manulife.ap.core.policy.domain.PolicyAggregate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/findex/v1")
@Slf4j
@RequiredArgsConstructor
public class PolicyController {
    @Autowired
    private final PolicyManager policyManager;

    @RequestMapping("/")
    public String sayHello() {
        return "The policy service is running";
    }

    @GetMapping("/{consumer}/policydetails")
    public ResponseEntity<List<PolicyAggregate>> getPolicydetails(@PathVariable String consumer) {

        
        String policyNumber = "1490137092";
        //String policyNumber = consumer;
        //System.out.println(policyNumber);
        List<String> policyNumberList = new ArrayList<>();
        policyNumberList.add(policyNumber);
        policyNumberList.add("1420000006");

        if (Objects.isNull(policyNumberList) || policyNumberList.isEmpty()) {
            throw new IllegalArgumentException("Policy number list is null or empty");
        }

        List<PolicyAggregate> policyAggregateList = policyManager.getPolicies(policyNumberList);

        if(policyAggregateList.isEmpty()){
            throw new RuntimeException("Policy not found, policyNumber: " + policyNumber);
        }

        //System.out.println(policyManager.getPolicies(policyNumberList).isEmpty());


        /*List<PolicyAggregate> policyAggregateList = policyManager.getPolicies(policyNumberList).stream().map(policyAggregate -> {
            System.out.println(policyAggregate);
            if(policyAggregate == null){
                throw new IllegalArgumentException("Policy not found, policyNumber: " + policyNumber);
            }
            return policyAggregate;
        }).collect(Collectors.toList());*/

        /*List<PolicyAggregate> policyAggregateList = policyManager.getPolicies(Arrays.asList(policyNumber));
        System.out.println("----------: " + policyAggregateList);*/
        /*List<PolicyAggregate> policyAggregateList = Optional.ofNullable(policyManager.getPolicies(policyNumberList))
                .orElseThrow(() -> new RuntimeException("Policy not found, policyNumber: " + policyNumber));*/

        //PolicyAggregate policyAggregate1 = policyAggregateList.get(0);
        //System.out.println(policyAggregate1.getPolicy().getPolicyNumber());
        return new ResponseEntity<List<PolicyAggregate>>(policyAggregateList, HttpStatus.OK);
    }

    @GetMapping("/{consumer}/policydetail")
    public ResponseEntity<PolicyAggregate> getPolicyById(@PathVariable String consumer) {
        //String policyNumber = "1490137092";
        String policyNumber = consumer;

        if (Objects.isNull(policyNumber) || policyNumber.isEmpty()) {
            throw new IllegalArgumentException("Policy number list is null or empty");
        }

        //PolicyAggregate policyAggregate = policyManager.getPolicyById(policyNumber);
        PolicyAggregate policyAggregate = Optional.ofNullable(policyManager.getPolicyById(policyNumber))
                .orElseThrow(() -> new RuntimeException("Policy not found, policyNumber: " + policyNumber));

        //System.out.println(policyAggregate.getPolicy().getPolicyNumber());
        return new ResponseEntity<PolicyAggregate>(policyAggregate, HttpStatus.OK);
    }

}
