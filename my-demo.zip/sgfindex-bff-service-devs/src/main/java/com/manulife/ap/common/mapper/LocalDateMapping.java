package com.manulife.ap.common.mapper;

import com.google.common.base.Strings;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

@LocalDateMapper
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@Slf4j
public class LocalDateMapping {

  /**
   * Expected Date Format: {@link java.time.format.DateTimeFormatter#ISO_LOCAL_DATE}
   * e.g. 2020-01-01, 1989-12-26
   *
   * @param dateString Date string input
   * @return LocalDate instance
   */
  @StringToLocalDate
  public static LocalDate stringToLocalDate(String dateString) {
    if (Strings.isNullOrEmpty(dateString) || dateString.length() < 10) {
      return null;
    }

    try {
      return LocalDate.parse(dateString.substring(0, 10));
    } catch (DateTimeParseException e) {
      log.error("Local date parsing exception: {}", e.getMessage());
      return null;
    }
  }
}
