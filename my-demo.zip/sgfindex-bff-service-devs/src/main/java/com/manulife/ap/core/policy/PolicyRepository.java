package com.manulife.ap.core.policy;

import com.manulife.ap.core.policy.domain.PolicyDetails;

import java.util.Optional;

public interface PolicyRepository {
    Optional<PolicyDetails> getPolicyDetails(String policyNumber);

    PolicyDetails getPolicyById(String policyNumber);
}
