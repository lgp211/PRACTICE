#!/bin/bash
set -x
sleep 120
if [[ $(curl -s -o /dev/null -L -w '%{http_code}' https://$1/actuator/health) != '200' ]]
then
    exit -1
fi