!!!**if you don't want to separate your conf from your project.**
!!!**please copy all thing in this repo  in your project root**