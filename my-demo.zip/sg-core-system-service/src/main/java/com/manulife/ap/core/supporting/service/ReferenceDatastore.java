package com.manulife.ap.core.supporting.service;

import com.manulife.ap.core.supporting.model.ReferenceCategory;
import com.manulife.ap.core.supporting.model.ReferenceField;

import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface ReferenceDatastore {
  Optional<ReferenceField> findByCategoryAndCode(ReferenceCategory category, String referenceCode);
  List<ReferenceField> findByCategoryAndCodes(ReferenceCategory category, Set<String> referenceCodes);
}
