package com.manulife.ap.external.persistence.fund.summary.repository;

import com.manulife.ap.external.persistence.fund.summary.model.FundSummaryEntity;
import com.manulife.ap.external.persistence.fund.summary.model.FundSummaryId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FundSummaryEntityRepository extends JpaRepository<FundSummaryEntity, FundSummaryId> {
  List<FundSummaryEntity> findAllByIdFundIdAndIdFundVersion(String fundId, String fundVersion);
}