package com.manulife.ap.external.persistence.policy.coverage.repository;

import com.manulife.ap.external.persistence.policy.coverage.model.ProductClaimEntity;
import com.manulife.ap.external.persistence.policy.coverage.model.ProductClaimId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductClaimEntityRepository extends JpaRepository<ProductClaimEntity, ProductClaimId> {
  List<ProductClaimEntity> findAllByIdPlanCodeAndIdPlanVersion(String planCode, String planVersion);
}
