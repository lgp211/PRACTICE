package com.manulife.ap.external.persistence.agent.thirdparty.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Embeddable
public class AgentThirdPartyCompanyId implements Serializable {
  @Column(name = "CO_CD")
  private String companyCode;

  @Column(name = "CPNY_ID")
  private String companyId;
}
