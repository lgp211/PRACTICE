package com.manulife.ap.core.policy.coverage.service;

import com.manulife.ap.core.policy.coverage.model.CoverageUnderwriting;
import com.manulife.ap.core.policy.coverage.model.CoverageUnderwritingKey;

import java.util.Map;
import java.util.Set;

public interface CoverageUnderwritingService {
  Map<CoverageUnderwritingKey, CoverageUnderwriting> findAllByUnderwritingKeyIn(Set<CoverageUnderwritingKey> coverageUnderwritingKeys);
}