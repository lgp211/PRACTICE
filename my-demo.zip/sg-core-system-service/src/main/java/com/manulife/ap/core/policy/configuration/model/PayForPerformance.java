package com.manulife.ap.core.policy.configuration.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PayForPerformance {
  private PfpChoiceIndicator choiceIndicator;
  private PfpHealthIndicator healthIndicator;
}
