package com.manulife.ap.core.agent.root.service;

import com.manulife.ap.core.agent.root.model.Agent;
import com.manulife.ap.core.common.model.FilterCriteria;

import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

public interface AgentService {
  List<Agent> findAllByAgentCodeIn(List<String> agentCode);

  Map<String, List<Agent>> findAllByBranchCodeIn(Set<String> branchCodes);

  Map<String, List<Agent>> findAllByUnitCodeIn(Set<String> unitCodes, List<FilterCriteria> filterCriteria);

  List<Agent> findAllByEmailAddress(
    @Valid
    @NotBlank(message = "Email address cannot be blank")
    @Email(message = "Email address is invalid")
      String emailAddress);
}
