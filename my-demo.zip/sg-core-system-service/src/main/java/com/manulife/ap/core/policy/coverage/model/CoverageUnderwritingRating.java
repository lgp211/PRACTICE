package com.manulife.ap.core.policy.coverage.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CoverageUnderwritingRating {
  String policyNumber;
  String planCode;
  String planVersion;
  String code;

  public boolean isKeyMatching(CoverageUnderwritingKey coverageUnderwritingKey) {
    return this.policyNumber.equals(coverageUnderwritingKey.getPolicyNumber()) &&
      this.planCode.equals(coverageUnderwritingKey.getPlanCode()) &&
      this.planVersion.equals(coverageUnderwritingKey.getPlanVersion());
  }
}
