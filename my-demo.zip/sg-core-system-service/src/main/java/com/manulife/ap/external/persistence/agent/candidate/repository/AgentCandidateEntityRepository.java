package com.manulife.ap.external.persistence.agent.candidate.repository;

import com.manulife.ap.external.persistence.agent.candidate.model.AgentCandidateEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AgentCandidateEntityRepository extends JpaRepository<AgentCandidateEntity, String> {
}
