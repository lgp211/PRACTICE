package com.manulife.ap.core.fund.summary.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FundSummary {
  private String fundId;
  private String fundVersion;
  private String policyNumber;
  private Double fundBalance;

  public boolean isKeyMatching(FundSummaryKey fundSummaryKey) {
    return this.fundId.equals(fundSummaryKey.getFundId()) &&
      this.fundVersion.equals(fundSummaryKey.getFundVersion());
  }
}
