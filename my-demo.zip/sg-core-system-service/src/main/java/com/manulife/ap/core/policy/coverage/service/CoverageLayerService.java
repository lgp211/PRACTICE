package com.manulife.ap.core.policy.coverage.service;

import com.manulife.ap.core.policy.coverage.model.CoverageLayer;
import com.manulife.ap.core.policy.coverage.model.CoverageLayerKey;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface CoverageLayerService {
  Map<CoverageLayerKey, List<CoverageLayer>> findAllByCoverageLayerKeyIn(Set<CoverageLayerKey> coverageLayerKeys);
}