package com.manulife.ap.core.agent.root.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum AgentFilter {

  UNIT_CODE ("unitCode"),
  STATUS ("status");

  private final String name;
}
