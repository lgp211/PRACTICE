package com.manulife.ap.core.policy.fund.service;

import com.manulife.ap.core.policy.fund.model.PolicyFundAllocation;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class PolicyFundAllocationManager implements PolicyFundAllocationService {

  private final PolicyFundAllocationRepository policyFundAllocationRepository;

  @Override
  public Map<String, List<PolicyFundAllocation>> findAllByPolicyNumbers(final Set<String> policyNumbers) {
    return Optional.ofNullable(policyNumbers)
      .map(list -> policyFundAllocationRepository.findAllByPolicyNumbers(list)
        .parallelStream()
        .collect(groupingBy(PolicyFundAllocation::getPolicyNumber))
      )
      .orElse(Collections.emptyMap());
  }
}
