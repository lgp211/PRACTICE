package com.manulife.ap.core.agent.hierarchy.service;

import com.manulife.ap.core.agent.hierarchy.model.Agency;

import java.util.List;
import java.util.Map;

public interface AgentHierarchyService {
  List<Agency> findAllAgenciesByAgencyCodeIn(List<String> agencyCodes);

  Map<String, List<Agency>> findAllAgenciesByManagerIn(List<String> managerAgentCodes);

  List<Agency> findAllUnitAgenciesByBranchCode(String branchCode);
}
