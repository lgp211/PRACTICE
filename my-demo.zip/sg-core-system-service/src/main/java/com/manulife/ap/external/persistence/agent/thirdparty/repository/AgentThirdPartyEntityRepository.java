package com.manulife.ap.external.persistence.agent.thirdparty.repository;

import com.manulife.ap.external.persistence.agent.thirdparty.model.AgentThirdPartyEntity;
import com.manulife.ap.external.persistence.agent.thirdparty.model.AgentThirdPartyId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AgentThirdPartyEntityRepository extends JpaRepository<AgentThirdPartyEntity, AgentThirdPartyId> {
  List<AgentThirdPartyEntity> findAllByIdThirdPartyIdIn(List<String> thirdPartyIds);
  List<AgentThirdPartyEntity> findAllByIdAgentCodeIn(List<String> agentCodes);
}
