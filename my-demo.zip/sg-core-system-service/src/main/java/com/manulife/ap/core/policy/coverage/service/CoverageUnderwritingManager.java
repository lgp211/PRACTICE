package com.manulife.ap.core.policy.coverage.service;

import com.manulife.ap.core.policy.coverage.model.CoverageUnderwriting;
import com.manulife.ap.core.policy.coverage.model.CoverageUnderwritingKey;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class CoverageUnderwritingManager implements CoverageUnderwritingService {

  @Override
  public Map<CoverageUnderwritingKey, CoverageUnderwriting> findAllByUnderwritingKeyIn(final Set<CoverageUnderwritingKey> keys) {
    if (Objects.isNull(keys) || keys.isEmpty()) {
      return Collections.emptyMap();
    }

    Map<CoverageUnderwritingKey, CoverageUnderwriting> underwritingMap = new HashMap<>();

    keys.forEach(key ->
      underwritingMap.put(key,
        CoverageUnderwriting.builder()
          .policyNumber(key.getPolicyNumber())
          .planCode(key.getPlanCode())
          .planVersion(key.getPlanVersion()).build())
    );

    return underwritingMap;
  }
}