package com.manulife.ap.external.persistence.policy.role;

import com.manulife.ap.core.policy.role.model.PolicyRole;
import com.manulife.ap.core.policy.role.service.PolicyRoleRepository;
import com.manulife.ap.external.persistence.policy.role.model.mapper.PolicyRoleEntityMapper;
import com.manulife.ap.external.persistence.policy.role.repository.PolicyRoleEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Component
@RequiredArgsConstructor
public class PolicyRoleJpaRepository implements PolicyRoleRepository {
  private final PolicyRoleEntityRepository policyRoleEntityRepository;

  @Override
  public List<PolicyRole> findAllByPolicyNumbers(Set<String> policyNumbers) {
    return Optional.ofNullable(policyNumbers)
      .map(policyRoleEntityRepository::findAllByIdPolicyNumberIn)
      .map(entityList -> PolicyRoleEntityMapper.get().toPolicyRoleList(entityList))
      .orElse(Collections.emptyList());
  }
}
