package com.manulife.ap.external.persistence.agent.production.model.mapper;

import com.manulife.ap.common.mapper.LocalDateMapper;
import com.manulife.ap.common.mapper.LocalDateMapping;
import com.manulife.ap.common.mapper.StringToLocalDate;
import com.manulife.ap.core.agent.production.model.AgentProductionDetails;
import com.manulife.ap.external.persistence.agent.production.model.AgentProductionDetailsEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = {LocalDateMapping.class})
public interface AgentProductionDetailsEntityMapper {
  static AgentProductionDetailsEntityMapper get() {
    return AgentProductionDetailsEntityMapper.ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final AgentProductionDetailsEntityMapper INSTANCE =
      Mappers.getMapper(AgentProductionDetailsEntityMapper.class);
    private ModelMapperInstance() {}
  }

  @Mapping(target = "month", source = "entity.id.productionMonth")
  @Mapping(target = "agentCode", source = "entity.id.agentCode")
  @Mapping(target = "policyNumber", source = "entity.id.policyNumber")
  @Mapping(target = "planCode", source = "entity.id.planCode")
  @Mapping(target = "planName", source = "entity.planName")
  @Mapping(target = "currencyCode", source = "entity.currencyCode")
  @Mapping(target = "date", source = "entity.id.date", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "description", source = "entity.id.description")
  @Mapping(target = "tagging.unitCode", source = "entity.taggingUnitCode")
  @Mapping(target = "tagging.branchCode", source = "entity.taggingBranchCode")
  @Mapping(target = "reporting.unitCode", source = "entity.reportingUnitCode")
  @Mapping(target = "reporting.branchCode", source = "entity.reportingBranchCode")
  @Mapping(target = "conservation.type", source = "entity.id.conservationType")
  @Mapping(target = "nac.newBusiness", source = "entity.nac")
  @Mapping(target = "nac.reinstatement", source = "entity.reinstatement")
  @Mapping(target = "nac.adjustment", source = "entity.adjustment")
  @Mapping(target = "nac.lapsed", source = "entity.lapsed")
  @Mapping(target = "nac.rescinded", source = "entity.rescinded")
  @Mapping(target = "nac.netTotal", source = "entity.netTotal")
  @Mapping(target = "nac.grossTotal", source = "entity.grossTotal")
  @Mapping(target = "caseCount.newBusiness", source = "entity.caseCount")
  @Mapping(target = "caseCount.reinstatement", source = "entity.reinstatementCaseCount")
  @Mapping(target = "caseCount.lapsed", source = "entity.lapsedCaseCount")
  @Mapping(target = "caseCount.rescinded", source = "entity.rescindedCaseCount")
  @Mapping(target = "caseCount.netTotal", source = "entity.netCaseCount")
  AgentProductionDetails toAgentProductionDetails(AgentProductionDetailsEntity entity);
}
