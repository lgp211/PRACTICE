package com.manulife.ap.external.persistence.customer.root.model.mapper;

import com.manulife.ap.common.mapper.*;
import com.manulife.ap.core.customer.root.model.Customer;
import com.manulife.ap.core.customer.root.model.CustomerPhone;
import com.manulife.ap.core.customer.root.model.CustomerPhoneType;
import com.manulife.ap.external.persistence.customer.root.model.CustomerEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import org.mapstruct.AfterMapping;
import org.mapstruct.MappingTarget;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Mapper(uses = {LocalDateMapping.class})
public interface CustomerEntityMapper {
  static CustomerEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final CustomerEntityMapper INSTANCE = Mappers.getMapper(CustomerEntityMapper.class);
    private ModelMapperInstance() {}
  }

  @Mapping(target = "clientNumber", source = "entity.clientNumber")
  @Mapping(target = "name.fullName", source = "entity.name")
  @Mapping(target = "identity.number", source = "entity.identityNumber")
  @Mapping(target = "identity.type.code", source = "entity.identityType")
  @Mapping(target = "gender.code", source = "entity.sexCode")
  @Mapping(target = "dob", source = "entity.birthDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  Customer toCustomer(CustomerEntity entity);

  @AfterMapping
  default void postMapping(CustomerEntity customerEntity, @MappingTarget Customer customer) {
    customer.setPhones(
      Stream
        .of(
          CustomerPhone.builder()
            .type(CustomerPhoneType.PRIMARY.toString())
            .countryCode(customerEntity.getPrimaryPhoneCountryCode())
            .number(customerEntity.getPrimaryPhoneNumber())
            .build(),
          CustomerPhone.builder()
            .type(CustomerPhoneType.MOBILE.toString())
            .countryCode(customerEntity.getMobilePhoneCountryCode())
            .number(customerEntity.getMobilePhoneNumber())
            .build(),
          CustomerPhone.builder()
            .type(CustomerPhoneType.OTHER.toString())
            .countryCode(customerEntity.getOtherPhoneCountryCode())
            .number(customerEntity.getOtherPhoneNumber())
            .build(),
          CustomerPhone.builder()
            .type(CustomerPhoneType.FAX.toString())
            .countryCode(customerEntity.getFaxPhoneNumber())
            .number(customerEntity.getFaxPhoneNumber())
            .build()
        )
        .filter(e -> Objects.nonNull(e.getCountryCode()))
        .collect(Collectors.toList())
    );
  }
}
