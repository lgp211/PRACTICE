package com.manulife.ap.external.persistence.fund.root.repository;

import com.manulife.ap.external.persistence.fund.root.model.FundEntity;
import com.manulife.ap.external.persistence.fund.root.model.FundId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface FundEntityRepository extends JpaRepository<FundEntity, FundId> {
  List<FundEntity> findAllByIdFundIdIn(Set<String> fundIds);
}