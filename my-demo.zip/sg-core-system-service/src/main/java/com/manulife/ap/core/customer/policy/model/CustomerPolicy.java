package com.manulife.ap.core.customer.policy.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomerPolicy {
  private String clientNumber;
  private String policyNumber;
  private CustomerPolicyLinkType linkType;
  private String correspondingAddressType;
  private String residentialAddressType;
}
