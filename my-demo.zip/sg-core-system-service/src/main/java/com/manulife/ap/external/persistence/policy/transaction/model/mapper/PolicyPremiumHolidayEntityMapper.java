package com.manulife.ap.external.persistence.policy.transaction.model.mapper;

import com.manulife.ap.common.mapper.LocalDateMapper;
import com.manulife.ap.common.mapper.LocalDateMapping;
import com.manulife.ap.common.mapper.StringToLocalDate;
import com.manulife.ap.core.policy.transaction.model.PolicyPremiumHoliday;
import com.manulife.ap.external.persistence.policy.transaction.model.PolicyPremiumHolidayEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Collection;
import java.util.List;

@Mapper(uses = LocalDateMapping.class)
public interface PolicyPremiumHolidayEntityMapper {

  static PolicyPremiumHolidayEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final PolicyPremiumHolidayEntityMapper INSTANCE = Mappers.getMapper(PolicyPremiumHolidayEntityMapper.class);

    private ModelMapperInstance() {
    }
  }
  @Mapping(target = "policyNumber", source = "entity.id.policyNumber")
  @Mapping(target = "fromDate", source = "entity.id.fromDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "transactionId", source = "entity.id.transactionId")
  @Mapping(target = "transactionDate", source = "entity.transactionDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "undoTransactionId", source = "entity.undoTransactionId")
  @Mapping(target = "toDate", source = "entity.toDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "paidToDate", source = "entity.paidToDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "lastPaidToDate", source = "entity.lastPaidToDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "type", source = "entity.type")
  @Mapping(target = "phPaidToDate", source = "entity.phPaidToDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "phLastPaidToDate", source = "entity.phLastPaidToDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  PolicyPremiumHoliday toPolicyPremiumHoliday(PolicyPremiumHolidayEntity entity);

  List<PolicyPremiumHoliday> toPolicyPremiumHolidayList(Collection<PolicyPremiumHolidayEntity> policyPremiumHolidayList);

}
