package com.manulife.ap.core.policy.beneficiary.service;

import com.manulife.ap.core.policy.beneficiary.model.PolicyBeneficiary;

import java.util.List;
import java.util.Set;

public interface PolicyBeneficiaryRepository {
  List<PolicyBeneficiary> findAllByPolicyNumberIn(Set<String> policyNumbers);
}
