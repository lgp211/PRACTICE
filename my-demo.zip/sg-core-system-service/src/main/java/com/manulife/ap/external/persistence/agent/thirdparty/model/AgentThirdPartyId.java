package com.manulife.ap.external.persistence.agent.thirdparty.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Embeddable
public class AgentThirdPartyId implements Serializable {
  @Column(name = "AGT_CODE")
  private String agentCode;

  @Column(name = "AVIVA_AGT_CD")
  private String thirdPartyId;

  @Column(name = "CO_CD")
  private String thirdPartyCompanyCode;

  @Column(name = "CPNY_ID")
  private String companyId;
}
