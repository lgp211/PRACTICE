package com.manulife.ap.core.systemuser.root.service;

import com.manulife.ap.core.systemuser.root.model.SystemUser;

import java.util.List;

public interface SystemUserService {
  List<SystemUser> findByUserIds(List<String> userIds);
}
