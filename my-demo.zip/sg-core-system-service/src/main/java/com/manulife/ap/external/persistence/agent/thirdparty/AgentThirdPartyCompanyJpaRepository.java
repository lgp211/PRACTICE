package com.manulife.ap.external.persistence.agent.thirdparty;

import com.manulife.ap.core.agent.thirdparty.model.AgentThirdPartyCompany;
import com.manulife.ap.core.agent.thirdparty.model.AgentThirdPartyCompanyKey;
import com.manulife.ap.core.agent.thirdparty.service.AgentThirdPartyCompanyRepository;
import com.manulife.ap.external.persistence.agent.thirdparty.model.AgentThirdPartyCompanyId;
import com.manulife.ap.external.persistence.agent.thirdparty.model.mapper.AgentThirdPartyCompanyEntityMapper;
import com.manulife.ap.external.persistence.agent.thirdparty.repository.AgentThirdPartyCompanyEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class AgentThirdPartyCompanyJpaRepository implements AgentThirdPartyCompanyRepository {
  private final AgentThirdPartyCompanyEntityRepository agentThirdPartyCompanyEntityRepository;

  @Override
  public List<AgentThirdPartyCompany> findAllByKeyIn(List<AgentThirdPartyCompanyKey> keys) {
    if (Objects.isNull(keys) || keys.isEmpty()) {
      return Collections.emptyList();
    }

    return agentThirdPartyCompanyEntityRepository
      .findAllByIdIn(
        keys.stream()
          .map(key -> AgentThirdPartyCompanyId.builder().companyCode(key.getCode()).companyId(key.getId()).build())
          .collect(Collectors.toList())
      )
      .parallelStream()
      .map(companyEntity -> AgentThirdPartyCompanyEntityMapper.get().toAgentThirdPartyCompany(companyEntity))
      .collect(Collectors.toList());
  }
}
