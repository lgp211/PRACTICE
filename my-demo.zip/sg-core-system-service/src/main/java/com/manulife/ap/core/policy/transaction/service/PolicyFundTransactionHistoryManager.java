package com.manulife.ap.core.policy.transaction.service;

import com.manulife.ap.core.policy.transaction.model.PolicyFundTransactionHistory;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class PolicyFundTransactionHistoryManager implements PolicyFundTransactionHistoryService {

  private final PolicyFundTransactionHistoryRepository policyFundTransactionHistoryRepository;

  @Override
  public Map<String, List<PolicyFundTransactionHistory>> findAllByPolicyNumbers(final Set<String> policyNumbers) {
    return Optional.ofNullable(policyNumbers)
      .map(list -> policyFundTransactionHistoryRepository.findAllByPolicyNumbers(list)
        .parallelStream()
        .collect(groupingBy(PolicyFundTransactionHistory::getPolicyNumber))
      )
      .orElse(Collections.emptyMap());
  }
}
