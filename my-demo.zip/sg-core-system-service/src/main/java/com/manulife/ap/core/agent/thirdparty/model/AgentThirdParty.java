package com.manulife.ap.core.agent.thirdparty.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AgentThirdParty {
  private String id;
  private AgentThirdPartyCompany company;
  private String agentCode;
}
