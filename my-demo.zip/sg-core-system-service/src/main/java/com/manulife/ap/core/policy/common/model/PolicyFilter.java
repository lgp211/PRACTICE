package com.manulife.ap.core.policy.common.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum PolicyFilter {
  STATUS,
  PRIMARY_SERVICING_AGENT,
  PAID_TO_DATE_RANGE;
}
