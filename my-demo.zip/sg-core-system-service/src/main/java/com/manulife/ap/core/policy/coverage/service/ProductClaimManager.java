package com.manulife.ap.core.policy.coverage.service;

import com.manulife.ap.common.util.StreamUtil;
import com.manulife.ap.core.policy.coverage.model.ProductClaim;
import com.manulife.ap.core.policy.coverage.model.ProductClaimGroup;
import com.manulife.ap.core.policy.coverage.model.ProductClaimType;
import com.manulife.ap.core.policy.coverage.model.ProductPlanKey;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class ProductClaimManager implements ProductClaimService {

  private final ProductClaimRepository productClaimRepository;

  private final ProductClaimGroupRepository productClaimGroupRepository;

  @Override
  public Map<ProductPlanKey, List<ProductClaim>> findClaimsByProductPlanKeys(final Set<ProductPlanKey> planKeys) {
    if (Objects.isNull(planKeys) || planKeys.isEmpty()) {
      return Collections.emptyMap();
    }

    HashMap<ProductPlanKey, List<ProductClaim>> claimMap = new HashMap<>();
    List<ProductClaim> productClaims = productClaimRepository.findByProductPlanKeys(planKeys);

    productClaims.forEach(productClaim ->
      claimMap.computeIfAbsent(
        ProductPlanKey.builder()
          .planCode(productClaim.getPlanCode())
          .planVersion(productClaim.getPlanVersion())
          .build(),
          k -> new ArrayList<>()
      ).add(productClaim)
    );

    return claimMap;
  }

  /**
   * This method is not in use due to business logic change.
   * @return Map of product claim group
   */
  public Map<ProductPlanKey, List<ProductClaim>> findClaimGroupsByProductPlanKeys(final Set<ProductPlanKey> planKeys,
                                                                                  List<ProductClaim> productClaims){
    HashMap<ProductPlanKey, List<ProductClaim>> claimMap = new HashMap<>();

    Set<ProductPlanKey> foundClaimsForPlanKeys =
      productClaims.stream()
        .map(foundClaim -> ProductPlanKey.builder()
          .planCode(foundClaim.getPlanCode())
          .planVersion(foundClaim.getPlanVersion())
          .build()
        )
        .collect(Collectors.toSet());

    Set<ProductPlanKey> remainingPlanKeys = new HashSet<>(planKeys);
    remainingPlanKeys.removeAll(foundClaimsForPlanKeys);
    List<ProductClaimGroup> productClaimGroups = productClaimGroupRepository.findByProductPlanKeys(remainingPlanKeys);

    Set<ProductPlanKey> planKeysForGroup =
      productClaimGroups.stream()
        .filter(StreamUtil.distinctByKey(ProductClaimGroup::getPlanGroupName))
        .map(foundClaimGroup -> ProductPlanKey.builder()
          .planCode(foundClaimGroup.getPlanGroupName())
          .planVersion("*")
          .build())
        .collect(Collectors.toSet());

    List<ProductClaim> productClaimsGroupSetup = productClaimRepository.findByProductPlanKeys(planKeysForGroup);

    List<ProductClaim> productClaimFromGroup = new ArrayList<>();
    productClaimGroups.forEach(group ->
      productClaimFromGroup.addAll(constructStandardClaimTypes(productClaimsGroupSetup, group))
    );

    List<ProductClaim> mergedProductClaims =
      Stream
        .concat(productClaims.stream(), productClaimFromGroup.stream())
        .collect(Collectors.toList());

    mergedProductClaims.forEach(productClaim ->
      claimMap.computeIfAbsent(
        ProductPlanKey.builder()
          .planCode(productClaim.getPlanCode())
          .planVersion(productClaim.getPlanVersion())
          .build(),
        k -> new ArrayList<>()
      ).add(productClaim)
    );

    return claimMap;
  }

  public List<ProductClaim> constructStandardClaimTypes(List<ProductClaim> groupSetup, ProductClaimGroup productClaimGroup) {
    if (Objects.isNull(groupSetup) || groupSetup.isEmpty() ||
      Objects.isNull(productClaimGroup) || StringUtils.isEmpty(productClaimGroup.getPlanCode()) ||
      StringUtils.isEmpty(productClaimGroup.getPlanVersion())) {
      return Collections.emptyList();
    }

    return groupSetup.stream()
      .map(claimType ->  ProductClaim.builder()
        .planCode(productClaimGroup.getPlanCode())
        .planVersion(productClaimGroup.getPlanVersion())
        .type(ProductClaimType.builder().code(claimType.getType().getCode()).build())
        .version(claimType.getVersion())
        .build()
      )
      .collect(Collectors.toList());
  }
}
