package com.manulife.ap.external.persistence.agent.hierarchy.model.mapper;

import com.manulife.ap.common.mapper.LocalDateMapper;
import com.manulife.ap.common.mapper.LocalDateMapping;
import com.manulife.ap.common.mapper.StringToLocalDate;
import com.manulife.ap.core.agent.hierarchy.model.Agency;
import com.manulife.ap.external.persistence.agent.hierarchy.model.AgentStructureGroupEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = LocalDateMapping.class)
public interface AgentStructureGroupEntityMapper {
  static AgentStructureGroupEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final AgentStructureGroupEntityMapper INSTANCE =
      Mappers.getMapper(AgentStructureGroupEntityMapper.class);
    private ModelMapperInstance() {}
  }

  @Mapping(target = "code", source = "entity.code")
  @Mapping(target = "name", source = "entity.name")
  @Mapping(target = "type.code", source = "entity.type")
  @Mapping(target = "managerAgentCode", source = "entity.managerCode")
  @Mapping(target = "status.code", source = "entity.statusCode")
  @Mapping(target = "terminationDate", source = "entity.terminationDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "channel.code", source = "entity.unitType")
  @Mapping(target = "zone.code", source = "entity.zoneCode")
  Agency toAgency(AgentStructureGroupEntity entity);
}
