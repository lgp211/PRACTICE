package com.manulife.ap.external.persistence.policy.coverage.repository;

import com.manulife.ap.external.persistence.policy.coverage.model.ProductClaimGroupEntity;
import com.manulife.ap.external.persistence.policy.coverage.model.ProductClaimGroupId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Set;

public interface ProductClaimGroupEntityRepository extends JpaRepository<ProductClaimGroupEntity, ProductClaimGroupId> {
  List<ProductClaimGroupEntity> findAllByIdIn(Set<ProductClaimGroupId> productClaimGroupId);
}
