package com.manulife.ap.external.persistence.agent.root.model.mapper;

import com.manulife.ap.core.agent.root.model.AgentRank;
import com.manulife.ap.external.persistence.agent.root.model.AgentRankEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AgentRankEntityMapper {
  static AgentRankEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final AgentRankEntityMapper INSTANCE = Mappers.getMapper(AgentRankEntityMapper.class);
    private ModelMapperInstance() {}
  }

  @Mapping(target = "code", source = "entity.code")
  @Mapping(target = "description", source = "entity.description")
  AgentRank toAgentRank(AgentRankEntity entity);
}
