package com.manulife.ap.external.persistence.policy.financial.repository;

import com.manulife.ap.external.persistence.policy.financial.model.PolicyFinancialEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;


@Repository
public interface PolicyFinancialEntityRepository extends JpaRepository<PolicyFinancialEntity, String> {

  @Transactional(propagation = Propagation.REQUIRES_NEW)
  @Procedure(name = "nfoCalcWrapper")
  Map<String, Object> nfoCalcWrapper(@Param("policyNumber") String policyNumber);
}
