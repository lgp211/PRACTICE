package com.manulife.ap.core.common.model;

import joptsimple.internal.Strings;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@Builder
public class FilterCriteria implements Serializable {

  @NotBlank(message = "Key cannot be blank")
  private String key;
  @NotBlank(message = "Value cannot be blank")
  private String value;
  private FilterValueDataType valueDataType;
  @NotNull(message = "Operation cannot be null")
  private FilterOperation operation;

  public List<String> getValueAsList() {
    if (Strings.isNullOrEmpty(Objects.toString(value, null))) {
      return Collections.emptyList();
    }

    return Arrays
      .stream(this.value.split(","))
      .map(String::trim)
      .collect(Collectors.toList());
  }
}
