package com.manulife.ap.external.persistence.agent.hierarchy.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "TAMS_STRU_GROUPS")
public class AgentStructureGroupEntity {

  @Id
  @Column(name = "STRU_GRP_CD")
  private String code;

  @Column(name = "STRU_GRP_NM")
  private String name;

  @Column(name = "STRU_GRP_TYP")
  private String type;

  @Column(name = "MGR_CD")
  private String managerCode;

  @Column(name = "STAT_CD")
  private String statusCode;

  @Column(name = "TRMN_DT")
  private String terminationDate;

  @Column(name = "UNIT_TYP")
  private String unitType;

  @Column(name = "ZONE_CD")
  private String zoneCode;

}
