package com.manulife.ap.core.policy.root.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PremiumHoliday {
  private PremiumFreezeStatus freezeStatus;
  private String type;
  private LocalDate startDate;
  private LocalDate endDate;
  private LocalDate paidToDate;
  private LocalDate lastPaidToDate;
}
