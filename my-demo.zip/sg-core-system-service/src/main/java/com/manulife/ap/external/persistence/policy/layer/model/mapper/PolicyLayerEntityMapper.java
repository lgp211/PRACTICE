package com.manulife.ap.external.persistence.policy.layer.model.mapper;

import com.manulife.ap.common.mapper.LocalDateMapper;
import com.manulife.ap.common.mapper.LocalDateMapping;
import com.manulife.ap.common.mapper.StringToLocalDate;
import com.manulife.ap.core.policy.layer.model.PolicyLayer;
import com.manulife.ap.external.persistence.policy.layer.model.PolicyLayerEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Collection;
import java.util.List;

@Mapper(uses = LocalDateMapping.class)
public interface PolicyLayerEntityMapper {

  static PolicyLayerEntityMapper get() {
    return PolicyLayerEntityMapper.ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final PolicyLayerEntityMapper INSTANCE = Mappers.getMapper(PolicyLayerEntityMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "policyNumber", source = "policyLayer.id.policyNumber")
  @Mapping(target = "type.code", source = "policyLayer.id.type")
  @Mapping(target = "effectiveDate", source = "policyLayer.id.effectiveDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "premium.amount", source = "policyLayer.amount")
  @Mapping(target = "premium.percentage", source = "policyLayer.percentage")
  @Mapping(target = "premium.paidAmount", source = "policyLayer.paidAmount")
  PolicyLayer toPolicyLayer(PolicyLayerEntity policyLayer);

  List<PolicyLayer> toPolicyLayerList(Collection<PolicyLayerEntity> policyLayerEntityList);
}
