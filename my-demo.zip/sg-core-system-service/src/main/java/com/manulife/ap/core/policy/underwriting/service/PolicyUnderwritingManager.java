package com.manulife.ap.core.policy.underwriting.service;

import com.manulife.ap.core.policy.underwriting.model.PolicyUnderwriting;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
public class PolicyUnderwritingManager implements PolicyUnderwritingService {

  @Override
  public Map<String, PolicyUnderwriting> findAllByPolicyNumbers(final Set<String> policyNumbers) {
    if (Objects.isNull(policyNumbers) || policyNumbers.isEmpty()) {
      return Collections.emptyMap();
    }

    Map<String, PolicyUnderwriting> underwritingMap = new HashMap<>();
    policyNumbers.forEach(policyNumber ->
      underwritingMap.put(policyNumber, PolicyUnderwriting.builder().policyNumber(policyNumber).build())
    );

    return underwritingMap;
  }
}
