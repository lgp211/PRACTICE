package com.manulife.ap.external.persistence.policy.coverage.model.mapper;

import com.manulife.ap.core.policy.coverage.model.ProductClaimGroup;
import com.manulife.ap.external.persistence.policy.coverage.model.ProductClaimGroupEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ProductClaimGroupEntityMapper {

  static ProductClaimGroupEntityMapper getInstance() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final ProductClaimGroupEntityMapper INSTANCE = Mappers.getMapper(ProductClaimGroupEntityMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "planCode", source = "productClaimGroup.id.planCode")
  @Mapping(target = "planVersion", source = "productClaimGroup.id.planVersion")
  @Mapping(target = "planGroupName", source = "productClaimGroup.planGroupName")
  @Mapping(target = "planGroupType", source = "productClaimGroup.planGroupType")
  ProductClaimGroup toProductClaimGroup(ProductClaimGroupEntity productClaimGroup);
}
