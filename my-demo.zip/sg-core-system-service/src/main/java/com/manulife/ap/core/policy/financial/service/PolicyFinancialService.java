package com.manulife.ap.core.policy.financial.service;

import com.manulife.ap.core.policy.financial.model.PolicyFinancial;

import java.util.Map;
import java.util.Set;

public interface PolicyFinancialService {
  Map<String, PolicyFinancial> findByPolicyNumbers(Set<String> policyNumbers);
}
