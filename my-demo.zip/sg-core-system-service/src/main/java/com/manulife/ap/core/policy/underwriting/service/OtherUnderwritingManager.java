package com.manulife.ap.core.policy.underwriting.service;

import com.manulife.ap.core.policy.underwriting.model.OtherUnderwriting;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class OtherUnderwritingManager implements OtherUnderwritingService {

  private final OtherUnderwritingRepository otherUnderwritingRepository;

  @Override
  public Map<String, List<OtherUnderwriting>> findAllByPolicyNumbers(final Set<String> policyNumbers) {
    if (Objects.isNull(policyNumbers) || policyNumbers.isEmpty()) {
      return Collections.emptyMap();
    }

    return otherUnderwritingRepository.findAllByPolicyNumbers(policyNumbers)
      .parallelStream()
      .collect(groupingBy(OtherUnderwriting::getPolicyNumber));
  }
}
