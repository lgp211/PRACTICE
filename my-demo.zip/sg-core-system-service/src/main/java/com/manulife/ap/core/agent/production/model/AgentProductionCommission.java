package com.manulife.ap.core.agent.production.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AgentProductionCommission {
  private String month;
  private String agentCode;
  private String policyNumber;
  private String planCode;
  private String planType;
  private String planName;
  private String currencyCode;
  private boolean soldToFamily;
  private String description;
  private double splitRatio;
  private AgentProductionStructure tagging;
  private AgentProductionStructure reporting;
  private AgentProductionCommissionSummary singlePremium;
  private AgentProductionCommissionSummary regularPremium;
  private AgentProductionCommissionSummary total;
}
