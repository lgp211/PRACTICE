package com.manulife.ap.core.fund.summary.service;

import com.manulife.ap.core.fund.summary.model.FundSummary;
import com.manulife.ap.core.fund.summary.model.FundSummaryKey;

import java.util.Map;
import java.util.Set;

public interface FundSummaryService {
  Map<FundSummaryKey, FundSummary> findAllByFundSummaryKeyIn(Set<FundSummaryKey> fundSummaryKeys);
}