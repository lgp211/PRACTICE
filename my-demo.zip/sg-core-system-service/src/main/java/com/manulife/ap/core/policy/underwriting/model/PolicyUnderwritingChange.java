package com.manulife.ap.core.policy.underwriting.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyUnderwritingChange {
  private String policyNumber;
  private Integer posNumber;
  private LocalDate submissionDate;
  private ChangeStatus status;
  private String departmentType;
}
