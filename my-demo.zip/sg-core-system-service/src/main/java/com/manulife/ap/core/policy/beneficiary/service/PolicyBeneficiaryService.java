package com.manulife.ap.core.policy.beneficiary.service;

import com.manulife.ap.core.policy.beneficiary.model.PolicyBeneficiary;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface PolicyBeneficiaryService {
  Map<String, List<PolicyBeneficiary>> findAllByPolicyNumbersIn(final Set<String> policyNumbers);
}
