package com.manulife.ap.core.agent.candidate.service;

import com.manulife.ap.core.agent.candidate.model.AgentCandidate;

import java.util.List;

public interface AgentCandidateRepository {
  List<AgentCandidate> findAllByCandidateNumberIn(List<String> candidateNumbers);
}
