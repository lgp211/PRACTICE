package com.manulife.ap.core.product.configuration.service;

import com.manulife.ap.core.product.configuration.model.ProductConfigurationCategory;
import com.manulife.ap.core.product.configuration.model.ProductConfigurationField;
import com.manulife.ap.core.product.root.model.ProductKey;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class ProductConfigurationFieldManager implements ProductConfigurationFieldService {

  private final ProductConfigurationFieldRepository repository;

  @Override
  public List<ProductConfigurationField> findAllByProductKey(
    final Set<ProductKey> productKeyList, final ProductConfigurationCategory category) {

    return Optional.ofNullable(productKeyList)
      .map(list -> repository.findAllByProductKey(productKeyList, category))
      .orElse(Collections.emptyList());
  }
}
