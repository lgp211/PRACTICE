package com.manulife.ap.core.policy.underwriting.service;

import com.manulife.ap.core.policy.underwriting.model.SupplementaryQuestion;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface SupplementaryQuestionService {
  Map<String, List<SupplementaryQuestion>> findAllByPolicyNumbers(Set<String> policyNumbers);
}
