package com.manulife.ap.core.policy.underwriting.service;

import com.manulife.ap.core.policy.underwriting.model.MedicalRequirementRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class MedicalRequirementRequestManager implements MedicalRequirementRequestService {

  private final MedicalRequirementRequestRepository medicalRequirementRequestRepository;

  @Override
  public Map<String, List<MedicalRequirementRequest>> findAllByPolicyNumbers(final Set<String> policyNumbers) {
    if (Objects.isNull(policyNumbers) || policyNumbers.isEmpty()) {
      return Collections.emptyMap();
    }

    return medicalRequirementRequestRepository.findAllByPolicyNumbers(policyNumbers)
      .parallelStream()
      .collect(groupingBy(MedicalRequirementRequest::getPolicyNumber));
  }
}
