package com.manulife.ap.external.persistence.agent.hierarchy.repository;

import com.manulife.ap.external.persistence.agent.hierarchy.model.AgentStructureGroupEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AgentStructureGroupEntityRepository extends JpaRepository<AgentStructureGroupEntity, String> {
  List<AgentStructureGroupEntity> findAllByManagerCodeIn(List<String> managerAgentCodes);
}
