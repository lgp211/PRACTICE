package com.manulife.ap.core.policy.transaction.service;

import com.manulife.ap.core.policy.transaction.model.PolicyPremiumTransaction;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class PolicyPremiumTransactionManager implements PolicyPremiumTransactionService {

  private final PolicyPremiumTransactionRepository policyTransactionRepository;

  @Override
  public Map<String, List<PolicyPremiumTransaction>> findPremiumTransactionsByPolicyNumbers(final Set<String> policyNumbers) {
    if (Objects.isNull(policyNumbers) || policyNumbers.isEmpty()) {
      return Collections.emptyMap();
    }

    return policyTransactionRepository.findPremiumTransactionsByPolicyNumbers(policyNumbers)
      .parallelStream()
      .collect(groupingBy(PolicyPremiumTransaction::getPolicyNumber));
  }
}
