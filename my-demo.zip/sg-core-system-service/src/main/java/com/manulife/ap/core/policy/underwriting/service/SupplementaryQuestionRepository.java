package com.manulife.ap.core.policy.underwriting.service;

import com.manulife.ap.core.policy.underwriting.model.SupplementaryQuestion;

import java.util.List;
import java.util.Set;

public interface SupplementaryQuestionRepository {
  List<SupplementaryQuestion> findAllByPolicyNumbers(Set<String> policyNumbers);
}
