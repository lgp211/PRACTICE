package com.manulife.ap.external.persistence.policy.role.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyRoleId implements Serializable {
  @Column(name = "POL_NUM")
  private String policyNumber;
  @Column(name = "CLI_NUM")
  private String clientNumber;
  @Column(name = "LINK_TYP")
  private String clientPolicyLinkType;
}
