package com.manulife.ap.core.common.model;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Slf4j
@Getter(value = AccessLevel.PACKAGE)
public class DomainDataMap<T> {
  private final Map<T, String> dataMap = new HashMap<>();

  /**
   * Set the key and associated value into data map in fluent interface approach.
   *
   * @param fieldType Domain field type
   * @param value Value in string
   * @return Domain data map instance
   */
  public DomainDataMap<T> put(T fieldType, String value) {
    if (Objects.nonNull(fieldType)) {
      this.dataMap.put(fieldType, value);
    }
    return this;
  }

  /**
   * Return associated value in String format.
   *
   * @param fieldType Key for the associated value
   * @return associated value in String format.
   */
  public String stringOf(T fieldType) {
    return dataMap.get(fieldType);
  }

  /**
   * Return associated value in {@link java.time.LocalDate} format.
   *
   * @param fieldType Key for the associated value
   * @return associated value in {@link java.time.LocalDate} format.
   * @see java.time.LocalDate
   */
  public LocalDate localDateOf(T fieldType) {
    try {
      return LocalDate.parse(dataMap.get(fieldType));
    } catch (DateTimeParseException | NullPointerException e) {
      log.error("Date Parsing Exception: input={}", dataMap.get(fieldType));
      return null;
    }
  }
}
