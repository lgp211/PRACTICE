package com.manulife.ap.core.agent.candidate.service;

import com.manulife.ap.core.agent.candidate.model.AgentCandidate;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class AgentCandidateManager implements AgentCandidateService {
  private final AgentCandidateRepository agentCandidateRepository;

  @Override
  public List<AgentCandidate> findAllByCandidateNumberIn(List<String> candidateNumbers) {
    if (Objects.isNull(candidateNumbers) || candidateNumbers.isEmpty()) {
      return Collections.emptyList();
    }

    return agentCandidateRepository.findAllByCandidateNumberIn(candidateNumbers);
  }
}
