package com.manulife.ap.core.policy.underwriting.service;

import com.manulife.ap.core.policy.underwriting.model.PremiumIssue;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface PremiumIssueService {
  Map<String, List<PremiumIssue>> findAllByPolicyNumbers(Set<String> policyNumbers);
}
