package com.manulife.ap.core.agent.thirdparty.service;

import com.manulife.ap.core.agent.thirdparty.model.AgentThirdParty;

import java.util.List;

public interface AgentThirdPartyRepository {
  List<AgentThirdParty> findAllByIdIn(List<String> thirdPartyIds);
  List<AgentThirdParty> findAllByAgentCodeIn(List<String> agentCodes);
}
