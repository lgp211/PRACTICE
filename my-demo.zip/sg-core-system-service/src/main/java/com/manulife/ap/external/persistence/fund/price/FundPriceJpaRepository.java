package com.manulife.ap.external.persistence.fund.price;

import com.manulife.ap.core.fund.price.model.FundPrice;
import com.manulife.ap.core.fund.price.model.FundPriceKey;
import com.manulife.ap.core.fund.price.service.FundPriceRepository;
import com.manulife.ap.external.persistence.fund.price.model.FundPriceEntity;
import com.manulife.ap.external.persistence.fund.price.model.mapper.FundPriceEntityMapper;
import com.manulife.ap.external.persistence.fund.price.repository.FundPriceEntityRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class FundPriceJpaRepository implements FundPriceRepository {
  private final FundPriceEntityRepository fundPriceEntityRepository;

  @Override
  public List<FundPrice> findAllByFundPriceKeyIn(Set<FundPriceKey> fundPriceKeys) {
    if (CollectionUtils.isEmpty(fundPriceKeys)) {
      return Collections.emptyList();
    }

    List<FundPriceEntity> entities = new ArrayList<>();

    fundPriceKeys.forEach(fundPriceKey ->
      entities.addAll(
        fundPriceEntityRepository.findAllByIdFundIdAndIdFundVersion(
          fundPriceKey.getFundId(), fundPriceKey.getFundVersion()
        )
      )
    );

    return entities.stream()
      .map(entity ->
        FundPriceEntityMapper.get().toDoaminObject(entity)
      )
      .collect(Collectors.toList());
  }
}