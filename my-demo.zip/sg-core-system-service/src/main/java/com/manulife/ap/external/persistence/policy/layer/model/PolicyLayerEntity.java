package com.manulife.ap.external.persistence.policy.layer.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TLAYERS")
public class PolicyLayerEntity {

  @EmbeddedId
  private PolicyLayerId id;

  @Column(name = "LAYER_PREM_AMT")
  private Double amount;

  @Column(name = "LAYER_PREM_PCT")
  private Double percentage;

  @Column(name = "TOT_PREM_PD")
  private Double paidAmount;
}
