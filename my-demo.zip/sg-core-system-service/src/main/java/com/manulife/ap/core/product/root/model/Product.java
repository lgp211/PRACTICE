package com.manulife.ap.core.product.root.model;

import lombok.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Product {
  private String planCode;
  private String planVersion;
  private ProductCurrency currency;
  private ProductCategory category;
  private ProductName name;
  private ProductConfiguration configuration;
  @Builder.Default
  private List<ProductVariant> variants = new ArrayList<>();

  /**
   * Evaluate value of marketing name using following rules:
   * - if matching variant found with given benefitDuration, then use the marketing name from variant
   * - otherwise, use marketing name at product level.
   *
   * @param premiumDuration Premium duration to compare
   * @param benefitDuration Benefit duration to compare
   * @return this product object instance
   */
  public Product evaluateProductMarketingName(final Integer premiumDuration, final Integer benefitDuration) {
    variants.stream()
      .filter(v -> v.isPremiumDurationExactMatch(premiumDuration))
      .filter(v -> v.isBenefitDurationExactMatch(benefitDuration))
      .findFirst()
      .ifPresent(v -> name.setMarketingName(v.getMarketingName()));

    return this;
  }

  public ProductKey getProductKey() {
    return ProductKey.builder()
      .planCode(this.planCode)
      .planVersion(this.planVersion)
      .currencyCode(Optional.ofNullable(this.currency).map(ProductCurrency::getCode).orElse(null))
      .build();
  }
}
