package com.manulife.ap.external.persistence.agent.root.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "TAMS_RANKS")
public class AgentRankEntity {
  @Id
  @Column(name = "RANK_CD")
  private String code;
  @Column(name = "RANK_DESC")
  private String description;
  @Column(name = "RANK_ORDR")
  private int order;
  @Column(name = "IS_MGR_IND")
  private String managerIndicator;
}
