package com.manulife.ap.core.agent.root.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Agent {
  private String agentCode;
  private String candidateNumber;
  private AgentName name;
  private AgentStatus status;
  private AgentEmail email;
  private AgentRank rank;
  private AgentContract contract;
  private AgentTraining training;
  private String branchCode;
  private String unitCode;
  private AgentReportingGroup reporting;
}
