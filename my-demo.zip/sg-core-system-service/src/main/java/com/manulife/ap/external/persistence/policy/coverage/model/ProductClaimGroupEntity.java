package com.manulife.ap.external.persistence.policy.coverage.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "TCLM_PLAN_GROUPS")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductClaimGroupEntity {

  @EmbeddedId
  private ProductClaimGroupId id;

  @Column(name = "PLAN_GRP_NM")
  private String planGroupName;

  @Column(name = "PLAN_GRP_TYP")
  private String planGroupType;
}