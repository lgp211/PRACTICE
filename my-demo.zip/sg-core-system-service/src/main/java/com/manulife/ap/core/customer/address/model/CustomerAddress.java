package com.manulife.ap.core.customer.address.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomerAddress {
  private String clientNumber;
  private String type;
  private String line1;
  private String line2;
  private String line3;
  private String line4;
  private String postalCode;
}
