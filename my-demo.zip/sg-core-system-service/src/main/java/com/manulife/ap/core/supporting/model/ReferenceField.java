package com.manulife.ap.core.supporting.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReferenceField {
  private ReferenceCategory category;
  private String code;
  private String description;
  private RecordStatus status;
}
