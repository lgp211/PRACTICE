package com.manulife.ap.external.persistence.policy.transaction.model.mapper;

import com.manulife.ap.core.policy.transaction.model.PolicyGiroTransaction;
import com.manulife.ap.external.persistence.policy.transaction.model.PolicyGiroTransactionEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Collection;
import java.util.List;

@Mapper
public interface PolicyGiroTransactionEntityMapper {
  static PolicyGiroTransactionEntityMapper get() {
    return PolicyGiroTransactionEntityMapper.ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final PolicyGiroTransactionEntityMapper INSTANCE = Mappers.getMapper(PolicyGiroTransactionEntityMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "policyNumber", source = "entity.id.policyNumber")
  @Mapping(target = "date", source = "entity.id.transactionDate")
  @Mapping(target = "code.code", source = "entity.transactionCode")
  @Mapping(target = "description", source = "entity.transactionDescription")
  @Mapping(target = "status", source = "entity.reasonCode")
  @Mapping(target = "amount", source = "entity.transactionAmount")
  PolicyGiroTransaction toPolicyGiroTransaction(PolicyGiroTransactionEntity entity);

  List<PolicyGiroTransaction> toPolicyGiroTransactionList(Collection<PolicyGiroTransactionEntity> policyGiroTransactionEntities);
}