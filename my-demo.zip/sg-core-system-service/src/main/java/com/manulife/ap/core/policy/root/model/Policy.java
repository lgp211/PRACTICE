package com.manulife.ap.core.policy.root.model;

import com.manulife.ap.core.policy.configuration.model.PolicyConfiguration;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Policy {
  private String policyNumber;
  private PolicyStatus status;
  private LocalDate effectiveDate;
  private LocalDate terminationDate;
  private LocalDate sliActivationDate;
  private PolicySubmission submission;
  private PolicyCurrency currency;
  private LocalDate paidToDate;
  private LocalDate lastAnniversaryDate;
  private List<PolicyAgent> agents;
  private PolicyPremium premium;
  private PolicyConfiguration configurations;
}
