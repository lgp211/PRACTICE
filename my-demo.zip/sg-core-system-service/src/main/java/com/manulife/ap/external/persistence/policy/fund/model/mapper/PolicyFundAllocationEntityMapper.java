package com.manulife.ap.external.persistence.policy.fund.model.mapper;

import com.manulife.ap.common.mapper.LocalDateMapper;
import com.manulife.ap.common.mapper.LocalDateMapping;
import com.manulife.ap.common.mapper.StringToLocalDate;
import com.manulife.ap.core.policy.fund.model.PolicyFundAllocation;
import com.manulife.ap.external.persistence.policy.fund.model.PolicyFundAllocationEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Collection;
import java.util.List;

@Mapper(uses = LocalDateMapping.class)
public interface PolicyFundAllocationEntityMapper {

  static PolicyFundAllocationEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final PolicyFundAllocationEntityMapper INSTANCE = Mappers.getMapper(PolicyFundAllocationEntityMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "policyNumber", source = "entity.id.policyNumber")
  @Mapping(target = "fundId", source = "entity.id.fundId")
  @Mapping(target = "fundVersion", source = "entity.id.fundVersion")
  @Mapping(target = "effectiveDate", source = "entity.id.effectiveDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "status", source = "entity.id.allocationStatus")
  @Mapping(target = "type.code", source = "entity.id.allocationType")
  @Mapping(target = "premiumGroup", source = "entity.id.premiumGroup")
  @Mapping(target = "percentage", source = "entity.percentage")
  PolicyFundAllocation toPolicyFundAllocation(PolicyFundAllocationEntity entity);

  List<PolicyFundAllocation> toPolicyFundAllocationList(Collection<PolicyFundAllocationEntity> policyFundAllocationList);

}
