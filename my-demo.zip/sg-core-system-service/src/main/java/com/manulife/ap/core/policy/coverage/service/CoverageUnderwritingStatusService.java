package com.manulife.ap.core.policy.coverage.service;

import com.manulife.ap.core.policy.coverage.model.CoverageUnderwritingStatus;

import java.util.Map;
import java.util.Set;

public interface CoverageUnderwritingStatusService {
  Map<String, CoverageUnderwritingStatus> findAllByPolicyNumberIn(Set<String> policyNumbers);
}