package com.manulife.ap.external.persistence.policy.common;

import com.manulife.ap.core.common.model.FilterCriteria;
import com.manulife.ap.external.persistence.common.GenericSpecification;
import com.manulife.ap.external.persistence.policy.root.model.PolicyEntity;
import com.manulife.ap.external.persistence.policy.root.model.filter.PolicyEntityFilter;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class PolicySpecificationFactory {

  public static GenericSpecification<PolicyEntity> createSpecificationForPolicyEntity(
    final List<FilterCriteria> filterCriteriaList) {

    return GenericSpecification.<PolicyEntity>builder()
      .filters(
        Optional.ofNullable(filterCriteriaList)
          .map(list -> list.stream()
            .map(filter ->
              FilterCriteria.builder()
                .key(PolicyEntityFilter.getColumnNameByFilter(filter.getKey()))
                .operation(filter.getOperation())
                .value(filter.getValue())
                .valueDataType(PolicyEntityFilter.getColumnDataTypeByFilter(filter.getKey()))
                .build()
            )
            .collect(Collectors.toList())
          )
          .orElse(Collections.emptyList())
      )
      .build();
  }
}
