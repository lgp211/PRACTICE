package com.manulife.ap.external.persistence.policy.root.model;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TPOLICYS")
@SecondaryTable(name = "TPOLICYS_SG", pkJoinColumns = @PrimaryKeyJoinColumn(name = "POL_NUM"))
@SecondaryTable(name = "TPOLICYS_INFO_SG", pkJoinColumns = @PrimaryKeyJoinColumn(name = "POL_NUM"))
public class PolicyEntity {

  @Id
  @Column(name = "POL_NUM")
  private String policyNumber;

  @Column(name = "POL_STAT_CD")
  private String status;

  @Column(name = "POL_EFF_DT")
  private String effectiveDate;

  @Column(name = "POL_TRMN_DT")
  private String terminationDate;

  @Column(name = "SLI_ACTIV_DT", table = "TPOLICYS_SG")
  private String sliActivationDate;

  @Column(name = "SBMT_DT")
  private String submissionDate;

  @Column(name = "SUBMISSION_TYPE", table = "TPOLICYS_SG")
  private String submissionType;

  @Column(name = "CRCY_CODE")
  private String currencyCode;

  @Column(name = "PD_TO_DT")
  private LocalDate paidToDate;

  @Column(name = "LAST_AVY_DT")
  private String lastAnniversaryDate;

  @Column(name = "AGT_CODE")
  private String primaryServicingAgent;

  @Column(name = "SA_CD_2")
  private String secondaryServicingAgent;

  @Column(name = "WA_CD_1")
  private String primaryWritingAgent;

  @Column(name = "WA_CD_2")
  private String secondaryWritingAgent;

  @Column(name = "MODE_PREM")
  private Double modeAmount;

  @Column(name = "PLAN_PREM")
  private Double planAmount;

  @Column(name = "DSCNT_PREM")
  private Double discountAmount;

  @Column(name = "PMT_SUSP")
  private Double suspenseAmount;

  @Column(name = "POL_SUSP")
  private Double suspensePolicy;

  @Column(name = "PH_IND")
  private String freezeStatus;

  @Column(name = "PH_EFF_TYP")
  private String premiumHolidayType;

  @Column(name = "PH_STRT_DT")
  private String premiumHolidayStartDate;

  @Column(name = "PH_END_DT")
  private String premiumHolidayEndDate;

  @Column(name = "PH_PD_TO_DT")
  private String premiumHolidayPaidToDate;

  @Column(name = "PH_LAST_PD_TO_DT")
  private String premiumHolidayLastPaidToDate;

  @Column(name = "DIV_OPT")
  private String dividendOption;

  @Column(name = "DB_OPT")
  private String deathBenefitOption;

  @Column(name = "NFO_OPT")
  private String nfoOption;

  @Column(name = "ANTY_OPT")
  private String annuityOption;

  @Column(name = "ANTY_DUR")
  private Integer annuityDuration;

  @Column(name = "ANTY_FREQ")
  private Integer annuityFrequency;

  @Column(name = "ACUM_PRD")
  private Integer accumulationPeriod;

  @Column(name = "BILL_MTHD")
  private String billingMethod;

  @Column(name = "PMT_MODE")
  private String paymentMode;

  @Column(name = "IPO_IND")
  private String ipoOption;

  @Column(name = "PAC_EFF_DT")
  private String giroEffectiveDate;

  @Column(name = "PAC_BK_CTR")
  private String giroStatus;

  @Column(name = "REBAL_IND")
  private String rebalancingIndicator;

  @Column(name = "PFP_CHOICE", table = "TPOLICYS_SG")
  private String pfpChoiceIndicator;

  @Column(name = "PFP_HEALTH", table = "TPOLICYS_SG")
  private String pfpHealthIndicator;

  @Column(name = "PAYO_MTHD")
  private String payoutMethod;

  @Column(name = "TRUST_TYPE", table = "TPOLICYS_INFO_SG")
  private String trustType;
}
