package com.manulife.ap.external.persistence.agent.production.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "TAMS_WRK_NAC_CONS_SG")
public class AgentProductionDetailsEntity {
  @EmbeddedId
  private AgentProductionDetailsId id;

  @Column(name = "CRCY_CD")
  private String currencyCode;

  @Column(name = "PLAN_NM")
  private String planName;

  @Column(name = "NAC")
  private Integer nac;

  @Column(name = "REINST")
  private Integer reinstatement;

  @Column(name = "ADJUST")
  private Integer adjustment;

  @Column(name = "LAPSED")
  private Integer lapsed;

  @Column(name = "RESCINDED")
  private Integer rescinded;

  @Column(name = "NETT_TOTAL")
  private Integer netTotal;

  @Column(name = "GROSS_TOTAL")
  private Integer grossTotal;

  @Column(name = "CASE_CNT")
  private Integer caseCount;

  @Column(name = "REIN_CNT")
  private Integer reinstatementCaseCount;

  @Column(name = "LAPS_CNT")
  private Integer lapsedCaseCount;

  @Column(name = "RESC_CNT")
  private Integer rescindedCaseCount;

  @Column(name = "NETT_CASE_CNT")
  private Integer netCaseCount;

  @Column(name = "UNIT_CD")
  private String taggingUnitCode;

  @Column(name = "BRANCH_CD")
  private String taggingBranchCode;

  @Column(name = "RPT_UNIT_CD")
  private String reportingUnitCode;

  @Column(name = "RPT_BRANCH_CD")
  private String reportingBranchCode;
}
