package com.manulife.ap.core.policy.coverage.model;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of = {"planCode", "planVersion"})
public class ProductPlanKey {
  private String planCode;
  private String planVersion;
}
