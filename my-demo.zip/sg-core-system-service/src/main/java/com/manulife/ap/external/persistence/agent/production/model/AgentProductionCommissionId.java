package com.manulife.ap.external.persistence.agent.production.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Embeddable
public class AgentProductionCommissionId implements Serializable {
  @Column(name = "PRODN_MTH")
  private String productionMonth;

  @Column(name = "POL_NUM")
  private String policyNumber;

  @Column(name = "PLAN_CODE")
  private String planCode;

  @Column(name = "POL_STAT")
  private String description;

  @Column(name = "AGT_CD")
  private String agentCode;
}
