package com.manulife.ap.core.policy.financial.service;

import com.manulife.ap.core.policy.financial.model.PolicyFinancial;

import java.util.Optional;

public interface PolicyFinancialRepository {
  Optional<PolicyFinancial> findByPolicyNumber(String policyNumber);
}
