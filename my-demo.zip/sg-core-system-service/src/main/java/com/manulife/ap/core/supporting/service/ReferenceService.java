package com.manulife.ap.core.supporting.service;

import com.manulife.ap.core.supporting.model.ReferenceCategory;
import com.manulife.ap.core.supporting.model.ReferenceField;

import java.util.Map;
import java.util.Optional;
import java.util.Set;

public interface ReferenceService {
  Optional<ReferenceField> findByCategoryAndCode(ReferenceCategory category, String referenceCode);
  Map<String, ReferenceField> findByCategoryAndCodes(ReferenceCategory category, Set<String> referenceCodes);
}
