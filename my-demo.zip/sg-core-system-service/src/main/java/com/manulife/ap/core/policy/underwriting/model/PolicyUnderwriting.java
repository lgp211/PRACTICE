package com.manulife.ap.core.policy.underwriting.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyUnderwriting {
  private String policyNumber;
  private List<OutstandingDocument> outstandingDocuments;
  private List<PremiumIssue> premiumIssues;
  private List<SupplementaryQuestion> supplementaryQuestions;
  private List<MedicalRequirementRequest> medicalRequirementRequests;
  private List<OtherUnderwriting> others;
  private List<PolicyUnderwritingChange> changes;
}
