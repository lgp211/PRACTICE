package com.manulife.ap.core.fund.price.service;

import com.manulife.ap.core.fund.price.model.FundPrice;
import com.manulife.ap.core.fund.price.model.FundPriceKey;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface FundPriceService {
  Map<FundPriceKey, List<FundPrice>> findAllByFundPriceKeyIn(Set<FundPriceKey> fundPriceKeys);
}
