package com.manulife.ap.external.persistence.customer.root;

import com.manulife.ap.core.common.model.FilterCriteria;
import com.manulife.ap.core.customer.root.model.Customer;
import com.manulife.ap.core.customer.root.service.CustomerRepository;
import com.manulife.ap.external.persistence.common.GenericSpecification;
import com.manulife.ap.external.persistence.customer.common.CustomerSpecificationFactory;
import com.manulife.ap.external.persistence.customer.root.model.CustomerEntity;
import com.manulife.ap.external.persistence.customer.root.model.mapper.CustomerEntityMapper;
import com.manulife.ap.external.persistence.customer.root.repository.CustomerEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import javax.validation.Valid;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class CustomerJpaRepository implements CustomerRepository {
  private final CustomerEntityRepository customerEntityRepository;

  @Override
  public List<Customer> findAllByClientNumberIn(List<String> clientNumbers) {
    if (Objects.isNull(clientNumbers) || clientNumbers.isEmpty()) {
      return Collections.emptyList();
    }

    return customerEntityRepository.findAllById(clientNumbers)
      .parallelStream()
      .map(customerEntity -> CustomerEntityMapper.get().toCustomer(customerEntity))
      .collect(Collectors.toList());
  }

  @Override
  public List<Customer> findAllByCriteria(@Valid List<FilterCriteria> filterCriteriaList) {
    return Optional.of(filterCriteriaList)
      .map(list -> {
        GenericSpecification<CustomerEntity> specification =
          CustomerSpecificationFactory.createSpecificationForCustomerEntity(list);

        return customerEntityRepository.findAll(specification)
          .parallelStream()
          .map(customerEntity -> CustomerEntityMapper.get().toCustomer(customerEntity))
          .collect(Collectors.toList());
      })
      .orElse(Collections.emptyList());
  }
}
