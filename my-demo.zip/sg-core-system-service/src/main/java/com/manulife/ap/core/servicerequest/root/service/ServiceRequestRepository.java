package com.manulife.ap.core.servicerequest.root.service;

import com.manulife.ap.core.servicerequest.root.model.ServiceRequest;

import java.util.List;
import java.util.Set;

public interface ServiceRequestRepository {
  List<ServiceRequest> findAllByPolicyNumber(Set<String> policyNumbers);
}
