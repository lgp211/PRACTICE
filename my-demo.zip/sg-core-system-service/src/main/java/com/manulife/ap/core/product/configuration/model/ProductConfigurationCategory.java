package com.manulife.ap.core.product.configuration.model;


import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ProductConfigurationCategory {

  MINIMUM_POLICY_AMOUNT("minimumPolicyAmount", "MIN_POL_AMT");

  private final String name;
  private final String code;
}
