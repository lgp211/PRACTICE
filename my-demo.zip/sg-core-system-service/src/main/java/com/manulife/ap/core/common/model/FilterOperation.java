package com.manulife.ap.core.common.model;

import lombok.AllArgsConstructor;

import java.util.Optional;
import java.util.stream.Stream;

@AllArgsConstructor
public enum FilterOperation {
  IN,
  EQUAL,
  BETWEEN;

  public static Optional<FilterOperation> findByName(final String name) {
    return Stream.of(FilterOperation.values())
      .filter(operation -> operation.name().equals(name))
      .findFirst();
  }
}
