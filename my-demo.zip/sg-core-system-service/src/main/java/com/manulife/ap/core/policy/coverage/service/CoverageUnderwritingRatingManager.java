package com.manulife.ap.core.policy.coverage.service;

import com.manulife.ap.core.policy.coverage.model.CoverageUnderwritingKey;
import com.manulife.ap.core.policy.coverage.model.CoverageUnderwritingRating;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CoverageUnderwritingRatingManager implements CoverageUnderwritingRatingService {
  private final CoverageUnderwritingRatingRepository coverageUnderwritingRatingRepository;

  @Override
  public Map<CoverageUnderwritingKey, CoverageUnderwritingRating> findRatingByUnderwritingKeys(final Set<CoverageUnderwritingKey> coverageUnderwritingKeys) {
    if (Objects.isNull(coverageUnderwritingKeys) || coverageUnderwritingKeys.isEmpty()) {
      return Collections.emptyMap();
    }

    List<CoverageUnderwritingRating> ratings =  coverageUnderwritingRatingRepository.findRatingByUnderwritingKeys(coverageUnderwritingKeys);

    return ratings.stream()
      .collect(Collectors.toMap(underwriting ->
          CoverageUnderwritingKey.builder()
            .policyNumber(underwriting.getPolicyNumber())
            .planCode(underwriting.getPlanCode())
            .planVersion(underwriting.getPlanVersion())
            .build(),
        Function.identity()
      ));
  }
}