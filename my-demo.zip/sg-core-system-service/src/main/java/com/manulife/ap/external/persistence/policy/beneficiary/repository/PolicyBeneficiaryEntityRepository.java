package com.manulife.ap.external.persistence.policy.beneficiary.repository;

import com.manulife.ap.external.persistence.policy.beneficiary.model.PolicyBeneficiaryEntity;
import com.manulife.ap.external.persistence.policy.beneficiary.model.PolicyBeneficiaryId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface PolicyBeneficiaryEntityRepository extends JpaRepository<PolicyBeneficiaryEntity, PolicyBeneficiaryId> {
  List<PolicyBeneficiaryEntity> findAllByIdPolicyNumberIn(Set<String> policyNumbers);
}