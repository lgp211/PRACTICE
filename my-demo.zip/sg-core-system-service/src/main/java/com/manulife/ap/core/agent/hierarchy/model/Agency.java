package com.manulife.ap.core.agent.hierarchy.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.Objects;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Agency {
  public static final String TYPE_BRANCH = "DT";
  public static final String TYPE_UNIT = "UN";

  private String code;
  private String name;
  private AgencyStatus status;
  private AgencyChannel channel;
  private AgencyType type;
  private AgencyZone zone;
  private LocalDate terminationDate;
  private String managerAgentCode;

  /**
   * Return <code>true</code> if this is branch-type; otherwise return <code>false</code>.
   *
   * @return <code>true</code> if this is branch-type; otherwise return <code>false</code>.
   */
  public boolean isBranchType() {
    return Objects.nonNull(this.type) && TYPE_BRANCH.equalsIgnoreCase(this.type.getCode());
  }

  /**
   * Return <code>true</code> if this is unit-type; otherwise return <code>false</code>.
   *
   * @return <code>true</code> if this is unit-type; otherwise return <code>false</code>.
   */
  public boolean isUnitType() {
    return Objects.nonNull(this.type) && TYPE_UNIT.equalsIgnoreCase(this.type.getCode());
  }
}
