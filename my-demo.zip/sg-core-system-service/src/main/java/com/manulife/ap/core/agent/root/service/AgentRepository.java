package com.manulife.ap.core.agent.root.service;

import com.manulife.ap.core.agent.root.model.Agent;
import com.manulife.ap.core.agent.root.model.AgentRank;
import com.manulife.ap.core.agent.root.model.AgentStatus;
import com.manulife.ap.core.common.model.FilterCriteria;

import java.util.List;

public interface AgentRepository {
  List<Agent> findAllAgentsByAgentCodeIn(List<String> agentCodes);

  List<AgentStatus> findAllStatusesByStatusCodeIn(List<String> statusCodes);

  List<AgentRank> findAllRanksByRankCodeIn(List<String> rankCodes);

  List<Agent> findAllAgentsByBranchCodeIn(List<String> branchCodes);

  List<Agent> findAllAgents(List<FilterCriteria> filters);

  List<Agent> findAllAgentsByEmailAddress(String emailAddress);
}
