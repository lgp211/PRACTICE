package com.manulife.ap.core.product.configuration.model;

import com.manulife.ap.core.product.root.model.ProductKey;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Optional;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductConfigurationField {
  private String planCode;
  private String planVersion;
  private String currencyCode;
  private String type;
  private String value;
  private Integer fromDuration;
  private Integer toDuration;

  public Double getValueAsDouble() {
    try {
      return Optional.ofNullable(value)
        .map(Double::parseDouble)
        .orElse(0.0);
    } catch (NumberFormatException e) {
      return 0.0;
    }
  }

  public ProductKey toProductKey() {
    return ProductKey.builder()
      .planCode(this.planCode)
      .planVersion(this.planVersion)
      .currencyCode(this.currencyCode)
      .build();
  }
}
