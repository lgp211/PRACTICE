package com.manulife.ap.external.persistence.policy.transaction.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TTRXN_HISTORIES")
public class PolicyGiroTransactionEntity {

  @EmbeddedId
  private PolicyGiroTransactionId id;

  @Column(name = "TRXN_CD")
  private String transactionCode;

  @Column(name = "TRXN_DESC")
  private String transactionDescription;

  @Column(name = "REASN_CODE")
  private String reasonCode;

  @Column(name = "TRXN_AMT")
  private Double transactionAmount;
}