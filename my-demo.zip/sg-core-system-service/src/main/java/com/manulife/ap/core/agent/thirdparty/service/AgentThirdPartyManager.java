package com.manulife.ap.core.agent.thirdparty.service;

import com.manulife.ap.core.agent.thirdparty.model.AgentThirdParty;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
public class AgentThirdPartyManager implements AgentThirdPartyService {
  private final AgentThirdPartyRepository agentThirdPartyRepository;

  @Override
  public List<AgentThirdParty> findAllByIdIn(final List<String> thirdPartyIds) {
    if (Objects.isNull(thirdPartyIds) || thirdPartyIds.isEmpty()) {
      return Collections.emptyList();
    }

    return agentThirdPartyRepository.findAllByIdIn(thirdPartyIds);
  }

  @Override
  public Map<String, List<AgentThirdParty>> findAllByAgentCodeIn(final Set<String> agentCodes) {
    if (Objects.isNull(agentCodes) || agentCodes.isEmpty()) {
      return Collections.emptyMap();
    }

    HashMap<String, List<AgentThirdParty>> map = new HashMap<>();
    List<AgentThirdParty> thirdParties = agentThirdPartyRepository.findAllByAgentCodeIn(new ArrayList<>(agentCodes));

    for (AgentThirdParty thirdParty: thirdParties) {
      map.computeIfAbsent(thirdParty.getAgentCode(), k -> new ArrayList<>()).add(thirdParty);
    }

    return map;
  }
}
