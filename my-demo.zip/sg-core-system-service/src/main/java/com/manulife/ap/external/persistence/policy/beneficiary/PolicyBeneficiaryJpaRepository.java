package com.manulife.ap.external.persistence.policy.beneficiary;

import com.manulife.ap.core.policy.beneficiary.model.PolicyBeneficiary;
import com.manulife.ap.core.policy.beneficiary.service.PolicyBeneficiaryRepository;
import com.manulife.ap.external.persistence.policy.beneficiary.model.mapper.PolicyBeneficiaryEntityMapper;
import com.manulife.ap.external.persistence.policy.beneficiary.repository.PolicyBeneficiaryEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Repository
@RequiredArgsConstructor
public class PolicyBeneficiaryJpaRepository implements PolicyBeneficiaryRepository {
  private final PolicyBeneficiaryEntityRepository policyBeneficiaryEntityRepository;

  @Override
  public List<PolicyBeneficiary> findAllByPolicyNumberIn(final Set<String> policyNumbers) {
    if (Objects.isNull(policyNumbers) || policyNumbers.isEmpty()) {
      return Collections.emptyList();
    }
    return policyBeneficiaryEntityRepository.findAllByIdPolicyNumberIn(policyNumbers)
      .stream()
      .map(entity -> PolicyBeneficiaryEntityMapper.get().toPolicyBeneficiary(entity))
      .collect(Collectors.toList());
  }
}