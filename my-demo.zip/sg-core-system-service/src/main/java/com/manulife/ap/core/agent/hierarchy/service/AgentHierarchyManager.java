package com.manulife.ap.core.agent.hierarchy.service;

import com.manulife.ap.core.agent.hierarchy.model.Agency;
import com.manulife.ap.core.agent.root.service.AgentRepository;
import joptsimple.internal.Strings;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.manulife.ap.common.util.StreamUtil.distinctByKey;
import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class AgentHierarchyManager implements AgentHierarchyService {
  private final AgentHierarchyRepository agentHierarchyRepository;
  private final AgentRepository agentRepository;

  @Override
  public List<Agency> findAllAgenciesByAgencyCodeIn(final List<String> agencyCodes) {
    if (Objects.isNull(agencyCodes) || agencyCodes.isEmpty()) {
      return Collections.emptyList();
    }

    return agentHierarchyRepository.findAllAgenciesByAgencyCodesIn(agencyCodes);
  }

  @Override
  public Map<String, List<Agency>> findAllAgenciesByManagerIn(final List<String> managerAgentCodes) {
    if (Objects.isNull(managerAgentCodes) || managerAgentCodes.isEmpty()) {
      return Collections.emptyMap();
    }

    return agentHierarchyRepository
      .findAllAgenciesByManagerIn(managerAgentCodes)
      .stream()
      .collect(groupingBy(Agency::getManagerAgentCode));
  }

  @Override
  public List<Agency> findAllUnitAgenciesByBranchCode(final String branchCode) {
    if (Strings.isNullOrEmpty(branchCode)) {
      return Collections.emptyList();
    }

    List<String> unitAgencyCodes =
      agentRepository.findAllAgentsByBranchCodeIn(Collections.singletonList(branchCode)).stream()
        .filter(distinctByKey(agent -> agent.getReporting().getUnitCode()))
        .map(agent -> agent.getReporting().getUnitCode())
        .collect(Collectors.toList());

    return agentHierarchyRepository.findAllAgenciesByAgencyCodesIn(unitAgencyCodes);
  }
}
