package com.manulife.ap.core.fund.summary.service;

import com.manulife.ap.core.fund.summary.model.FundSummary;
import com.manulife.ap.core.fund.summary.model.FundSummaryKey;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FundSummaryManager implements FundSummaryService {
  private final FundSummaryRepository fundSummaryRepository;

  @Override
  public Map<FundSummaryKey, FundSummary> findAllByFundSummaryKeyIn(final Set<FundSummaryKey> fundSummaryKeys) {
    if (Objects.isNull(fundSummaryKeys) || fundSummaryKeys.isEmpty()) {
      return Collections.emptyMap();
    }

    return fundSummaryRepository.findAllByFundSummaryKeyIn(fundSummaryKeys)
      .stream()
      .collect(Collectors.toMap(fundSummary ->
          FundSummaryKey.builder()
            .fundId(fundSummary.getFundId())
            .fundVersion(fundSummary.getFundVersion())
            .build(),
        Function.identity()
      ));
  }
}