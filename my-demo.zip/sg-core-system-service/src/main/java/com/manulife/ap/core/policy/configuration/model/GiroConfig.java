package com.manulife.ap.core.policy.configuration.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GiroConfig {
  private LocalDate effectiveDate;
  private GiroStatus status;
}
