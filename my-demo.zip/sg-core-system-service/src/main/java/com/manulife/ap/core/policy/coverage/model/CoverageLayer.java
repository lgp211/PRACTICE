package com.manulife.ap.core.policy.coverage.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CoverageLayer {
  private String policyNumber;
  private String clientNumber;
  private String planCode;
  private String planVersion;
  private LocalDate coverageEffectiveDate;
  private LocalDate effectiveDate;
  private CoverageLayerStatus status;
  private SmokerStatus smoker;

  public boolean isKeyMatching(CoverageLayerKey coverageLayerKey) {
    return this.policyNumber.equals(coverageLayerKey.getPolicyNumber()) &&
      this.clientNumber.equals(coverageLayerKey.getClientNumber()) &&
      this.planCode.equals(coverageLayerKey.getPlanCode()) &&
      this.planVersion.equals(coverageLayerKey.getPlanVersion()) &&
      this.coverageEffectiveDate.equals(coverageLayerKey.getCoverageEffectiveDate());
  }
}