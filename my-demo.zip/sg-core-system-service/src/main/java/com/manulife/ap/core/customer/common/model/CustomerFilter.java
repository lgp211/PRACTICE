package com.manulife.ap.core.customer.common.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum CustomerFilter {
  NAME,
  IDENTITY_NUMBER;
}
