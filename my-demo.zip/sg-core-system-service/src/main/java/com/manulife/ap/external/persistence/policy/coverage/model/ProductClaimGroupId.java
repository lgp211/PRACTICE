package com.manulife.ap.external.persistence.policy.coverage.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductClaimGroupId implements Serializable {
  @Column(name = "PLAN_CODE")
  private String planCode;

  @Column(name = "VERS_NUM")
  private String planVersion;
}
