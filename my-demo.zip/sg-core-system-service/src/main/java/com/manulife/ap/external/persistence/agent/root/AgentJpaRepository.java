package com.manulife.ap.external.persistence.agent.root;

import com.manulife.ap.core.agent.root.model.Agent;
import com.manulife.ap.core.agent.root.model.AgentRank;
import com.manulife.ap.core.agent.root.model.AgentStatus;
import com.manulife.ap.core.agent.root.service.AgentRepository;
import com.manulife.ap.core.common.model.FilterCriteria;
import com.manulife.ap.external.persistence.agent.common.AgentSpecificationFactory;
import com.manulife.ap.external.persistence.agent.root.model.AgentEntity;
import com.manulife.ap.external.persistence.agent.root.model.mapper.AgentEntityMapper;
import com.manulife.ap.external.persistence.agent.root.model.mapper.AgentRankEntityMapper;
import com.manulife.ap.external.persistence.agent.root.model.mapper.AgentStatusEntityMapper;
import com.manulife.ap.external.persistence.agent.root.repository.AgentEntityRepository;
import com.manulife.ap.external.persistence.agent.root.repository.AgentRankEntityRepository;
import com.manulife.ap.external.persistence.agent.root.repository.AgentStatusEntityRepository;
import com.manulife.ap.external.persistence.common.GenericSpecification;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class AgentJpaRepository implements AgentRepository {
  private final AgentEntityRepository agentEntityRepository;
  private final AgentStatusEntityRepository agentStatusEntityRepository;
  private final AgentRankEntityRepository agentRankEntityRepository;

  @Override
  public List<Agent> findAllAgentsByAgentCodeIn(final List<String> agentCodes) {
    if (Objects.isNull(agentCodes) || agentCodes.isEmpty()) {
      return Collections.emptyList();
    }

    return agentEntityRepository.findAllById(agentCodes)
      .parallelStream()
      .map(agentEntity -> AgentEntityMapper.get().toAgent(agentEntity))
      .collect(Collectors.toList());
  }

  @Override
  public List<AgentStatus> findAllStatusesByStatusCodeIn(final List<String> statusCodes) {
    if (Objects.isNull(statusCodes) || statusCodes.isEmpty()) {
      return Collections.emptyList();
    }

    return agentStatusEntityRepository.findAllById(statusCodes)
      .parallelStream()
      .map(statusEntity -> AgentStatusEntityMapper.get().toAgentStatus(statusEntity))
      .collect(Collectors.toList());
  }

  @Override
  public List<AgentRank> findAllRanksByRankCodeIn(final List<String> rankCodes) {
    if (Objects.isNull(rankCodes) || rankCodes.isEmpty()) {
      return Collections.emptyList();
    }

    return agentRankEntityRepository.findAllById(rankCodes)
      .parallelStream()
      .map(rankEntity -> AgentRankEntityMapper.get().toAgentRank(rankEntity))
      .collect(Collectors.toList());
  }

  @Override
  public List<Agent> findAllAgentsByBranchCodeIn(final List<String> branchCodes) {
    if (Objects.isNull(branchCodes) || branchCodes.isEmpty()) {
      return Collections.emptyList();
    }

    return agentEntityRepository.findAllByBranchCodeIn(branchCodes)
      .parallelStream()
      .map(agentEntity -> AgentEntityMapper.get().toAgent(agentEntity))
      .collect(Collectors.toList());
  }

  @Override
  public List<Agent> findAllAgents(final List<FilterCriteria> filters) {
    if (Objects.isNull(filters)) {
      return Collections.emptyList();
    }

    GenericSpecification<AgentEntity> specification =
      AgentSpecificationFactory.createSpecificationForAgentEntity(filters);

    return agentEntityRepository.findAll(specification)
      .parallelStream()
      .map(agentEntity -> AgentEntityMapper.get().toAgent(agentEntity))
      .collect(Collectors.toList());
  }

  @Override
  public List<Agent> findAllAgentsByEmailAddress(final String emailAddress) {
    if (Objects.isNull(emailAddress) || emailAddress.isEmpty()) {
      return Collections.emptyList();
    }

    return agentEntityRepository.findAllByEmailAddress(emailAddress)
      .parallelStream()
      .map(agentEntity -> AgentEntityMapper.get().toAgent(agentEntity))
      .collect(Collectors.toList());
  }

}
