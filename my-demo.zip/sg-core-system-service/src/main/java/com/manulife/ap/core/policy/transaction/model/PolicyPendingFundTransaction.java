package com.manulife.ap.core.policy.transaction.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyPendingFundTransaction {
  private String policyNumber;
  private String transactionId;
  private Integer fundTransactionNumber;
  private LocalDate date;
  private LocalDate valuationDate;
  private FundTransactionCode fundTransactionCode;
  private Double amount;
  private String userId;
  private String fundId;
  private String fundVersion;
}
