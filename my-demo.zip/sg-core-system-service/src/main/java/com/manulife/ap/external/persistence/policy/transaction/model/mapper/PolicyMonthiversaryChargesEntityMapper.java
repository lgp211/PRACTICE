package com.manulife.ap.external.persistence.policy.transaction.model.mapper;

import com.manulife.ap.core.policy.transaction.model.PolicyMonthiversaryCharges;
import com.manulife.ap.external.persistence.policy.transaction.model.PolicyMonthiversaryChargesEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Collection;
import java.util.List;

@Mapper
public interface PolicyMonthiversaryChargesEntityMapper {
  static PolicyMonthiversaryChargesEntityMapper get() {
    return PolicyMonthiversaryChargesEntityMapper.ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final PolicyMonthiversaryChargesEntityMapper INSTANCE = Mappers.getMapper(PolicyMonthiversaryChargesEntityMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "policyNumber", source = "entity.id.policyNumber")
  @Mapping(target = "mvySeq", source = "entity.id.mvySeq")
  @Mapping(target = "deferralReason", source = "entity.id.deferralReason")
  @Mapping(target = "layerEffectiveDate", source = "entity.id.layerEffectiveDate")
  @Mapping(target = "layerType.code", source = "entity.id.layerType")
  @Mapping(target = "testLevel", source = "entity.id.testLevel")
  @Mapping(target = "processSeq", source = "entity.id.processSeq")
  @Mapping(target = "dbpIndicator", source = "entity.id.dbpIndicator")
  @Mapping(target = "totalAmount", source = "entity.totalAmount")
  @Mapping(target = "currentMvyDate", source = "entity.currentMvyDate")
  PolicyMonthiversaryCharges toPolicyMonthiversaryCharges(PolicyMonthiversaryChargesEntity entity);

  List<PolicyMonthiversaryCharges> toPolicyMonthiversaryChargesList(Collection<PolicyMonthiversaryChargesEntity> policyMonthiversaryChargesEntities);
}