package com.manulife.ap.external.persistence.policy.beneficiary.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyBeneficiaryId implements Serializable {
  @Column(name = "POL_NUM")
  private String policyNumber;

  @Column(name = "BDE_NUM")
  private String beneficiaryNumber;

  @Column(name = "BNFY_TYP")
  private String beneficiaryType;
}