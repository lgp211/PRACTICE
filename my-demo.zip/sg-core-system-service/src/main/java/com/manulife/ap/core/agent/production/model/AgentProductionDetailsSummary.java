package com.manulife.ap.core.agent.production.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AgentProductionDetailsSummary {
  private Integer newBusiness;
  private Integer reinstatement;
  private Integer adjustment;
  private Integer lapsed;
  private Integer rescinded;
  @NotNull @Positive
  private Integer netTotal;
  @NotNull @Positive
  private Integer grossTotal;
}
