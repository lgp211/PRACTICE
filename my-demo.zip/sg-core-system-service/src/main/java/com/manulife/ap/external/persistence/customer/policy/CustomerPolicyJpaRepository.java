package com.manulife.ap.external.persistence.customer.policy;

import com.manulife.ap.core.customer.policy.model.CustomerPolicy;
import com.manulife.ap.core.customer.policy.service.CustomerPolicyRepository;
import com.manulife.ap.external.persistence.customer.policy.model.mapper.CustomerPolicyEntityMapper;
import com.manulife.ap.external.persistence.customer.policy.repository.CustomerPolicyEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class CustomerPolicyJpaRepository implements CustomerPolicyRepository {
  private final CustomerPolicyEntityRepository customerPolicyEntityRepository;

  @Override
  public List<CustomerPolicy> findAllByClientNumberIn(final List<String> clientNumber) {
    if (Objects.isNull(clientNumber) || clientNumber.isEmpty()) {
      return Collections.emptyList();
    }

    return customerPolicyEntityRepository.findAllByIdClientNumberIn(clientNumber)
      .parallelStream()
      .map(policyEntity -> CustomerPolicyEntityMapper.get().toCustomerPolicy(policyEntity))
      .collect(Collectors.toList());
  }
}
