package com.manulife.ap.core.agent.thirdparty.service;

import com.manulife.ap.core.agent.thirdparty.model.AgentThirdParty;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface AgentThirdPartyService {
  List<AgentThirdParty> findAllByIdIn(List<String> thirdPartyIds);
  Map<String, List<AgentThirdParty>> findAllByAgentCodeIn(Set<String> agentCodes);
}
