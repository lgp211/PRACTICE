package com.manulife.ap.external.persistence.agent.thirdparty.model.mapper;

import com.manulife.ap.core.agent.thirdparty.model.AgentThirdParty;
import com.manulife.ap.external.persistence.agent.thirdparty.model.AgentThirdPartyEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AgentThirdPartyEntityMapper {
  static AgentThirdPartyEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final AgentThirdPartyEntityMapper INSTANCE = Mappers.getMapper(AgentThirdPartyEntityMapper.class);
    private ModelMapperInstance() {}
  }

  @Mapping(target = "id", source = "entity.id.thirdPartyId")
  @Mapping(target = "company.key.code", source = "entity.id.thirdPartyCompanyCode")
  @Mapping(target = "agentCode", source = "entity.id.agentCode")
  AgentThirdParty toAgentThirdParty(AgentThirdPartyEntity entity);
}
