package com.manulife.ap.delegate;

import com.manulife.ap.swagger.api.NounApiDelegate;
import com.manulife.ap.swagger.model.NounInfo;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class NounApiDelegateImpl implements NounApiDelegate {
  @Override
  public ResponseEntity<Void> deleteNounByID(Long nounID) {
    return null;
  }

  @Override
  public ResponseEntity<NounInfo> getNoun(Long nounID) {
    return null;
  }

  @Override
  public ResponseEntity<Void> updateNounByID(String nounID, NounInfo body) {
    return null;
  }

  @Override
  public ResponseEntity<Void> updateNounForm(Long nounID, String name, String status) {
    return null;
  }
}
