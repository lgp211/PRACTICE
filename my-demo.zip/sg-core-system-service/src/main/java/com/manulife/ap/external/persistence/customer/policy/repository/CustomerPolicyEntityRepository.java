package com.manulife.ap.external.persistence.customer.policy.repository;

import com.manulife.ap.external.persistence.customer.policy.model.CustomerPolicyEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CustomerPolicyEntityRepository extends JpaRepository<CustomerPolicyEntity, String> {
    List<CustomerPolicyEntity> findAllByIdClientNumberIn(List<String> clientNumber);
}
