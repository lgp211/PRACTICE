package com.manulife.ap.core.policy.layer.service;

import com.manulife.ap.core.policy.layer.model.PolicyLayer;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
public class PolicyLayerManager implements PolicyLayerService {

  private final PolicyLayerRepository policyLayerRepository;

  @Override
  public Map<String, List<PolicyLayer>> findLayersByPolicyNumbers(Set<String> policyNumbers) {
    if (Objects.isNull(policyNumbers) || policyNumbers.isEmpty()) {
      return Collections.emptyMap();
    }

    HashMap<String, List<PolicyLayer>> map = new HashMap<>();
    List<PolicyLayer> layers = policyLayerRepository.findLayersByPolicyNumbers(policyNumbers);

    for (PolicyLayer layer : layers) {
      map.computeIfAbsent(layer.getPolicyNumber(), k -> new ArrayList<>()).add(layer);
    }

    return map;
  }
}
