package com.manulife.ap.core.policy.transaction.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyPremiumTransaction {
  private String policyNumber;
  private LocalDate date;
  private String shiNumber;
  private Double appliedAmount;
}
