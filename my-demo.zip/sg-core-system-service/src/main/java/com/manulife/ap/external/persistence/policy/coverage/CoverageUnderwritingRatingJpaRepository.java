package com.manulife.ap.external.persistence.policy.coverage;

import com.manulife.ap.core.policy.coverage.model.CoverageUnderwritingKey;
import com.manulife.ap.core.policy.coverage.model.CoverageUnderwritingRating;
import com.manulife.ap.core.policy.coverage.service.CoverageUnderwritingRatingRepository;
import com.manulife.ap.external.persistence.policy.coverage.model.CoverageUnderwritingRatingId;
import com.manulife.ap.external.persistence.policy.coverage.model.mapper.CoverageUnderwritingRatingEntityMapper;
import com.manulife.ap.external.persistence.policy.coverage.repository.CoverageUnderwritingRatingEntityRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class CoverageUnderwritingRatingJpaRepository implements CoverageUnderwritingRatingRepository {
  private final CoverageUnderwritingRatingEntityRepository coverageUnderwritingRatingEntityRepository;

  @Override
  public List<CoverageUnderwritingRating> findRatingByUnderwritingKeys(final Set<CoverageUnderwritingKey> coverageUnderwritingKeys) {
    if (CollectionUtils.isEmpty(coverageUnderwritingKeys)) {
      return Collections.emptyList();
    }

    return coverageUnderwritingRatingEntityRepository
      .findAllByIdIn(
        coverageUnderwritingKeys.stream()
          .map(coverageUnderwritingKey ->
            CoverageUnderwritingRatingId.builder()
              .policyNumber(coverageUnderwritingKey.getPolicyNumber())
              .planCode(coverageUnderwritingKey.getPlanCode())
              .planVersion(coverageUnderwritingKey.getPlanVersion())
              .build()
          )
          .collect(Collectors.toSet())
      )
      .stream()
      .map(entity ->
        CoverageUnderwritingRatingEntityMapper.get().toCoverageUnderwritingRating(entity))
      .collect(Collectors.toList());
  }
}
