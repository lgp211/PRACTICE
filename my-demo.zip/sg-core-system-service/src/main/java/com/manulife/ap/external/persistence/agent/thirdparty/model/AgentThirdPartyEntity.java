package com.manulife.ap.external.persistence.agent.thirdparty.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "TAMS_AVIVA_AGT_MAPPINGS_SG")
public class AgentThirdPartyEntity {
  @EmbeddedId
  private AgentThirdPartyId id;
}
