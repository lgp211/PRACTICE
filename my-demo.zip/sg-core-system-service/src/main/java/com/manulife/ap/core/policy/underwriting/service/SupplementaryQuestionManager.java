package com.manulife.ap.core.policy.underwriting.service;

import com.manulife.ap.core.policy.underwriting.model.SupplementaryQuestion;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class SupplementaryQuestionManager implements SupplementaryQuestionService {

  private final SupplementaryQuestionRepository supplementaryQuestionRepository;

  @Override
  public Map<String, List<SupplementaryQuestion>> findAllByPolicyNumbers(final Set<String> policyNumbers) {
    if (Objects.isNull(policyNumbers) || policyNumbers.isEmpty()) {
      return Collections.emptyMap();
    }

    return supplementaryQuestionRepository.findAllByPolicyNumbers(policyNumbers)
      .parallelStream()
      .collect(groupingBy(SupplementaryQuestion::getPolicyNumber));
  }
}
