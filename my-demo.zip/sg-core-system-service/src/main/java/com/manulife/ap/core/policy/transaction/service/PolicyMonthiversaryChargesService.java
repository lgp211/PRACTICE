package com.manulife.ap.core.policy.transaction.service;

import com.manulife.ap.core.policy.transaction.model.PolicyMonthiversaryCharges;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface PolicyMonthiversaryChargesService {
  Map<String, List<PolicyMonthiversaryCharges>> findAllByPolicyNumberIn(Set<String> policyNumbers);
}