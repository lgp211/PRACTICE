package com.manulife.ap.external.persistence.policy.coverage.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "TCLM_PLAN_CLM_MAP")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductClaimEntity {

  @EmbeddedId
  private ProductClaimId id;

  @Column(name = "SPCL_CODE")
  private String specialCode;

}