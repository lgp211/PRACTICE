package com.manulife.ap.external.persistence.policy.beneficiary.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "TBENEFICIARY_DETAILS")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyBeneficiaryEntity {
  @EmbeddedId
  private PolicyBeneficiaryId id;

  @Column(name = "BNFY_CODE")
  private String beneficiaryCode;

  @Column(name = "BNFY_NM")
  private String beneficiaryName;

  @Column(name = "BNFY_PCT")
  private Double beneficiaryPercentage;

  @Column(name = "BNFY_PRTY")
  private String beneficiaryParty;
}
