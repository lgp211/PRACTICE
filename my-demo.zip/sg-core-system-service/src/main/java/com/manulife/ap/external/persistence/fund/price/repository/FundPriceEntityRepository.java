package com.manulife.ap.external.persistence.fund.price.repository;

import com.manulife.ap.external.persistence.fund.price.model.FundPriceEntity;
import com.manulife.ap.external.persistence.fund.price.model.FundPriceId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FundPriceEntityRepository extends JpaRepository<FundPriceEntity, FundPriceId> {
  List<FundPriceEntity> findAllByIdFundIdAndIdFundVersion(String fundId, String fundVersion);
}