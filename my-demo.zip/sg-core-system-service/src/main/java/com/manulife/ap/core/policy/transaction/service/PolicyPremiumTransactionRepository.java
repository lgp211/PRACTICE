package com.manulife.ap.core.policy.transaction.service;

import com.manulife.ap.core.policy.transaction.model.PolicyPremiumTransaction;

import java.util.List;
import java.util.Set;

public interface PolicyPremiumTransactionRepository {
  List<PolicyPremiumTransaction> findPremiumTransactionsByPolicyNumbers(Set<String> policyNumbers);
}
