package com.manulife.ap.core.fund.root.service;

import com.manulife.ap.core.fund.root.model.Fund;

import java.util.List;
import java.util.Set;

public interface FundRepository {
  List<Fund> findAllByFundIdIn(Set<String> fundIds);
}