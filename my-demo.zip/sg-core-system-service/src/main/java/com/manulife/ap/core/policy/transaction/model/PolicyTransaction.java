package com.manulife.ap.core.policy.transaction.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyTransaction {
  private String policyNumber;
  private List<PolicyPremiumTransaction> premiums;
  private List<PolicyGiroTransaction> giro;
  private List<PolicyPremiumHoliday> premiumHolidays;
  private List<PolicyFundTransactionHistory> funds;
  private List<PolicyPendingFundTransaction> pendingFunds;
}
