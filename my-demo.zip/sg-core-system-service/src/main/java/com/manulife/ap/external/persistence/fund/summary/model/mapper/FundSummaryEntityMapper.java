package com.manulife.ap.external.persistence.fund.summary.model.mapper;

import com.manulife.ap.core.fund.summary.model.FundSummary;
import com.manulife.ap.external.persistence.fund.summary.model.FundSummaryEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface FundSummaryEntityMapper {
  static FundSummaryEntityMapper get() {
    return FundSummaryEntityMapper.ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final FundSummaryEntityMapper INSTANCE = Mappers.getMapper(FundSummaryEntityMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "fundId", source = "entity.id.fundId")
  @Mapping(target = "fundVersion", source = "entity.id.fundVersion")
  @Mapping(target = "policyNumber", source = "entity.id.policyNumber")
  @Mapping(target = "fundBalance", source = "entity.fundBalance")
  FundSummary toDoaminObject(FundSummaryEntity entity);
}