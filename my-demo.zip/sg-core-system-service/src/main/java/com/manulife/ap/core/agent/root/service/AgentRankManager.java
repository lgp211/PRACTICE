package com.manulife.ap.core.agent.root.service;

import com.manulife.ap.core.agent.root.model.AgentRank;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class AgentRankManager implements AgentRankService {
  private final AgentRepository agentRepository;

  @Override
  public List<AgentRank> findAllByRankCodeIn(List<String> rankCodes) {
    if (Objects.isNull(rankCodes) || rankCodes.isEmpty()) {
      return Collections.emptyList();
    }

    return agentRepository.findAllRanksByRankCodeIn(rankCodes);
  }
}
