package com.manulife.ap.external.persistence.agent.hierarchy;

import com.manulife.ap.core.agent.hierarchy.model.Agency;
import com.manulife.ap.core.agent.hierarchy.service.AgentHierarchyRepository;
import com.manulife.ap.external.persistence.agent.hierarchy.model.mapper.AgentStructureGroupEntityMapper;
import com.manulife.ap.external.persistence.agent.hierarchy.repository.AgentStructureGroupEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class AgentHierarchyJpaRepository implements AgentHierarchyRepository {
  private final AgentStructureGroupEntityRepository agentStructureGroupEntityRepository;

  @Override
  public List<Agency> findAllAgenciesByAgencyCodesIn(final List<String> agencyCodes) {
    if (Objects.isNull(agencyCodes) || agencyCodes.isEmpty()) {
      return Collections.emptyList();
    }

    return agentStructureGroupEntityRepository.findAllById(agencyCodes)
      .parallelStream()
      .map(structureGroupEntity -> AgentStructureGroupEntityMapper.get().toAgency(structureGroupEntity))
      .collect(Collectors.toList());
  }

  @Override
  public List<Agency> findAllAgenciesByManagerIn(final List<String> managerAgentCodes) {
    if (Objects.isNull(managerAgentCodes) || managerAgentCodes.isEmpty()) {
      return Collections.emptyList();
    }

    return agentStructureGroupEntityRepository.findAllByManagerCodeIn(managerAgentCodes)
      .parallelStream()
      .map(structureGroupEntity -> AgentStructureGroupEntityMapper.get().toAgency(structureGroupEntity))
      .collect(Collectors.toList());
  }
}
