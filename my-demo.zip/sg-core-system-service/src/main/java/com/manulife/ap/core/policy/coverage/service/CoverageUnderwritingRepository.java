package com.manulife.ap.core.policy.coverage.service;

import com.manulife.ap.core.policy.coverage.model.CoverageUnderwriting;

import java.util.List;
import java.util.Set;

public interface CoverageUnderwritingRepository {
  List<CoverageUnderwriting> findAllByPolicyNumberIn(Set<String> policyNumbers);
}