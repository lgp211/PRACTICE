package com.manulife.ap.core.product.root.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.util.Optional;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductSearchCriteria {

  @NotBlank(message = "Plan code is mandatory")
  private String planCode;
  @NotBlank(message = "Plan version is mandatory")
  private String planVersion;
  @NotBlank(message = "Currency code is mandatory")
  private String currencyCode;
  private Integer benefitDuration;
  private Integer premiumDuration;

  public ProductKey toProductKey() {
    return ProductKey.builder()
      .planCode(this.planCode)
      .planVersion(this.planVersion)
      .currencyCode(this.currencyCode)
      .build();
  }

  public boolean isProductMatch(final Product product) {
    return Optional.ofNullable(product)
      .map(p -> this.planCode.equals(product.getPlanCode()) &&
        this.planVersion.equals(product.getPlanVersion()) &&
        this.currencyCode.equals(product.getCurrency().getCode()))
      .orElse(false);
  }
}
