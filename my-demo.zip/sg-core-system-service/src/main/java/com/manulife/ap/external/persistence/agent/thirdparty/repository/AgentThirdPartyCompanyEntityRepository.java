package com.manulife.ap.external.persistence.agent.thirdparty.repository;

import com.manulife.ap.external.persistence.agent.thirdparty.model.AgentThirdPartyCompanyEntity;
import com.manulife.ap.external.persistence.agent.thirdparty.model.AgentThirdPartyCompanyId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AgentThirdPartyCompanyEntityRepository
  extends JpaRepository<AgentThirdPartyCompanyEntity, AgentThirdPartyCompanyId> {

  List<AgentThirdPartyCompanyEntity> findAllByIdIn(List<AgentThirdPartyCompanyId> companyIds);
}
