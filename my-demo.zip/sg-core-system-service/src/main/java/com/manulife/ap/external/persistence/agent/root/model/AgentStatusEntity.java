package com.manulife.ap.external.persistence.agent.root.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "TAMS_STATUS")
public class AgentStatusEntity {
  @Id
  @Column(name = "STAT_CD")
  private String code;
  @Column(name = "STAT_DESC")
  private String description;
  @Column(name = "STAT_TYP")
  private String type;
  @Column(name = "CAS_STAT_CD")
  private String casStatusCode;
  @Column(name = "AGT_STAT_IND")
  private String agentStatusIndicator;
  @Column(name = "GRP_STAT_IND")
  private String groupStatusIndicator;
}
