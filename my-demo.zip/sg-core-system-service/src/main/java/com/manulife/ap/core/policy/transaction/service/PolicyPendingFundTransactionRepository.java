package com.manulife.ap.core.policy.transaction.service;

import com.manulife.ap.core.policy.transaction.model.PolicyPendingFundTransaction;

import java.util.List;
import java.util.Set;

public interface PolicyPendingFundTransactionRepository {
  List<PolicyPendingFundTransaction> findAllByPolicyNumbers(Set<String> policyNumbers);
}
