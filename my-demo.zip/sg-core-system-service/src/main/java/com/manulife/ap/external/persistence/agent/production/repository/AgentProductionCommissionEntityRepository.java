package com.manulife.ap.external.persistence.agent.production.repository;

import com.manulife.ap.external.persistence.agent.production.model.AgentProductionCommissionEntity;
import com.manulife.ap.external.persistence.agent.production.model.AgentProductionCommissionId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AgentProductionCommissionEntityRepository
  extends JpaRepository<AgentProductionCommissionEntity, AgentProductionCommissionId> {

  List<AgentProductionCommissionEntity> findByIdAgentCodeAndIdProductionMonthInAndCurrencyCodeIn(
    String agentCode, List<String> productionMonths, List<String> currencyCodes);

  List<AgentProductionCommissionEntity> findByTaggingUnitCodeAndIdProductionMonthInAndCurrencyCodeIn(
    String unitCode, List<String> productionMonths, List<String> currencyCodes);

  List<AgentProductionCommissionEntity> findByTaggingBranchCodeAndIdProductionMonthInAndCurrencyCodeIn(
    String branchCode, List<String> productionMonths, List<String> currencyCodes);

  List<AgentProductionCommissionEntity> findByReportingUnitCodeAndIdProductionMonthInAndCurrencyCodeIn(
    String unitCode, List<String> productionMonths, List<String> currencyCodes);

  List<AgentProductionCommissionEntity> findByReportingBranchCodeAndIdProductionMonthInAndCurrencyCodeIn(
    String branchCode, List<String> productionMonths, List<String> currencyCodes);
}
