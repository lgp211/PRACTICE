package com.manulife.ap.core.agent.production.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.Optional;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AgentProductionDetails {
  private String month;
  private String agentCode;
  private String policyNumber;
  private String planCode;
  private String planName;
  private String currencyCode;
  private LocalDate date;
  private String description;
  private AgentProductionStructure tagging;
  private AgentProductionStructure reporting;
  private AgentProductionConservation conservation;
  @NotNull @Valid
  private AgentProductionDetailsSummary nac;
  private AgentProductionDetailsSummary caseCount;

  /**
   * Compute conservation rate using following formula.
   * rate = (NAC Net Total / NAC Gross Total) * 100
   *
   * @return conservation rate
   */
  public AgentProductionDetails computeConservationRate() {
    double conservationRate = 0;
    long violationCount = Validation.buildDefaultValidatorFactory().getValidator().validate(this).size();

    if (violationCount == 0) {
      conservationRate = (nac.getNetTotal().doubleValue() / nac.getGrossTotal().doubleValue()) * 100;
    }

    this.conservation = Optional.ofNullable(this.conservation).orElse(AgentProductionConservation.builder().build());
    this.conservation.setRate(conservationRate);

    return this;
  }
}
