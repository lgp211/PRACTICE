package com.manulife.ap.core.servicerequest.root.service;

import com.manulife.ap.core.servicerequest.root.model.ServiceRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.stream.Collectors;

import static com.manulife.ap.common.util.StreamUtil.distinctByKey;

@RequiredArgsConstructor
@Slf4j
public class ServiceRequestManager implements ServiceRequestService {

  private final ServiceRequestRepository repository;

  @Override
  public List<ServiceRequest> findAllByPolicyNumber(Set<String> policyNumbers) {
    return Optional.ofNullable(policyNumbers)
      .map(list -> repository.findAllByPolicyNumber(list).stream()
        .filter(Objects::nonNull)
        .filter(distinctByKey(ServiceRequest::getSubmissionDate))
        .collect(Collectors.toList())
      )
      .orElse(Collections.emptyList());
  }
}
