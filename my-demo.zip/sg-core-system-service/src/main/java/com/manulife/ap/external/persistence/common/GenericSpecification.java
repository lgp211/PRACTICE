package com.manulife.ap.external.persistence.common;

import com.manulife.ap.core.common.model.FilterCriteria;
import com.manulife.ap.core.common.model.FilterOperation;
import com.manulife.ap.core.common.model.FilterValueDataType;
import lombok.Builder;
import lombok.Getter;
import lombok.Singular;
import org.jetbrains.annotations.NotNull;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Getter
@Builder
public class GenericSpecification<T> implements Specification<T> {

  @Singular
  private final List<FilterCriteria> filters;

  @Override
  public Predicate toPredicate(
    @NotNull Root<T> root,
    @NotNull CriteriaQuery<?> criteriaQuery,
    @NotNull CriteriaBuilder criteriaBuilder) {

    // Create a new predicate list
    List<Predicate> predicates = new ArrayList<>();

    // Add filter into predicates
    for (FilterCriteria filter : filters) {

      if (FilterOperation.IN.equals(filter.getOperation())) {
        CriteriaBuilder.In<String> inClause = criteriaBuilder.in(root.get(filter.getKey()));
        filter.getValueAsList().forEach(inClause::value);
        predicates.add(inClause);
      }

      if (FilterOperation.EQUAL.equals(filter.getOperation())) {
        predicates.add(criteriaBuilder.equal(root.get(filter.getKey()), filter.getValue()));
      }

      if (FilterOperation.BETWEEN.equals(filter.getOperation())) {
        String valueFrom = filter.getValue().substring(0, filter.getValue().indexOf(',')).trim();
        String valueTo = filter.getValue().substring(filter.getValue().indexOf(',') + 1).trim();

        if (FilterValueDataType.LOCAL_DATE.equals(filter.getValueDataType())) {
          predicates.add(
            criteriaBuilder.between(root.get(filter.getKey()), LocalDate.parse(valueFrom), LocalDate.parse(valueTo))
          );
        } else {
          predicates.add(
            criteriaBuilder.between(root.get(filter.getKey()), valueFrom, valueTo)
          );
        }
      }
    }

    return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
  }
}
