package com.manulife.ap.core.product.configuration.service;

import com.manulife.ap.core.product.configuration.model.ProductConfigurationCategory;
import com.manulife.ap.core.product.configuration.model.ProductConfigurationField;
import com.manulife.ap.core.product.root.model.ProductKey;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Set;

public interface ProductConfigurationFieldRepository {
  List<ProductConfigurationField> findAllByProductKey(
    @Valid Set<ProductKey> productKeyList,
    @NotNull(message = "Product configuration category cannot be null") ProductConfigurationCategory category);
}
