package com.manulife.ap.external.persistence.policy.coverage.model.mapper;

import com.manulife.ap.core.policy.coverage.model.CoverageUnderwritingStatus;
import com.manulife.ap.external.persistence.policy.coverage.model.CoverageUnderwritingEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface CoverageUnderwritingStatusEntityMapper {
  static CoverageUnderwritingStatusEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final CoverageUnderwritingStatusEntityMapper INSTANCE = Mappers.getMapper(CoverageUnderwritingStatusEntityMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "policyNumber", source = "entity.policyNumber")
  @Mapping(target = "code", source = "entity.status")
  CoverageUnderwritingStatus toCoverageUnderwritingStatus(CoverageUnderwritingEntity entity);
}