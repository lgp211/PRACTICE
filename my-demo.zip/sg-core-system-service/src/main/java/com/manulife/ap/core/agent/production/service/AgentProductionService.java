package com.manulife.ap.core.agent.production.service;

import com.manulife.ap.core.agent.production.model.AgentProduction;
import com.manulife.ap.core.agent.production.model.filter.AgentProductionSearchCriteria;
import com.manulife.ap.core.agent.production.model.AgentProductionTransaction;
import com.manulife.ap.core.agent.production.model.filter.BranchProductionSearchCriteria;
import com.manulife.ap.core.agent.production.model.filter.UnitProductionSearchCriteria;

import javax.validation.Valid;
import java.util.List;

public interface AgentProductionService {
  AgentProduction findByAgentCriteria(@Valid AgentProductionSearchCriteria searchCriteria);

  List<AgentProductionTransaction> findByTaggingUnit(@Valid UnitProductionSearchCriteria searchCriteria);

  List<AgentProductionTransaction> findByTaggingBranch(@Valid BranchProductionSearchCriteria searchCriteria);

  List<AgentProductionTransaction> findByReportingUnit(@Valid UnitProductionSearchCriteria searchCriteria);

  List<AgentProductionTransaction> findByReportingBranch(@Valid BranchProductionSearchCriteria searchCriteria);
}
