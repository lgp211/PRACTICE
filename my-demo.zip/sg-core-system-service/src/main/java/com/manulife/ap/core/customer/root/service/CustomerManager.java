package com.manulife.ap.core.customer.root.service;

import com.manulife.ap.core.common.model.FilterCriteria;
import com.manulife.ap.core.customer.root.model.Customer;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import java.util.Collections;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.List;
import java.time.LocalDate;

@Service
@RequiredArgsConstructor
@Validated
public class CustomerManager implements CustomerService {
  private final CustomerRepository repository;

  @Override
  public List<Customer> findAllByClientNumberIn(final List<String> clientNumbers) {
    return Optional.ofNullable(clientNumbers)
      .map(clientNumberList ->
        repository.findAllByClientNumberIn(clientNumberList).stream()
          .map(customer -> {
            customer.setAge(customer.getAgeAsOf(LocalDate.now()));
            return customer;
          })
          .collect(Collectors.toList())
      )
      .orElse(Collections.emptyList());
  }

  @Override
  public List<Customer> findAllByCriteria(final List<FilterCriteria> filterCriteriaList) {
    return Optional.ofNullable(filterCriteriaList)
      .map(list -> repository.findAllByCriteria(filterCriteriaList))
      .orElse(Collections.emptyList());
  }
}
