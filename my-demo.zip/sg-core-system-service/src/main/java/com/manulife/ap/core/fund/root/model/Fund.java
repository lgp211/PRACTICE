package com.manulife.ap.core.fund.root.model;

import com.manulife.ap.core.fund.price.model.FundPrice;
import com.manulife.ap.core.fund.summary.model.FundSummary;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Fund {
  private String fundId;
  private String fundVersion;
  private String description;
  private LocalDate effectiveStartDate;
  private LocalDate effectiveEndDate;
  private FundCurrency currency;
  private String type;
  private FundSummary summary;
  private List<FundPrice> prices;
}