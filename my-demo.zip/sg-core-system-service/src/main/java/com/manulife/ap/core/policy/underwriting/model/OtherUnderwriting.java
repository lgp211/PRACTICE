package com.manulife.ap.core.policy.underwriting.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OtherUnderwriting {
  private String policyNumber;
  private Integer sequenceNumber;
  private String description;
  private LocalDate startDate;
  private LocalDate endDate;
}
