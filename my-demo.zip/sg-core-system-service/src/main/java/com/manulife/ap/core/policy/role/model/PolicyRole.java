package com.manulife.ap.core.policy.role.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyRole {
  private String policyNumber;
  private String clientNumber;
  private PolicyRoleType type;
}
