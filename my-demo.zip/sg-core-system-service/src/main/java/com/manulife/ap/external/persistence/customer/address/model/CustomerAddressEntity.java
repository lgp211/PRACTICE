package com.manulife.ap.external.persistence.customer.address.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "TCLIENT_ADDRESSES")
public class CustomerAddressEntity {
  @EmbeddedId
  private CustomerAddressId id;

  @Column(name = "ADDR_1")
  private String line1;

  @Column(name = "ADDR_2")
  private String line2;

  @Column(name = "ADDR_3")
  private String line3;

  @Column(name = "ADDR_4")
  private String line4;

  @Column(name = "ZIP_CODE")
  private String postalCode;

  @Column(name = "INVALID_ADDR_IND")
  private String active;


}
