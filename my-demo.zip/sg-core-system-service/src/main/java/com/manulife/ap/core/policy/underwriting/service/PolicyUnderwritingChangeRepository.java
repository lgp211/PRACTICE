package com.manulife.ap.core.policy.underwriting.service;

import com.manulife.ap.core.policy.underwriting.model.PolicyUnderwritingChange;

import java.util.List;
import java.util.Set;

public interface PolicyUnderwritingChangeRepository {
  List<PolicyUnderwritingChange> findAllByPolicyNumbers(Set<String> policyNumbers);
}
