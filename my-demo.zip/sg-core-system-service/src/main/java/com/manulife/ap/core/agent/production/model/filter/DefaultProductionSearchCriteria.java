package com.manulife.ap.core.agent.production.model.filter;

import lombok.AllArgsConstructor;
import lombok.Getter;

import javax.validation.Validation;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Getter
@AllArgsConstructor
public abstract class DefaultProductionSearchCriteria {

  @NotBlank(message = "First month is mandatory")
  @Pattern(regexp = "^\\d{4}(0[1-9]|1[012])$", message = "First month must be in six-characters format of YYYYMM")
  private final String firstMonth;

  @NotBlank(message = "Last month is mandatory")
  @Pattern(regexp = "^\\d{4}(0[1-9]|1[012])$", message = "Last month must be in six-characters format of YYYYMM")
  private final String lastMonth;

  private final List<String> currencyCodes;

  public boolean isValid() {
    return Validation.buildDefaultValidatorFactory().getValidator()
      .validate(this)
      .isEmpty();
  }

  /**
   * Return months in between <code>firstMonth</code> and <code>lastMonth</code> inclusively.
   * e.g. firstMonth is 202001 and lastMonth is 202003, then returning list contains 202001, 202002, 202003
   *
   * @return list of month in format of YYYYMM; otherwise empty list if <code>firstMonth</code> and
   * <code>lastMonth</code> are not in correct format or order.
   */
  public List<String> getMonths() {
    if (!this.isValid()) {
      return Collections.emptyList();
    }

    int firstYearInNumber = Integer.parseInt(this.firstMonth.substring(0, 4));
    int firstMonthInNumber = Integer.parseInt(this.firstMonth.substring(4, 6));
    int lastYearInNumber = Integer.parseInt(this.lastMonth.substring(0, 4));
    int lastMonthInNumber = Integer.parseInt(this.lastMonth.substring(4, 6));

    int year;
    int month;
    List<String> months = new ArrayList<>();
    DecimalFormat df = new DecimalFormat("#00");

    for (year = firstYearInNumber ; year <= lastYearInNumber ; year++) {
      int initialMonth = 1;
      if (year == firstYearInNumber) {
        initialMonth = firstMonthInNumber;
      }

      int monthLimit = 12;
      if (year == lastYearInNumber) {
        monthLimit = lastMonthInNumber;
      }

      for (month = initialMonth ; month <= monthLimit ; month++) {
        months.add(year + df.format(month));
      }
    }

    return months;
  }

  /**
   * Check if given production month match with value between <code>firstMonth</code> and <code>lastMonth</code>.
   *
   * @param month Production month to compare (format in YYYYMM).
   * @return <code>true</code> if given production month found in list; otherwise <code>false</code>.
   */
  public boolean anyMatchWithMonth(final String month) {
    return this.getMonths().contains(month);
  }

  /**
   * Check if given currency code match with any value from currencyCodes.
   *
   * @param currencyCode Currency code to compare.
   * @return <code>true</code> if given currency code found in list; otherwise <code>false</code>.
   */
  public boolean anyMatchWithCurrencyCode(final String currencyCode) {
    return this.getCurrencyCodes().contains(currencyCode);
  }
}
