package com.manulife.ap.core.product.root.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Optional;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductVariant {
  private Integer premiumDuration;
  private Integer benefitDuration;
  private String marketingName;

  public boolean isPremiumDurationExactMatch(final Integer duration) {
    return Optional.ofNullable(this.premiumDuration)
      .map(d -> d.equals(duration))
      .orElse(false);
  }

  public boolean isBenefitDurationExactMatch(final Integer duration) {
    return Optional.ofNullable(this.benefitDuration)
      .map(d -> d.equals(duration))
      .orElse(false);
  }
}
