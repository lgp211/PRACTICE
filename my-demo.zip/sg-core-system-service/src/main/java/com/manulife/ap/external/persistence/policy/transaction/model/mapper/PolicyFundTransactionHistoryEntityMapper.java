package com.manulife.ap.external.persistence.policy.transaction.model.mapper;

import com.manulife.ap.common.mapper.LocalDateMapper;
import com.manulife.ap.common.mapper.LocalDateMapping;
import com.manulife.ap.common.mapper.StringToLocalDate;
import com.manulife.ap.core.policy.transaction.model.PolicyFundTransactionHistory;
import com.manulife.ap.external.persistence.policy.transaction.model.PolicyFundTransactionHistoryEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Collection;
import java.util.List;

@Mapper(uses = LocalDateMapping.class)
public interface PolicyFundTransactionHistoryEntityMapper {

  static PolicyFundTransactionHistoryEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final PolicyFundTransactionHistoryEntityMapper INSTANCE = Mappers.getMapper(PolicyFundTransactionHistoryEntityMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "policyNumber", source = "entity.id.policyNumber")
  @Mapping(target = "transactionId", source = "entity.id.transactionId")
  @Mapping(target = "fundTransactionNumber", source = "entity.id.fundTransactionNumber")
  @Mapping(target = "fundId", source = "entity.fundId")
  @Mapping(target = "fundVersion", source = "entity.fundVersion")
  @Mapping(target = "type.code", source = "entity.transactionType")
  @Mapping(target = "date", source = "entity.transactionDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "code.code", source = "entity.transactionCode")
  @Mapping(target = "amount", source = "entity.amount")
  PolicyFundTransactionHistory toPolicyFundTransactionHistory(PolicyFundTransactionHistoryEntity entity);

  List<PolicyFundTransactionHistory> toPolicyFundTransactionHistoryList(Collection<PolicyFundTransactionHistoryEntity> policyFundTransactionHistoryList);

}
