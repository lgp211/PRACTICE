package com.manulife.ap.core.fund.summary.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FundSummaryKey {
  private String fundId;
  private String fundVersion;
}