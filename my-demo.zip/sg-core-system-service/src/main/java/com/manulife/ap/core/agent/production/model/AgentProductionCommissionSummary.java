package com.manulife.ap.core.agent.production.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AgentProductionCommissionSummary {
  private Double efyc;
  private Double afyc;
  private Double nac;
  private Integer caseCount;
  private Double anp;
  private Double premiumAmount;
  private Double netApe;
}
