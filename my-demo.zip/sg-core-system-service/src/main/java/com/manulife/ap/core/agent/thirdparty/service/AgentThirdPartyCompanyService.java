package com.manulife.ap.core.agent.thirdparty.service;

import com.manulife.ap.core.agent.thirdparty.model.AgentThirdPartyCompany;
import com.manulife.ap.core.agent.thirdparty.model.AgentThirdPartyCompanyKey;

import java.util.List;

public interface AgentThirdPartyCompanyService {
  List<AgentThirdPartyCompany> findAllByKeyIn(List<AgentThirdPartyCompanyKey> keys);
}
