package com.manulife.ap.core.product.root.service;

import com.manulife.ap.core.product.root.model.Product;
import com.manulife.ap.core.product.root.model.ProductSearchCriteria;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Set;

public interface ProductService {
  List<Product> findAllByProductCriteria(
    @Valid @NotNull(message = "Search criteria cannot be null") Set<ProductSearchCriteria> searchCriteria);
}
