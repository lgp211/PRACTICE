package com.manulife.ap.core.customer.address.service;

import com.manulife.ap.core.customer.address.model.CustomerAddress;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import static java.util.stream.Collectors.groupingBy;

import java.util.*;

@Service
@RequiredArgsConstructor
public class CustomerAddressManager implements CustomerAddressService {
  private final CustomerAddressRepository repository;

  @Override
  public Map<String, List<CustomerAddress>> findAllByClientNumberIn(final List<String> clientNumbers) {
    if (Objects.isNull(clientNumbers) || clientNumbers.isEmpty()) {
      return Collections.emptyMap();
    }

    return repository.findAllByClientNumberIn(clientNumbers).stream()
      .collect(groupingBy(CustomerAddress::getClientNumber));

  }
}
