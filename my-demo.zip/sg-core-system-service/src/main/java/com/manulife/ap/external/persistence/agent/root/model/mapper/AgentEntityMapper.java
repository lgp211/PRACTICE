package com.manulife.ap.external.persistence.agent.root.model.mapper;

import com.manulife.ap.common.mapper.*;
import com.manulife.ap.core.agent.root.model.Agent;
import com.manulife.ap.external.persistence.agent.root.model.AgentEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = {LocalDateMapping.class, BooleanMapping.class})
public interface AgentEntityMapper {
  static AgentEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final AgentEntityMapper INSTANCE = Mappers.getMapper(AgentEntityMapper.class);
    private ModelMapperInstance() {}
  }

  @Mapping(target = "agentCode", source = "entity.agentCode")
  @Mapping(target = "candidateNumber", source = "entity.candidateNumber")
  @Mapping(target = "name.fullName", source = "entity.name")
  @Mapping(target = "status.code", source = "entity.status")
  @Mapping(target = "email.address", source = "entity.emailAddress")
  @Mapping(target = "rank.code", source = "entity.rankCode")
  @Mapping(target = "rank.effectiveDate", source = "entity.rankEffectiveDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "contract.licenseNumber", source = "entity.licenseNumber")
  @Mapping(target = "contract.effectiveDate", source = "entity.contractEffectiveDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "contract.signDate", source = "entity.contractSignDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "contract.terminationDate", source = "entity.terminationDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "contract.suspended", source = "entity.suspendIndicator", qualifiedBy = {BooleanMapper.class, StringToBoolean.class})
  @Mapping(target = "training.agentCode", source = "entity.originalAgentCode")
  @Mapping(target = "branchCode", source = "entity.branchCode")
  @Mapping(target = "unitCode", source = "entity.unitCode")
  @Mapping(target = "reporting.unitCode", source = "entity.reportingUnitCode")
  Agent toAgent(AgentEntity entity);
}
