package com.manulife.ap.external.persistence.policy.fund.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TFUND_ALLOCATIONS")
public class PolicyFundAllocationEntity {

  @EmbeddedId
  private PolicyFundAllocationId id;

  @Column(name = "ALLOC_PCT")
  private Double percentage;
}
