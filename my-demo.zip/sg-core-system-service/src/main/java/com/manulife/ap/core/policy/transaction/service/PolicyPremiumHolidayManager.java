package com.manulife.ap.core.policy.transaction.service;

import com.manulife.ap.core.policy.transaction.model.PolicyPremiumHoliday;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class PolicyPremiumHolidayManager implements PolicyPremiumHolidayService {

  private final PolicyPremiumHolidayRepository policyPremiumHolidayRepository;

  @Override
  public Map<String, List<PolicyPremiumHoliday>> findAllByPolicyNumbers(final Set<String> policyNumbers) {
    if (Objects.isNull(policyNumbers) || policyNumbers.isEmpty()) {
      return Collections.emptyMap();
    }

    return policyPremiumHolidayRepository.findAllByPolicyNumbers(policyNumbers)
      .parallelStream()
      .collect(groupingBy(PolicyPremiumHoliday::getPolicyNumber));
  }
}
