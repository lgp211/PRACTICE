package com.manulife.ap.core.agent.production.service;

import com.manulife.ap.core.agent.production.model.AgentProductionCommission;
import com.manulife.ap.core.agent.production.model.AgentProductionDetails;
import com.manulife.ap.core.agent.production.model.filter.AgentProductionSearchCriteria;
import com.manulife.ap.core.agent.production.model.filter.BranchProductionSearchCriteria;
import com.manulife.ap.core.agent.production.model.filter.UnitProductionSearchCriteria;

import java.util.List;

public interface AgentProductionRepository {
  List<AgentProductionCommission> findAllProductionCommissionByAgentCriteria(AgentProductionSearchCriteria searchCriteria);

  List<AgentProductionDetails> findAllProductionDetailsByAgentCriteria(AgentProductionSearchCriteria searchCriteria);

  List<AgentProductionCommission> findAllProductionCommissionByTaggingUnit(UnitProductionSearchCriteria searchCriteria);

  List<AgentProductionDetails> findAllProductionDetailsByTaggingUnit(UnitProductionSearchCriteria searchCriteria);

  List<AgentProductionCommission> findAllProductionCommissionByTaggingBranch(BranchProductionSearchCriteria searchCriteria);

  List<AgentProductionDetails> findAllProductionDetailsByTaggingBranch(BranchProductionSearchCriteria searchCriteria);

  List<AgentProductionCommission> findAllProductionCommissionByReportingUnit(UnitProductionSearchCriteria searchCriteria);

  List<AgentProductionDetails> findAllProductionDetailsByReportingUnit(UnitProductionSearchCriteria searchCriteria);

  List<AgentProductionCommission> findAllProductionCommissionByReportingBranch(BranchProductionSearchCriteria searchCriteria);

  List<AgentProductionDetails> findAllProductionDetailsByReportingBranch(BranchProductionSearchCriteria searchCriteria);
}
