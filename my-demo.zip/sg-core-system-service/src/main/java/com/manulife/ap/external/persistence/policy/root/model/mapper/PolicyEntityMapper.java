package com.manulife.ap.external.persistence.policy.root.model.mapper;

import com.manulife.ap.common.mapper.*;
import com.manulife.ap.core.policy.root.model.Policy;
import com.manulife.ap.core.policy.root.model.PolicyAgent;
import com.manulife.ap.core.policy.root.model.field.PolicyAgentType;
import com.manulife.ap.external.persistence.policy.root.model.PolicyEntity;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Mapper(uses = {LocalDateMapping.class, BooleanMapping.class})
public interface PolicyEntityMapper {
  static PolicyEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final PolicyEntityMapper INSTANCE = Mappers.getMapper(PolicyEntityMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "policyNumber", source = "policy.policyNumber")
  @Mapping(target = "status.code", source = "policy.status")
  @Mapping(target = "effectiveDate", source = "policy.effectiveDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "terminationDate", source = "policy.terminationDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "sliActivationDate", source = "policy.sliActivationDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "submission.date", source = "policy.submissionDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "submission.type.code", source = "policy.submissionType")
  @Mapping(target = "currency.code", source = "policy.currencyCode")
  @Mapping(target = "paidToDate", source = "policy.paidToDate")
  @Mapping(target = "lastAnniversaryDate", source = "policy.lastAnniversaryDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "premium.modeAmount", source = "policy.modeAmount")
  @Mapping(target = "premium.planAmount", source = "policy.planAmount")
  @Mapping(target = "premium.discountAmount", source = "policy.discountAmount")
  @Mapping(target = "premium.suspenseAmount", source = "policy.suspenseAmount")
  @Mapping(target = "premium.suspensePolicy", source = "policy.suspensePolicy")
  @Mapping(target = "premium.holiday.freezeStatus.code", source = "policy.freezeStatus")
  @Mapping(target = "premium.holiday.type", source = "policy.premiumHolidayType")
  @Mapping(target = "premium.holiday.startDate", source = "policy.premiumHolidayStartDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "premium.holiday.endDate", source = "policy.premiumHolidayEndDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "premium.holiday.paidToDate", source = "policy.premiumHolidayPaidToDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "premium.holiday.lastPaidToDate", source = "policy.premiumHolidayLastPaidToDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "configurations.dividend.option.code", source = "policy.dividendOption")
  @Mapping(target = "configurations.deathBenefit.option.code", source = "policy.deathBenefitOption")
  @Mapping(target = "configurations.nfo.option.code", source = "policy.nfoOption")
  @Mapping(target = "configurations.annuity.option.code", source = "policy.annuityOption")
  @Mapping(target = "configurations.annuity.duration", source = "policy.annuityDuration")
  @Mapping(target = "configurations.annuity.frequency", source = "policy.annuityFrequency")
  @Mapping(target = "configurations.accumulation.period", source = "policy.accumulationPeriod")
  @Mapping(target = "configurations.billing.method.code", source = "policy.billingMethod")
  @Mapping(target = "configurations.payment.mode.code", source = "policy.paymentMode")
  @Mapping(target = "configurations.ipo.option.code", source = "policy.ipoOption")
  @Mapping(target = "configurations.giro.effectiveDate", source = "policy.giroEffectiveDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "configurations.giro.status.code", source = "policy.giroStatus")
  @Mapping(target = "configurations.rebalancing.enabled", source = "policy.rebalancingIndicator", qualifiedBy = {BooleanMapper.class, StringToBoolean.class})
  @Mapping(target = "configurations.payForPerformance.choiceIndicator.code", source = "policy.pfpChoiceIndicator")
  @Mapping(target = "configurations.payForPerformance.healthIndicator.code", source = "policy.pfpHealthIndicator")
  @Mapping(target = "configurations.payout.method.code", source = "policy.payoutMethod")
  @Mapping(target = "configurations.trust.type", source = "policy.trustType")
  Policy toDomainObject(PolicyEntity policy);

  List<Policy> toDomainObjectList(Collection<PolicyEntity> policyEntityList);

  @AfterMapping
  default void postConstructPolicyModel(PolicyEntity policyEntity, @MappingTarget Policy policy) {
    policy.setAgents(
      Stream
        .of(
          PolicyAgent.builder()
            .code(policyEntity.getPrimaryServicingAgent())
            .type(PolicyAgentType.PRIMARY_SERVICING_AGENT)
            .build(),
          PolicyAgent.builder()
            .code(policyEntity.getSecondaryServicingAgent())
            .type(PolicyAgentType.SECONDARY_SERVICING_AGENT)
            .build(),
          PolicyAgent.builder()
            .code(policyEntity.getPrimaryWritingAgent())
            .type(PolicyAgentType.PRIMARY_WRITING_AGENT)
            .build(),
          PolicyAgent.builder()
            .code(policyEntity.getSecondaryWritingAgent())
            .type(PolicyAgentType.SECONDARY_WRITING_AGENT)
            .build()
        )
        .filter(e -> Objects.nonNull(e.getCode()))
        .collect(Collectors.toList())
    );
  }
}
