package com.manulife.ap.core.policy.transaction.service;

import com.manulife.ap.core.policy.transaction.model.PolicyPendingFundTransaction;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class PolicyPendingFundTransactionManager implements PolicyPendingFundTransactionService {

  private final PolicyPendingFundTransactionRepository policyPendingFundTransactionRepository;

  @Override
  public Map<String, List<PolicyPendingFundTransaction>> findAllByPolicyNumbers(final Set<String> policyNumbers) {
    return Optional.ofNullable(policyNumbers)
      .map(list -> policyPendingFundTransactionRepository.findAllByPolicyNumbers(list)
        .parallelStream()
        .collect(groupingBy(PolicyPendingFundTransaction::getPolicyNumber))
      )
      .orElse(Collections.emptyMap());
  }
}
