package com.manulife.ap.external.persistence.policy.role.model.mapper;

import com.manulife.ap.core.policy.role.model.PolicyRole;
import com.manulife.ap.external.persistence.policy.role.model.PolicyRoleEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Collection;
import java.util.List;

@Mapper
public interface PolicyRoleEntityMapper {

  static PolicyRoleEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final PolicyRoleEntityMapper INSTANCE = Mappers.getMapper(PolicyRoleEntityMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "policyNumber", source = "policyRole.id.policyNumber")
  @Mapping(target = "clientNumber", source = "policyRole.id.clientNumber")
  @Mapping(target = "type.code", source = "policyRole.id.clientPolicyLinkType")
  PolicyRole toPolicyRole(PolicyRoleEntity policyRole);

  List<PolicyRole> toPolicyRoleList(Collection<PolicyRoleEntity> policyRoleEntityList);

}
