package com.manulife.ap.external.persistence.agent.common;

import com.manulife.ap.core.common.model.FilterCriteria;
import com.manulife.ap.external.persistence.agent.root.model.AgentEntity;
import com.manulife.ap.external.persistence.agent.root.model.filter.AgentEntityFilter;
import com.manulife.ap.external.persistence.common.GenericSpecification;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class AgentSpecificationFactory {

  public static GenericSpecification<AgentEntity> createSpecificationForAgentEntity(
    final List<FilterCriteria> filterCriteriaList) {

    return GenericSpecification.<AgentEntity>builder()
      .filters(
        Optional.ofNullable(filterCriteriaList)
          .map(list -> list.stream()
            .map(filter ->
              FilterCriteria.builder()
                .key(AgentEntityFilter.getColumnNameByFilter(filter.getKey()))
                .operation(filter.getOperation())
                .value(filter.getValue())
                .build()
            )
            .collect(Collectors.toList())
          )
          .orElse(Collections.emptyList())
      )
      .build();
  }
}
