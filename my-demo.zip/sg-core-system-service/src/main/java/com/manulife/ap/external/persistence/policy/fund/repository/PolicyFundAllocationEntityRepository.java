package com.manulife.ap.external.persistence.policy.fund.repository;

import com.manulife.ap.external.persistence.policy.fund.model.PolicyFundAllocationEntity;
import com.manulife.ap.external.persistence.policy.fund.model.PolicyFundAllocationId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface PolicyFundAllocationEntityRepository extends JpaRepository<PolicyFundAllocationEntity, PolicyFundAllocationId> {
  List<PolicyFundAllocationEntity> findAllByIdPolicyNumberIn(Set<String> policyNumbers);
}
