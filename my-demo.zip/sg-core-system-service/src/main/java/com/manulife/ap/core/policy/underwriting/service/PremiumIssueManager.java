package com.manulife.ap.core.policy.underwriting.service;

import com.manulife.ap.core.policy.underwriting.model.PremiumIssue;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class PremiumIssueManager implements PremiumIssueService {

  private final PremiumIssueRepository premiumIssueRepository;

  @Override
  public Map<String, List<PremiumIssue>> findAllByPolicyNumbers(final Set<String> policyNumbers) {
    if (Objects.isNull(policyNumbers) || policyNumbers.isEmpty()) {
      return Collections.emptyMap();
    }

    return premiumIssueRepository.findAllByPolicyNumbers(policyNumbers)
      .parallelStream()
      .collect(groupingBy(PremiumIssue::getPolicyNumber));
  }
}
