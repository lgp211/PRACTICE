package com.manulife.ap.core.agent.production.service;

import com.manulife.ap.core.agent.production.model.AgentProduction;
import com.manulife.ap.core.agent.production.model.AgentProductionCommission;
import com.manulife.ap.core.agent.production.model.AgentProductionDetails;
import com.manulife.ap.core.agent.production.model.filter.AgentProductionSearchCriteria;
import com.manulife.ap.core.agent.production.model.AgentProductionTransaction;
import com.manulife.ap.core.agent.production.model.filter.BranchProductionSearchCriteria;
import com.manulife.ap.core.agent.production.model.filter.UnitProductionSearchCriteria;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
@Validated
public class AgentProductionManager implements AgentProductionService {

  private final AgentProductionRepository agentProductionRepository;

  @Override
  public AgentProduction findByAgentCriteria(final AgentProductionSearchCriteria searchCriteria) {
    Map<String, List<AgentProductionCommission>> commissionMap =
      agentProductionRepository.findAllProductionCommissionByAgentCriteria(searchCriteria)
        .stream()
        .collect(groupingBy(AgentProductionCommission::getMonth));

    Map<String, List<AgentProductionDetails>> detailsMap =
      agentProductionRepository.findAllProductionDetailsByAgentCriteria(searchCriteria)
        .stream()
        .map(AgentProductionDetails::computeConservationRate)
        .collect(groupingBy(AgentProductionDetails::getMonth));

    return AgentProduction.builder()
      .agentCode(searchCriteria.getAgentCode())
      .transactions(
        Stream.of(commissionMap.keySet(), detailsMap.keySet())
          .flatMap(Collection::stream)
          .collect(Collectors.toSet())
          .stream()
          .map(month ->
            AgentProductionTransaction.builder()
              .month(month)
              .commissions(commissionMap.getOrDefault(month, Collections.emptyList()))
              .details(detailsMap.getOrDefault(month, Collections.emptyList()))
              .build()
          )
          .collect(Collectors.toList())
      )
      .build();
  }

  @Override
  public List<AgentProductionTransaction> findByTaggingUnit(final UnitProductionSearchCriteria searchCriteria) {
    Map<String, List<AgentProductionCommission>> commissionMap =
      agentProductionRepository.findAllProductionCommissionByTaggingUnit(searchCriteria)
        .stream()
        .collect(groupingBy(AgentProductionCommission::getMonth));

    Map<String, List<AgentProductionDetails>> detailsMap =
      agentProductionRepository.findAllProductionDetailsByTaggingUnit(searchCriteria)
        .stream()
        .map(AgentProductionDetails::computeConservationRate)
        .collect(groupingBy(AgentProductionDetails::getMonth));

    return Stream.of(commissionMap.keySet(), detailsMap.keySet())
      .flatMap(Collection::stream)
      .collect(Collectors.toSet())
      .stream()
      .map(month ->
        AgentProductionTransaction.builder()
          .month(month)
          .commissions(commissionMap.getOrDefault(month, Collections.emptyList()))
          .details(detailsMap.getOrDefault(month, Collections.emptyList()))
          .build()
      )
      .collect(Collectors.toList());
  }

  @Override
  public List<AgentProductionTransaction> findByTaggingBranch(final BranchProductionSearchCriteria searchCriteria) {
    Map<String, List<AgentProductionCommission>> commissionMap =
      agentProductionRepository.findAllProductionCommissionByTaggingBranch(searchCriteria)
        .stream()
        .collect(groupingBy(AgentProductionCommission::getMonth));

    Map<String, List<AgentProductionDetails>> detailsMap =
      agentProductionRepository.findAllProductionDetailsByTaggingBranch(searchCriteria)
        .stream()
        .map(AgentProductionDetails::computeConservationRate)
        .collect(groupingBy(AgentProductionDetails::getMonth));

    return Stream.of(commissionMap.keySet(), detailsMap.keySet())
      .flatMap(Collection::stream)
      .collect(Collectors.toSet())
      .stream()
      .map(month ->
        AgentProductionTransaction.builder()
          .month(month)
          .commissions(commissionMap.getOrDefault(month, Collections.emptyList()))
          .details(detailsMap.getOrDefault(month, Collections.emptyList()))
          .build()
      )
      .collect(Collectors.toList());
  }

  @Override
  public List<AgentProductionTransaction> findByReportingUnit(@Valid UnitProductionSearchCriteria searchCriteria) {
    Map<String, List<AgentProductionCommission>> commissionMap =
      agentProductionRepository.findAllProductionCommissionByReportingUnit(searchCriteria)
        .stream()
        .collect(groupingBy(AgentProductionCommission::getMonth));

    Map<String, List<AgentProductionDetails>> detailsMap =
      agentProductionRepository.findAllProductionDetailsByReportingUnit(searchCriteria)
        .stream()
        .map(AgentProductionDetails::computeConservationRate)
        .collect(groupingBy(AgentProductionDetails::getMonth));

    return Stream.of(commissionMap.keySet(), detailsMap.keySet())
      .flatMap(Collection::stream)
      .collect(Collectors.toSet())
      .stream()
      .map(month ->
        AgentProductionTransaction.builder()
          .month(month)
          .commissions(commissionMap.getOrDefault(month, Collections.emptyList()))
          .details(detailsMap.getOrDefault(month, Collections.emptyList()))
          .build()
      )
      .collect(Collectors.toList());
  }

  @Override
  public List<AgentProductionTransaction> findByReportingBranch(@Valid BranchProductionSearchCriteria searchCriteria) {
    Map<String, List<AgentProductionCommission>> commissionMap =
      agentProductionRepository.findAllProductionCommissionByReportingBranch(searchCriteria)
        .stream()
        .collect(groupingBy(AgentProductionCommission::getMonth));

    Map<String, List<AgentProductionDetails>> detailsMap =
      agentProductionRepository.findAllProductionDetailsByReportingBranch(searchCriteria)
        .stream()
        .map(AgentProductionDetails::computeConservationRate)
        .collect(groupingBy(AgentProductionDetails::getMonth));

    return Stream.of(commissionMap.keySet(), detailsMap.keySet())
      .flatMap(Collection::stream)
      .collect(Collectors.toSet())
      .stream()
      .map(month ->
        AgentProductionTransaction.builder()
          .month(month)
          .commissions(commissionMap.getOrDefault(month, Collections.emptyList()))
          .details(detailsMap.getOrDefault(month, Collections.emptyList()))
          .build()
      )
      .collect(Collectors.toList());
  }
}
