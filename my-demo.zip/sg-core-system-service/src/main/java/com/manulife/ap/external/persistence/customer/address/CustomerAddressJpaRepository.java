package com.manulife.ap.external.persistence.customer.address;

import com.manulife.ap.core.customer.address.model.CustomerAddress;
import com.manulife.ap.core.customer.address.service.CustomerAddressRepository;
import com.manulife.ap.external.persistence.customer.address.model.mapper.CustomerAddressEntityMapper;
import com.manulife.ap.external.persistence.customer.address.repository.CustomerAddressEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class CustomerAddressJpaRepository implements CustomerAddressRepository {
  private final CustomerAddressEntityRepository customerAddressEntityRepository;

  @Override
  public List<CustomerAddress> findAllByClientNumberIn(final List<String> clientNumber) {
    if (Objects.isNull(clientNumber) || clientNumber.isEmpty()) {
      return Collections.emptyList();
    }

    return customerAddressEntityRepository.findAllByIdClientNumberIn(clientNumber)
      .parallelStream()
      .map(addressEntity -> CustomerAddressEntityMapper.get().toCustomerAddress(addressEntity))
      .collect(Collectors.toList());
  }
}
