package com.manulife.ap.core.policy.transaction.service;

import com.manulife.ap.core.policy.transaction.model.PolicyFundTransactionHistory;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface PolicyFundTransactionHistoryService {
  Map<String, List<PolicyFundTransactionHistory>> findAllByPolicyNumbers(Set<String> policyNumbers);
}
