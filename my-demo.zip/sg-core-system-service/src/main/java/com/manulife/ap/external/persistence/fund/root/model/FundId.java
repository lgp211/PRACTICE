package com.manulife.ap.external.persistence.fund.root.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FundId implements Serializable {
  @Column(name = "FND_ID")
  private String fundId;
  @Column(name = "FND_VERS")
  private String fundVersion;
}