package com.manulife.ap.external.persistence.agent.production.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "TAMS_CRR_SUMM_BK_SG")
public class AgentProductionCommissionEntity {
  @EmbeddedId
  private AgentProductionCommissionId id;

  @Column(name = "PLAN_TYP")
  private String planType;

  @Column(name = "CRCY_CD")
  private String currencyCode;

  @Column(name = "PLAN_NM")
  private String planName;

  @Column(name = "POL_EFF_DT")
  private String policyEffectiveDate;

  @Column(name = "AGT_SPLT_RT")
  private Double splitRatio;

  @Column(name = "FMLY_IND")
  private String familyIndicator;

  @Column(name = "EFYC")
  private Double efyc;

  @Column(name = "AFYC")
  private Double afyc;

  @Column(name = "NAC")
  private Double nac;

  @Column(name = "CASE_CNT")
  private Integer caseCount;

  @Column(name = "NETT_APE")
  private Double netApe;

  @Column(name = "SP_ANP")
  private Double spAnp;

  @Column(name = "SP_PREM_AMT")
  private Double spPremiumAmount;

  @Column(name = "SP_CASE_CNT")
  private Integer spCaseCount;

  @Column(name = "SP_EFYC")
  private Double spEfyc;

  @Column(name = "SP_NAC")
  private Double spNac;

  @Column(name = "RP_ANP")
  private Double rpAnp;

  @Column(name = "RP_PREM_AMT")
  private Double rpPremiumAmount;

  @Column(name = "RP_CASE_CNT")
  private Integer rpCaseCount;

  @Column(name = "RP_EFYC")
  private Double rpEfyc;

  @Column(name = "RP_NAC")
  private Double rpNac;

  @Column(name = "UNIT_CD")
  private String taggingUnitCode;

  @Column(name = "BRANCH_CD")
  private String taggingBranchCode;

  @Column(name = "RPT_UNIT_CD")
  private String reportingUnitCode;

  @Column(name = "RPT_BRANCH_CD")
  private String reportingBranchCode;
}
