package com.manulife.ap.core.agent.root.service;

import com.manulife.ap.core.agent.root.model.Agent;
import com.manulife.ap.core.agent.root.model.AgentFilter;
import com.manulife.ap.core.common.model.FilterCriteria;
import com.manulife.ap.core.common.model.FilterOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import static java.util.stream.Collectors.groupingBy;
import org.springframework.validation.annotation.Validated;

import java.util.*;

@Service
@RequiredArgsConstructor
@Validated
public class AgentManager implements AgentService {
  private final AgentRepository agentRepository;

  @Override
  public List<Agent> findAllByAgentCodeIn(final List<String> agentCodes) {
    if (Objects.isNull(agentCodes) || agentCodes.isEmpty()) {
      return Collections.emptyList();
    }

    return agentRepository.findAllAgentsByAgentCodeIn(agentCodes);
  }

  @Override
  public Map<String, List<Agent>> findAllByBranchCodeIn(final Set<String> branchCodes) {
    if (Objects.isNull(branchCodes) || branchCodes.isEmpty()) {
      return Collections.emptyMap();
    }

    return agentRepository.findAllAgentsByBranchCodeIn(new ArrayList<>(branchCodes))
      .parallelStream()
      .collect(groupingBy(Agent::getBranchCode));
  }

  @Override
  public Map<String, List<Agent>> findAllByUnitCodeIn(
    final Set<String> unitCodes, final List<FilterCriteria> filterCriteria) {

    if (Objects.isNull(unitCodes) || unitCodes.isEmpty()) {
      return Collections.emptyMap();
    }

    List<FilterCriteria> filterCriteriaList =
      Optional.ofNullable(filterCriteria).orElse(new ArrayList<>());

    filterCriteriaList.add(
      FilterCriteria.builder()
        .key(AgentFilter.UNIT_CODE.getName())
        .operation(FilterOperation.IN)
        .value(String.join(",", unitCodes))
        .build()
    );

    return agentRepository.findAllAgents(filterCriteriaList)
      .parallelStream()
      .collect(groupingBy(Agent::getUnitCode));
  }

  @Override
  public List<Agent> findAllByEmailAddress(final String emailAddress) {
    if (Objects.isNull(emailAddress) || emailAddress.isEmpty()) {
      return Collections.emptyList();
    }

    return agentRepository.findAllAgentsByEmailAddress(emailAddress);
  }

}
