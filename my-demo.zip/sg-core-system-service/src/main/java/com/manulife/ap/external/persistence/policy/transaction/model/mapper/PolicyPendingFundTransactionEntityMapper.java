package com.manulife.ap.external.persistence.policy.transaction.model.mapper;

import com.manulife.ap.common.mapper.LocalDateMapper;
import com.manulife.ap.common.mapper.LocalDateMapping;
import com.manulife.ap.common.mapper.StringToLocalDate;
import com.manulife.ap.core.policy.transaction.model.PolicyPendingFundTransaction;
import com.manulife.ap.external.persistence.policy.transaction.model.PolicyPendingFundTransactionEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Collection;
import java.util.List;

@Mapper(uses = LocalDateMapping.class)
public interface PolicyPendingFundTransactionEntityMapper {

  static PolicyPendingFundTransactionEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final PolicyPendingFundTransactionEntityMapper INSTANCE = Mappers.getMapper(PolicyPendingFundTransactionEntityMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "policyNumber", source = "entity.id.policyNumber")
  @Mapping(target = "fundTransactionNumber", source = "entity.id.fundTransactionNumber")
  @Mapping(target = "transactionId", source = "entity.transactionId")
  @Mapping(target = "date", source = "entity.transactionDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "valuationDate", source = "entity.valuationDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "fundTransactionCode.code", source = "entity.fundTransactionCode")
  @Mapping(target = "amount", source = "entity.amount")
  @Mapping(target = "userId", source = "entity.userId")
  @Mapping(target = "fundId", source = "entity.fundId")
  @Mapping(target = "fundVersion", source = "entity.fundVersion")
  PolicyPendingFundTransaction toPolicyPendingFundTransaction(PolicyPendingFundTransactionEntity entity);

  List<PolicyPendingFundTransaction> toPolicyPendingFundTransactionList(Collection<PolicyPendingFundTransactionEntity> PolicyPendingFundTransactionList);

}
