package com.manulife.ap.core.supporting.service;

import com.manulife.ap.core.supporting.model.ReferenceCategory;
import com.manulife.ap.core.supporting.model.ReferenceField;
import joptsimple.internal.Strings;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReferenceManager implements ReferenceService {

  private final ReferenceDatastore referenceDatastore;

  @Override
  public Optional<ReferenceField> findByCategoryAndCode(final ReferenceCategory category, final String referenceCode) {
    if (Objects.isNull(category) || Strings.isNullOrEmpty(referenceCode)) {
      return Optional.empty();
    }

    return referenceDatastore.findByCategoryAndCode(category, referenceCode);
  }

  @Override
  public Map<String, ReferenceField> findByCategoryAndCodes(final ReferenceCategory category, final Set<String> referenceCodes) {
    if (Objects.isNull(category) || Objects.isNull(referenceCodes) || referenceCodes.isEmpty()) {
      return Collections.emptyMap();
    }

    return referenceDatastore
        .findByCategoryAndCodes(category, referenceCodes).stream()
        .collect(Collectors.toMap(ReferenceField::getCode, referenceField -> referenceField));
  }
}
