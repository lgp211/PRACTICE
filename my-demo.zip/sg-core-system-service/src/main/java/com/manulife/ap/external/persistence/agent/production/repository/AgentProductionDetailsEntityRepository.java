package com.manulife.ap.external.persistence.agent.production.repository;

import com.manulife.ap.external.persistence.agent.production.model.AgentProductionDetailsEntity;
import com.manulife.ap.external.persistence.agent.production.model.AgentProductionDetailsId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AgentProductionDetailsEntityRepository
  extends JpaRepository<AgentProductionDetailsEntity, AgentProductionDetailsId> {

  List<AgentProductionDetailsEntity> findByIdAgentCodeAndIdProductionMonthInAndCurrencyCodeIn(
    String agentCode, List<String> productionMonths, List<String> currencyCodes);

  List<AgentProductionDetailsEntity> findByTaggingUnitCodeAndIdProductionMonthInAndCurrencyCodeIn(
    String unitCode, List<String> productionMonths, List<String> currencyCodes);

  List<AgentProductionDetailsEntity> findByTaggingBranchCodeAndIdProductionMonthInAndCurrencyCodeIn(
    String branchCode, List<String> productionMonths, List<String> currencyCodes);

  List<AgentProductionDetailsEntity> findByReportingUnitCodeAndIdProductionMonthInAndCurrencyCodeIn(
    String unitCode, List<String> productionMonths, List<String> currencyCodes);

  List<AgentProductionDetailsEntity> findByReportingBranchCodeAndIdProductionMonthInAndCurrencyCodeIn(
    String branchCode, List<String> productionMonths, List<String> currencyCodes);
}
