package com.manulife.ap.core.policy.coverage.model;

import lombok.*;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyCoverage {
  private String policyNumber;
  private String clientNumber;
  private String currencyCode;
  private CoverageType type;
  private ProductPlan plan;
  private LocalDate effectiveDate;
  private LocalDate terminationDate;
  private CoverageStatus status;
  private LocalDate expiryDate;
  private CoverageReason reason;
  private CoveragePremium premium;
  private CoverageUnderwriting underwriting;
  private CoverageBenefit benefit;
  private CoverageOption options;
  private CoverageLayer layers;
  private String jointClientNumber;
  private SmokerStatus smoker;
  private Integer effectiveAge;
  private CoverageCampaign campaign;
}
