package com.manulife.ap.core.policy.coverage.service;

import com.manulife.ap.core.policy.coverage.model.CoverageUnderwritingStatus;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CoverageUnderwritingStatusManager implements CoverageUnderwritingStatusService {
  private final CoverageUnderwritingStatusRepository coverageUnderwritingStatusRepository;

  @Override
  public Map<String, CoverageUnderwritingStatus> findAllByPolicyNumberIn(final Set<String> policyNumbers) {
    if (Objects.isNull(policyNumbers) || policyNumbers.isEmpty()) {
      return Collections.emptyMap();
    }

    return coverageUnderwritingStatusRepository.findAllByPolicyNumberIn(policyNumbers).stream()
      .collect(Collectors.toMap(CoverageUnderwritingStatus::getPolicyNumber, Function.identity()));
  }
}