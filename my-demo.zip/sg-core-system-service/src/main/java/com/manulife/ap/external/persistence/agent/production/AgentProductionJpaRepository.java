package com.manulife.ap.external.persistence.agent.production;

import com.manulife.ap.core.agent.production.model.AgentProductionCommission;
import com.manulife.ap.core.agent.production.model.AgentProductionDetails;
import com.manulife.ap.core.agent.production.model.filter.AgentProductionSearchCriteria;
import com.manulife.ap.core.agent.production.model.filter.BranchProductionSearchCriteria;
import com.manulife.ap.core.agent.production.model.filter.UnitProductionSearchCriteria;
import com.manulife.ap.core.agent.production.service.AgentProductionRepository;
import com.manulife.ap.external.persistence.agent.production.model.mapper.AgentProductionCommissionEntityMapper;
import com.manulife.ap.external.persistence.agent.production.model.mapper.AgentProductionDetailsEntityMapper;
import com.manulife.ap.external.persistence.agent.production.repository.AgentProductionCommissionEntityRepository;
import com.manulife.ap.external.persistence.agent.production.repository.AgentProductionDetailsEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class AgentProductionJpaRepository implements AgentProductionRepository {

  private final AgentProductionCommissionEntityRepository agentProductionCommissionEntityRepository;
  private final AgentProductionDetailsEntityRepository agentProductionDetailsEntityRepository;

  @Override
  public List<AgentProductionCommission> findAllProductionCommissionByAgentCriteria(
    final AgentProductionSearchCriteria searchCriteria) {

    return agentProductionCommissionEntityRepository
      .findByIdAgentCodeAndIdProductionMonthInAndCurrencyCodeIn(
        searchCriteria.getAgentCode(), searchCriteria.getMonths(), searchCriteria.getCurrencyCodes()
      )
      .stream()
      .map(entity -> AgentProductionCommissionEntityMapper.get().toAgentProductionCommission(entity))
      .collect(Collectors.toList());
  }

  @Override
  public List<AgentProductionDetails> findAllProductionDetailsByAgentCriteria(
    final AgentProductionSearchCriteria searchCriteria) {

    return agentProductionDetailsEntityRepository
      .findByIdAgentCodeAndIdProductionMonthInAndCurrencyCodeIn(
        searchCriteria.getAgentCode(), searchCriteria.getMonths(), searchCriteria.getCurrencyCodes()
      )
      .stream()
      .map(entity -> AgentProductionDetailsEntityMapper.get().toAgentProductionDetails(entity))
      .collect(Collectors.toList());
  }

  @Override
  public List<AgentProductionCommission> findAllProductionCommissionByTaggingUnit(
    final UnitProductionSearchCriteria searchCriteria) {

    return agentProductionCommissionEntityRepository
      .findByTaggingUnitCodeAndIdProductionMonthInAndCurrencyCodeIn(
        searchCriteria.getUnitCode(), searchCriteria.getMonths(), searchCriteria.getCurrencyCodes()
      )
      .stream()
      .map(entity -> AgentProductionCommissionEntityMapper.get().toAgentProductionCommission(entity))
      .collect(Collectors.toList());
  }

  @Override
  public List<AgentProductionDetails> findAllProductionDetailsByTaggingUnit(
    final UnitProductionSearchCriteria searchCriteria) {

    return agentProductionDetailsEntityRepository
      .findByTaggingUnitCodeAndIdProductionMonthInAndCurrencyCodeIn(
        searchCriteria.getUnitCode(), searchCriteria.getMonths(), searchCriteria.getCurrencyCodes()
      )
      .stream()
      .map(entity -> AgentProductionDetailsEntityMapper.get().toAgentProductionDetails(entity))
      .collect(Collectors.toList());
  }

  @Override
  public List<AgentProductionCommission> findAllProductionCommissionByTaggingBranch(
    final BranchProductionSearchCriteria searchCriteria) {

    return agentProductionCommissionEntityRepository
      .findByTaggingBranchCodeAndIdProductionMonthInAndCurrencyCodeIn(
        searchCriteria.getBranchCode(), searchCriteria.getMonths(), searchCriteria.getCurrencyCodes()
      )
      .stream()
      .map(entity -> AgentProductionCommissionEntityMapper.get().toAgentProductionCommission(entity))
      .collect(Collectors.toList());
  }

  @Override
  public List<AgentProductionDetails> findAllProductionDetailsByTaggingBranch(
    final BranchProductionSearchCriteria searchCriteria) {

    return agentProductionDetailsEntityRepository
      .findByTaggingBranchCodeAndIdProductionMonthInAndCurrencyCodeIn(
        searchCriteria.getBranchCode(), searchCriteria.getMonths(), searchCriteria.getCurrencyCodes()
      )
      .stream()
      .map(entity -> AgentProductionDetailsEntityMapper.get().toAgentProductionDetails(entity))
      .collect(Collectors.toList());
  }

  @Override
  public List<AgentProductionCommission> findAllProductionCommissionByReportingUnit(
    final UnitProductionSearchCriteria searchCriteria) {

    return agentProductionCommissionEntityRepository
      .findByReportingUnitCodeAndIdProductionMonthInAndCurrencyCodeIn(
        searchCriteria.getUnitCode(), searchCriteria.getMonths(), searchCriteria.getCurrencyCodes()
      )
      .stream()
      .map(entity -> AgentProductionCommissionEntityMapper.get().toAgentProductionCommission(entity))
      .collect(Collectors.toList());
  }

  @Override
  public List<AgentProductionDetails> findAllProductionDetailsByReportingUnit(
    final UnitProductionSearchCriteria searchCriteria) {

    return agentProductionDetailsEntityRepository
      .findByReportingUnitCodeAndIdProductionMonthInAndCurrencyCodeIn(
        searchCriteria.getUnitCode(), searchCriteria.getMonths(), searchCriteria.getCurrencyCodes()
      )
      .stream()
      .map(entity -> AgentProductionDetailsEntityMapper.get().toAgentProductionDetails(entity))
      .collect(Collectors.toList());
  }

  @Override
  public List<AgentProductionCommission> findAllProductionCommissionByReportingBranch(
    final BranchProductionSearchCriteria searchCriteria) {

    return agentProductionCommissionEntityRepository
      .findByReportingBranchCodeAndIdProductionMonthInAndCurrencyCodeIn(
        searchCriteria.getBranchCode(), searchCriteria.getMonths(), searchCriteria.getCurrencyCodes()
      )
      .stream()
      .map(entity -> AgentProductionCommissionEntityMapper.get().toAgentProductionCommission(entity))
      .collect(Collectors.toList());
  }

  @Override
  public List<AgentProductionDetails> findAllProductionDetailsByReportingBranch(
    final BranchProductionSearchCriteria searchCriteria) {

    return agentProductionDetailsEntityRepository
      .findByReportingBranchCodeAndIdProductionMonthInAndCurrencyCodeIn(
        searchCriteria.getBranchCode(), searchCriteria.getMonths(), searchCriteria.getCurrencyCodes()
      )
      .stream()
      .map(entity -> AgentProductionDetailsEntityMapper.get().toAgentProductionDetails(entity))
      .collect(Collectors.toList());
  }
}
