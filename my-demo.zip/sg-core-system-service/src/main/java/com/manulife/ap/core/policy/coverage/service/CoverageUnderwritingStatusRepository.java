package com.manulife.ap.core.policy.coverage.service;

import com.manulife.ap.core.policy.coverage.model.CoverageUnderwritingStatus;

import java.util.List;
import java.util.Set;

public interface CoverageUnderwritingStatusRepository {
  List<CoverageUnderwritingStatus> findAllByPolicyNumberIn(Set<String> policyNumbers);
}