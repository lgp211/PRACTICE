package com.manulife.ap.external.persistence.agent.root.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "TAMS_AGENTS")
@SecondaryTable(name = "TAMS_AGENTS_SG", pkJoinColumns = @PrimaryKeyJoinColumn(name = "AGENT_CODE"))
public class AgentEntity {

  @Id
  @Column(name = "AGT_CODE")
  private String agentCode;

  @Column(name = "CAN_NUM")
  private String candidateNumber;

  @Column(name = "AGT_NM")
  private String name;

  @Column(name = "STAT_CD")
  private String status;

  @Column(name = "EMAIL_ADD")
  private String emailAddress;

  @Column(name = "RANK_CD")
  private String rankCode;

  @Column(name = "RANK_EFF_DT")
  private String rankEffectiveDate;

  @Column(name = "LIC_NUM")
  private String licenseNumber;

  @Column(name = "CNTRCT_EFF_DT")
  private String contractEffectiveDate;

  @Column(name = "CNTRCT_SIGN_DT")
  private String contractSignDate;

  @Column(name = "TRMN_DT")
  private String terminationDate;

  @Column(name = "SUSPEND_IND", table = "TAMS_AGENTS_SG")
  private String suspendIndicator;

  @Column(name = "ORIG_AGT_CDE")
  private String originalAgentCode;

  @Column(name = "BR_CODE")
  private String branchCode;

  @Column(name = "UNIT_CODE")
  private String unitCode;

  @Column(name = "RPT_TO_GRP")
  private String reportingUnitCode;
}
