package com.manulife.ap.core.policy.coverage.service;

import com.manulife.ap.core.policy.coverage.model.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class CoverageLayerManager implements CoverageLayerService {
  private final CoverageLayerRepository coverageLayerRepository;

  @Override
  public Map<CoverageLayerKey, List<CoverageLayer>> findAllByCoverageLayerKeyIn(final Set<CoverageLayerKey> coverageLayerKeys) {
    if (Objects.isNull(coverageLayerKeys) || coverageLayerKeys.isEmpty()) {
      return Collections.emptyMap();
    }

    return coverageLayerRepository.findAllByCoverageLayerKeyIn(coverageLayerKeys).stream()
      .collect(groupingBy(coverageLayer ->
        CoverageLayerKey.builder()
          .policyNumber(coverageLayer.getPolicyNumber())
          .clientNumber(coverageLayer.getClientNumber())
          .planCode(coverageLayer.getPlanCode())
          .planVersion(coverageLayer.getPlanVersion())
          .coverageEffectiveDate(coverageLayer.getCoverageEffectiveDate())
          .build()
      ));
  }
}