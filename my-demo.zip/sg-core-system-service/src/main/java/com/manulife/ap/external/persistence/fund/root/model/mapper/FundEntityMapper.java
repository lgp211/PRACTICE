package com.manulife.ap.external.persistence.fund.root.model.mapper;

import com.manulife.ap.core.fund.root.model.Fund;
import com.manulife.ap.external.persistence.fund.root.model.FundEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Collection;
import java.util.List;

@Mapper
public interface FundEntityMapper {
  static FundEntityMapper get() {
    return FundEntityMapper.ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final FundEntityMapper INSTANCE = Mappers.getMapper(FundEntityMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "fundId", source = "entity.id.fundId")
  @Mapping(target = "fundVersion", source = "entity.id.fundVersion")
  @Mapping(target = "description", source = "entity.description")
  @Mapping(target = "effectiveStartDate", source = "entity.effectiveFromDate")
  @Mapping(target = "effectiveEndDate", source = "entity.effectiveToDate")
  @Mapping(target = "currency.code", source = "entity.currency")
  @Mapping(target = "type", source = "entity.fundType")
  Fund toDoaminObject(FundEntity entity);

  List<Fund> toDomainObjectList(Collection<FundEntity> fundEntityList);
}