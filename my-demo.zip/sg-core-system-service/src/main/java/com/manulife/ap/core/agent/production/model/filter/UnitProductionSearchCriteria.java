package com.manulife.ap.core.agent.production.model.filter;

import lombok.Builder;
import lombok.Getter;

import javax.validation.constraints.NotBlank;
import java.util.List;

@Getter
public class UnitProductionSearchCriteria extends DefaultProductionSearchCriteria {

  @NotBlank(message = "Unit code is mandatory")
  private final String unitCode;

  @Builder
  public UnitProductionSearchCriteria(String unitCode, String firstMonth, String lastMonth, List<String> currencyCodes) {
    super(firstMonth, lastMonth, currencyCodes);
    this.unitCode = unitCode;
  }
}
