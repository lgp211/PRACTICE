package com.manulife.ap.external.persistence.customer.root.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "TCLIENT_DETAILS")
public class CustomerEntity {

  @Id
  @Column(name = "CLI_NUM")
  private String clientNumber;

  @Column(name = "CLI_NM")
  private String name;

  @Column(name = "ID_NUM")
  private String identityNumber;

  @Column(name = "ID_TYP")
  private String identityType;

  @Column(name = "SEX_CODE")
  private String sexCode;

  @Column(name = "BIRTH_DT")
  private String birthDate;

  @Column(name = "ADDR_TYP")
  private String permanentAddressType;

  @Column(name = "PERM_ADDR_1")
  private String permanentAddressLine1;

  @Column(name = "PERM_ADDR_2")
  private String permanentAddressLine2;

  @Column(name = "PERM_ADDR_3")
  private String permanentAddressLine3;

  @Column(name = "PERM_ADDR_4")
  private String permanentAddressLine4;

  @Column(name = "PERM_ZIP_CODE")
  private String permanentAddressPostalCode;

  @Column(name = "PRIM_PHON_NUM")
  private String primaryPhoneNumber;

  @Column(name = "PRIM_PHON_COUNTRY_CD")
  private String primaryPhoneCountryCode;

  @Column(name = "HP_NUM")
  private String mobilePhoneNumber;

  @Column(name = "HP_COUNTRY_CD")
  private String mobilePhoneCountryCode;

  @Column(name = "OTHR_PHON_NUM")
  private String otherPhoneNumber;

  @Column(name = "OTHR_PHON_COUNTRY_CD")
  private String otherPhoneCountryCode;

  @Column(name = "FAX_NUM")
  private String faxPhoneNumber;

  @Column(name = "FAX_COUNTRY_CD")
  private String faxPhoneCountryCode;

}
