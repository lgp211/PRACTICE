package com.manulife.ap.external.persistence.customer.address.model.mapper;

import com.manulife.ap.core.customer.address.model.CustomerAddress;
import com.manulife.ap.external.persistence.customer.address.model.CustomerAddressEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface CustomerAddressEntityMapper {
  static CustomerAddressEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final CustomerAddressEntityMapper INSTANCE = Mappers.getMapper(CustomerAddressEntityMapper.class);
    private ModelMapperInstance() {}
  }

  @Mapping(target = "clientNumber", source = "entity.id.clientNumber")
  @Mapping(target = "type", source = "entity.id.type")
  @Mapping(target = "line1", source = "entity.line1")
  @Mapping(target = "line2", source = "entity.line2")
  @Mapping(target = "line3", source = "entity.line3")
  @Mapping(target = "line4", source = "entity.line4")
  @Mapping(target = "postalCode", source = "entity.postalCode")
  CustomerAddress toCustomerAddress(CustomerAddressEntity entity);
}
