package com.manulife.ap.core.product.root.service;

import com.manulife.ap.core.product.root.model.Product;
import com.manulife.ap.core.product.root.model.ProductKey;

import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Set;

public interface ProductRepository {

  List<Product> findAllByProductKey(
    @NotNull(message = "Product key set cannot be null") Set<ProductKey> productKeys);
}
