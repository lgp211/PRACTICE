package com.manulife.ap.core.policy.coverage.service;

import com.manulife.ap.core.policy.coverage.model.PolicyCoverage;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class PolicyCoverageManager implements PolicyCoverageService {
  private final PolicyCoverageRepository policyCoverageRepository;

  public Map<String, List<PolicyCoverage>> findCoveragesByPolicyNumbers(final Set<String> policyNumbers) {
    return Optional.ofNullable(policyNumbers)
      .map(policyNumberSet ->
        policyCoverageRepository.findCoveragesByPolicyNumbers(policyNumberSet).stream()
          .collect(groupingBy(PolicyCoverage::getPolicyNumber))
      )
      .orElse(Collections.emptyMap());
  }
}
