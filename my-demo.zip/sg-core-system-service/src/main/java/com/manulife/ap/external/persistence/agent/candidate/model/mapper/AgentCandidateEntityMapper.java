package com.manulife.ap.external.persistence.agent.candidate.model.mapper;

import com.manulife.ap.common.mapper.*;
import com.manulife.ap.core.agent.candidate.model.AgentCandidate;
import com.manulife.ap.external.persistence.agent.candidate.model.AgentCandidateEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = LocalDateMapping.class)
public interface AgentCandidateEntityMapper {
  static AgentCandidateEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final AgentCandidateEntityMapper INSTANCE = Mappers.getMapper(AgentCandidateEntityMapper.class);
    private ModelMapperInstance() {}
  }

  @Mapping(target = "number", source = "entity.candidateNumber")
  @Mapping(target = "name", source = "entity.name")
  @Mapping(target = "dob", source = "entity.dob", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  AgentCandidate toAgentCandidate(AgentCandidateEntity entity);
}
