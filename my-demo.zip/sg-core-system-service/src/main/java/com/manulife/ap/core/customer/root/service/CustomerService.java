package com.manulife.ap.core.customer.root.service;

import com.manulife.ap.core.common.model.FilterCriteria;
import com.manulife.ap.core.customer.root.model.Customer;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

public interface CustomerService {
  List<Customer> findAllByClientNumberIn(List<String> clientNumbers);

  List<Customer> findAllByCriteria(
    @Valid
    @NotNull(message = "Search criteria cannot be null")
    @NotEmpty(message = "Search criteria cannot be empty")
      List<FilterCriteria> filterCriteriaList);
}
