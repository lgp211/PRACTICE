package com.manulife.ap.external.persistence.customer.policy.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomerPolicyId implements Serializable {
  @Column(name = "CLI_NUM")
  private String clientNumber;
  @Column(name = "POL_NUM")
  private String policyNumber;
  @Column(name = "LINK_TYP")
  private String linkType;
}
