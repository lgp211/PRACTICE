package com.manulife.ap.external.persistence.policy.coverage.model.mapper;

import com.manulife.ap.core.policy.coverage.model.ProductClaim;
import com.manulife.ap.external.persistence.policy.coverage.model.ProductClaimEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ProductClaimEntityMapper {

  static ProductClaimEntityMapper getInstance() {
    return ModelMapperInstance.INSTANCE;
  }

  @Mapping(target = "planCode", source = "productClaim.id.planCode")
  @Mapping(target = "planVersion", source = "productClaim.id.planVersion")
  @Mapping(target = "type.code", source = "productClaim.id.claimType")
  @Mapping(target = "version", source = "productClaim.id.claimVersion")
  ProductClaim toProductClaim(ProductClaimEntity productClaim);

  final class ModelMapperInstance {
    private static final ProductClaimEntityMapper INSTANCE = Mappers.getMapper(ProductClaimEntityMapper.class);

    private ModelMapperInstance() {
    }
  }
}
