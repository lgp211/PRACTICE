package com.manulife.ap.core.policy.root.service;

import com.manulife.ap.core.common.model.FilterCriteria;
import com.manulife.ap.core.policy.root.model.Policy;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import java.util.*;

@Service
@RequiredArgsConstructor
@Validated
public class PolicyManager implements PolicyService {
  private final PolicyRepository policyRepository;

  @Override
  public List<Policy> findByPolicyNumbers(final List<String> policyNumbers) {
    return Optional.ofNullable(policyNumbers)
      .map(policyRepository::findByPolicyNumbers)
      .orElse(Collections.emptyList());
  }

  @Override
  public List<Policy> findAllByCriteria(final List<FilterCriteria> filterCriteriaList) {
    return Optional.ofNullable(filterCriteriaList)
      .map(policyRepository::findAllByCriteria)
      .orElse(Collections.emptyList());
  }
}
