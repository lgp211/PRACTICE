package com.manulife.ap.core.fund.root.service;

import com.manulife.ap.core.fund.root.model.Fund;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class FundManager implements FundService{
  private final FundRepository fundRepository;

  @Override
  public List<Fund> findAllByFundIdIn(final Set<String> fundIds) {
    return Optional.ofNullable(fundIds)
      .map(fundRepository::findAllByFundIdIn)
      .orElse(Collections.emptyList());
  }
}