package com.manulife.ap.core.policy.financial.service;

import com.manulife.ap.core.policy.financial.model.PolicyFinancial;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PolicyFinancialManager implements PolicyFinancialService {

  private final PolicyFinancialRepository policyFinancialRepository;

  @Override
  public Map<String, PolicyFinancial> findByPolicyNumbers(final Set<String> policyNumbers) {
    return Optional.ofNullable(policyNumbers)
      .map(policyNumberList ->
        policyNumberList.parallelStream()
          .map(policyFinancialRepository::findByPolicyNumber)
          .collect(Collectors.toList())
          .stream()
          .filter(Optional::isPresent)
          .map(Optional::get)
          .collect(Collectors.toMap(PolicyFinancial::getPolicyNumber, Function.identity()))
      )
      .orElse(Collections.emptyMap());
  }
}
