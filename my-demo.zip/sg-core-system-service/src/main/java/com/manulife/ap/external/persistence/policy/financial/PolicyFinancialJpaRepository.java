package com.manulife.ap.external.persistence.policy.financial;

import com.manulife.ap.core.policy.financial.model.PolicyFinancial;
import com.manulife.ap.core.policy.financial.service.PolicyFinancialRepository;
import com.manulife.ap.external.persistence.policy.financial.model.PolicyFinancialEntity;
import com.manulife.ap.external.persistence.policy.financial.model.mapper.PolicyFinancialEntityMapper;
import com.manulife.ap.external.persistence.policy.financial.repository.PolicyFinancialEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;

@Component
@RequiredArgsConstructor
public class PolicyFinancialJpaRepository implements PolicyFinancialRepository {

  private final PolicyFinancialEntityRepository policyFinancialEntityRepository;

  @Override
  public Optional<PolicyFinancial> findByPolicyNumber(final String policyNumber) {
    if(Objects.isNull(policyNumber) || policyNumber.isEmpty()) {
      return Optional.empty();
    }

    Map<String, Object> map = policyFinancialEntityRepository.nfoCalcWrapper(policyNumber);

    return Optional.ofNullable(PolicyFinancialEntityMapper.get().toPolicyFinancial(
      PolicyFinancialEntity.builder()
        .policyNumber(map.get("policyNumber").toString())
        .basicCashValue((Double) map.get("basicCashValue"))
        .nonGuaranteedTerminalBonus((Double) map.get("nonGuaranteedTerminalBonus"))
        .surrenderValue((Double) map.get("surrenderValue"))
        .couponBalance((Double) map.get("couponBalance"))
        .csaBalance((Double) map.get("csaBalance"))
        .outstandingLoan((Double) map.get("outstandingLoan"))
        .outstandingInterestFreeLoan((Double) map.get("outstandingInterestFreeLoan"))
        .totalAvailableLoan((Double) map.get("totalAvailableLoan"))
        .totalAvailableInterestFreeLoan((Double) map.get("totalAvailableInterestFreeLoan"))
        .build()
    ));
  }
}
