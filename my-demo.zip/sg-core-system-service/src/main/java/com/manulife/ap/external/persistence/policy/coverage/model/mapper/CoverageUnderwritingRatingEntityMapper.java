package com.manulife.ap.external.persistence.policy.coverage.model.mapper;

import com.manulife.ap.core.policy.coverage.model.CoverageUnderwritingRating;
import com.manulife.ap.external.persistence.policy.coverage.model.CoverageUnderwritingRatingEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface CoverageUnderwritingRatingEntityMapper {
  static CoverageUnderwritingRatingEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final CoverageUnderwritingRatingEntityMapper INSTANCE = Mappers.getMapper(CoverageUnderwritingRatingEntityMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "policyNumber", source = "entity.id.policyNumber")
  @Mapping(target = "planCode", source = "entity.id.planCode")
  @Mapping(target = "planVersion", source = "entity.id.planVersion")
  @Mapping(target = "code", source = "entity.rating")
  CoverageUnderwritingRating toCoverageUnderwritingRating(CoverageUnderwritingRatingEntity entity);
}