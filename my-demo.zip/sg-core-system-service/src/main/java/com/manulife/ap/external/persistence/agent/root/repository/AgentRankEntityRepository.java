package com.manulife.ap.external.persistence.agent.root.repository;

import com.manulife.ap.external.persistence.agent.root.model.AgentRankEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AgentRankEntityRepository extends JpaRepository<AgentRankEntity, String> {
}
