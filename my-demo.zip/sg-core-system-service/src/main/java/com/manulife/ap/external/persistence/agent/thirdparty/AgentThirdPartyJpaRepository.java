package com.manulife.ap.external.persistence.agent.thirdparty;

import com.manulife.ap.core.agent.thirdparty.model.AgentThirdParty;
import com.manulife.ap.core.agent.thirdparty.service.AgentThirdPartyRepository;
import com.manulife.ap.external.persistence.agent.thirdparty.model.mapper.AgentThirdPartyEntityMapper;
import com.manulife.ap.external.persistence.agent.thirdparty.repository.AgentThirdPartyEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class AgentThirdPartyJpaRepository implements AgentThirdPartyRepository {
  private final AgentThirdPartyEntityRepository agentThirdPartyEntityRepository;

  @Override
  public List<AgentThirdParty> findAllByIdIn(final List<String> thirdPartyIds) {
    if (Objects.isNull(thirdPartyIds) || thirdPartyIds.isEmpty()) {
      return Collections.emptyList();
    }

    return agentThirdPartyEntityRepository.findAllByIdThirdPartyIdIn(thirdPartyIds)
      .parallelStream()
      .map(thirdPartyEntity -> AgentThirdPartyEntityMapper.get().toAgentThirdParty(thirdPartyEntity))
      .collect(Collectors.toList());
  }

  @Override
  public List<AgentThirdParty> findAllByAgentCodeIn(final List<String> agentCodes) {
    if (Objects.isNull(agentCodes) || agentCodes.isEmpty()) {
      return Collections.emptyList();
    }

    return agentThirdPartyEntityRepository.findAllByIdAgentCodeIn(agentCodes)
      .parallelStream()
      .map(thirdPartyEntity -> AgentThirdPartyEntityMapper.get().toAgentThirdParty(thirdPartyEntity))
      .collect(Collectors.toList());
  }
}
