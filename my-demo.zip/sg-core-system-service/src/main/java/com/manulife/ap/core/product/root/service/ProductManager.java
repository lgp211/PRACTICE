package com.manulife.ap.core.product.root.service;

import com.manulife.ap.core.product.root.model.Product;
import com.manulife.ap.core.product.root.model.ProductSearchCriteria;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Validated
public class ProductManager implements ProductService {
  private final ProductRepository productRepository;

  @Override
  public List<Product> findAllByProductCriteria(final Set<ProductSearchCriteria> searchCriteria) {
    List<Product> productList =
      productRepository.findAllByProductKey(
        searchCriteria.stream().map(ProductSearchCriteria::toProductKey).collect(Collectors.toSet())
      );

    productList.forEach(product ->
      searchCriteria.stream()
        .filter(criteria -> criteria.isProductMatch(product))
        .findFirst()
        .ifPresent(criteria ->
          product.evaluateProductMarketingName(criteria.getPremiumDuration(), criteria.getBenefitDuration())
        )
    );

    return productList;
  }
}
