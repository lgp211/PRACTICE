package com.manulife.ap.core.policy.root.model;

import com.manulife.ap.core.policy.root.model.field.PolicyAgentType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyAgent {
  private String code;
  private PolicyAgentType type;

  public boolean isPrimaryServicingAgent() {
    return PolicyAgentType.PRIMARY_SERVICING_AGENT.equals(type);
  }

  public boolean isSecondaryServicingAgent() {
    return PolicyAgentType.SECONDARY_SERVICING_AGENT.equals(type);
  }

  public boolean isPrimaryWritingAgent() {
    return PolicyAgentType.PRIMARY_WRITING_AGENT.equals(type);
  }

  public boolean isSecondaryWritingAgent() {
    return PolicyAgentType.SECONDARY_WRITING_AGENT.equals(type);
  }
}
