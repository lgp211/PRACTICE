package com.manulife.ap.core.customer.policy.service;

import com.manulife.ap.core.customer.policy.model.CustomerPolicy;

import java.util.List;
import java.util.Map;

public interface CustomerPolicyService {
  Map<String, List<CustomerPolicy>> findAllByClientNumberIn(List<String> clientNumbers);
}
