package com.manulife.ap.external.persistence.policy.financial.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "POLICY_FINANCIAL")
@NamedStoredProcedureQuery(name = "nfoCalcWrapper",
  procedureName = "CORE_SERVICE.NFO_CALC_WRAPPER",
  parameters = {
    @StoredProcedureParameter(mode = ParameterMode.INOUT, name = "policyNumber", type = String.class),
    @StoredProcedureParameter(mode = ParameterMode.OUT, name = "basicCashValue", type = Double.class),
    @StoredProcedureParameter(mode = ParameterMode.OUT, name = "nonGuaranteedTerminalBonus", type = Double.class),
    @StoredProcedureParameter(mode = ParameterMode.OUT, name = "surrenderValue", type = Double.class),
    @StoredProcedureParameter(mode = ParameterMode.OUT, name = "couponBalance", type = Double.class),
    @StoredProcedureParameter(mode = ParameterMode.OUT, name = "csaBalance", type = Double.class),
    @StoredProcedureParameter(mode = ParameterMode.OUT, name = "outstandingLoan", type = Double.class),
    @StoredProcedureParameter(mode = ParameterMode.OUT, name = "outstandingInterestFreeLoan", type = Double.class),
    @StoredProcedureParameter(mode = ParameterMode.OUT, name = "totalAvailableLoan", type = Double.class),
    @StoredProcedureParameter(mode = ParameterMode.OUT, name = "totalAvailableInterestFreeLoan", type = Double.class)
  })
public class PolicyFinancialEntity implements Serializable {

  @Id
  @Column
  private String policyNumber;

  @Column
  private Double basicCashValue;

  @Column
  private Double nonGuaranteedTerminalBonus;

  @Column
  private Double surrenderValue;

  @Column
  private Double couponBalance;

  @Column
  private Double csaBalance;

  @Column
  private Double outstandingLoan;

  @Column
  private Double outstandingInterestFreeLoan;

  @Column
  private Double totalAvailableLoan;

  @Column
  private Double totalAvailableInterestFreeLoan;
}
