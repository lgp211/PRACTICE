package com.manulife.ap.core.policy.underwriting.service;

import com.manulife.ap.core.policy.underwriting.model.PolicyUnderwriting;

import java.util.Map;
import java.util.Set;

public interface PolicyUnderwritingService {
  Map<String, PolicyUnderwriting> findAllByPolicyNumbers(Set<String> policyNumbers);
}
