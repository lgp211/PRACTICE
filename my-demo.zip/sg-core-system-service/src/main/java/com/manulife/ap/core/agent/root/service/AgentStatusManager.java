package com.manulife.ap.core.agent.root.service;

import com.manulife.ap.core.agent.root.model.AgentStatus;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class AgentStatusManager implements AgentStatusService {
  private final AgentRepository agentRepository;

  @Override
  public List<AgentStatus> findAllByStatusCodeIn(List<String> statusCodes) {
    if (Objects.isNull(statusCodes) || statusCodes.isEmpty()) {
      return Collections.emptyList();
    }

    return agentRepository.findAllStatusesByStatusCodeIn(statusCodes);
  }
}
