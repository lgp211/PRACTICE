package com.manulife.ap.core.agent.root.service;

import com.manulife.ap.core.agent.root.model.AgentStatus;

import java.util.List;

public interface AgentStatusService {
  List<AgentStatus> findAllByStatusCodeIn(List<String> statusCodes);
}
