package com.manulife.ap.external.persistence.policy.coverage.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "TCOVERAGE_LAYERS")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CoverageLayerEntity {
  @EmbeddedId
  private CoverageLayerId id;

  @Column(name = "STAT_CD")
  private String statusCode;

  @Column(name = "SMKR_CODE")
  private String smokerCode;
}