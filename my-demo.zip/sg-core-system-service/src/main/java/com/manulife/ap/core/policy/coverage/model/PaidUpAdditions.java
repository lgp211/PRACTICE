package com.manulife.ap.core.policy.coverage.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PaidUpAdditions {
  private double totalAmount;
  private double currentAmount;
}
