package com.manulife.ap.core.customer.address.service;

import com.manulife.ap.core.customer.address.model.CustomerAddress;

import java.util.Map;
import java.util.List;

public interface CustomerAddressService {
  Map<String, List<CustomerAddress>> findAllByClientNumberIn(List<String> clientNumbers);
}
