package com.manulife.ap.external.persistence.fund.root.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TFUNDS")
public class FundEntity {

  @EmbeddedId
  private FundId id;

  @Column(name = "FND_DESC")
  private String description;

  @Column(name = "EFF_FR_DT")
  private LocalDate effectiveFromDate;

  @Column(name = "EFF_TO_DT")
  private LocalDate effectiveToDate;

  @Column(name = "CRCY_CD")
  private String currency;

  @Column(name = "FND_TYP")
  private String fundType;
}