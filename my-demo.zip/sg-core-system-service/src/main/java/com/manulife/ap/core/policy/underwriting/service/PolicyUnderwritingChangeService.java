package com.manulife.ap.core.policy.underwriting.service;

import com.manulife.ap.core.policy.underwriting.model.PolicyUnderwritingChange;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface PolicyUnderwritingChangeService {
  Map<String, List<PolicyUnderwritingChange>> findAllByPolicyNumbers(Set<String> policyNumbers);
}
