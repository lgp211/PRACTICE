package com.manulife.ap.core.supporting.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Optional;
import java.util.stream.Stream;

@Getter
@AllArgsConstructor
public enum ReferenceCategory {
  POLICY_STATUS("policyStatus", "STAT_CODE"),
  POLICY_SUBMISSION_TYPE("policySubmissionType", "SUBMISSION_TYPE"),
  COVERAGE_TYPE("coverageType", "CVG_TYP"),
  PRODUCT_CLAIM_TYPE("productClaimType", "CLM_TYP"),
  CLIENT_POLICY_LINK_TYPE("clientPolicyLinkType", "LINK_TYP"),
  POLICY_LAYER_TYPE("policyLayerType", "LAY_TYP"),
  COVERAGE_REASON("coverageReason", "CVG_REASN"),
  UNDERWRITING_RATING("underwritingRating", "UW_RATING"),
  SMOKER_CODE("smokerCode", "SMKR_CODE"),
  PRODUCT_CATEGORY("productCategory", "PROD_CAT"),
  POLICY_DIVIDEND_OPTION("policyDividendOption", "DIV_OPT"),
  POLICY_NFO_OPTION("policyNfoOption", "NFO_OPT"),
  POLICY_ANNUITY_OPTION("policyAnnuityOption", "ANTY_OPT"),
  CURRENCY_CODE("currencyCode", "CRCY_CODE"),
  PAYMENT_MODE("paymentMode", "PMT_MODE"),
  POLICY_IPO_INDICATOR("policyIpoIndicator", "IPO_IND"),
  AGENT_ROLE("agentRole", "AGT_ROLE"),
  AGENT_STATUS("agentStatus", "AGT_STAT_CODE"),
  AGENT_UNIT_TYPE("agentUnitType", "UNIT_TYPE"),
  AGENCY_ZONE("agencyZone", "ZONE_CD"),
  CUSTOMER_IDENTITY_TYPE("customerIdentityType", "ID_TYP"),
  GENDER("gender", "SEX_CODE"),
  POLICY_DEATH_BENEFIT_OPTION("policyDeathBenefitOption", "DB_OPT"),
  POLICY_BILLING_METHOD("policyBillingMethod", "BILL_MTHD"),
  UNDERWRITING_STATUS("underwritingStatus", "UW_DISP_ST"),
  BENEFICIARY_TYPE("beneficiaryType", "BNFY_TYP"),
  BENEFICIARY_CODE("beneficiaryCode", "BNFY_CODE"),
  BENEFICIARY_PARTY("beneficiaryParty", "BNFY_PRTY"),
  PREMIUM_HOLIDAY_INDICATOR("premiumHolidayIndicator", "PH_IND"),
  PFP_CHOICE_INDICATOR("pfpChoiceIndicator", "PFP_CHOICE"),
  PFP_HEALTH_INDICATOR("pfpHealthIndicator", "PFP_HEALTH"),
  POLICY_GIRO_STATUS("policyGiroStatus", "PAC_BK_CTR"),
  POINT_OF_SALES_STATUS_CODE("pointOfSalesStatusCode", "POS_STAT_CODE"),
  TRANSACTION_CODE("transactionCode", "TRXN_CD"),
  PAYOUT_METHOD("payoutMethod", "PAYO_MTHD"),
  TRANSACTION_TYPE("transactionType", "TRXN_TYP"),
  FUND_TRANSACTION_CODE("fundTransactionCode", "FND_TRXN_CD"),
  RECORD_STATUS("recordStatus", "REC_STATUS"),
  TEAM_IDENTIFICATION("teamIdentification", "TEAM_ID"),
  ALLOCATION_TYPE("allocationType", "ALLOC_TYP");

  private final String name;
  private final String code;

  public static Optional<ReferenceCategory> findByCode(final String anotherCode) {
    return Stream.of(values())
        .filter(category -> String.valueOf(anotherCode).equalsIgnoreCase(category.code))
        .findFirst();
  }
}
