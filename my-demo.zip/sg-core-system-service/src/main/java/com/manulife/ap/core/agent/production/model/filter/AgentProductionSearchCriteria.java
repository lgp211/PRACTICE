package com.manulife.ap.core.agent.production.model.filter;

import lombok.Builder;
import lombok.Getter;

import javax.validation.constraints.NotBlank;
import java.util.List;

@Getter
public class AgentProductionSearchCriteria extends DefaultProductionSearchCriteria {

  @NotBlank(message = "Agent code is mandatory")
  private final String agentCode;

  @Builder
  public AgentProductionSearchCriteria(String agentCode, String firstMonth, String lastMonth, List<String> currencyCodes) {
    super(firstMonth, lastMonth, currencyCodes);
    this.agentCode = agentCode;
  }
}
