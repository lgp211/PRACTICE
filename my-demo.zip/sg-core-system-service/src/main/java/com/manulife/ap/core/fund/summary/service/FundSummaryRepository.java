package com.manulife.ap.core.fund.summary.service;

import com.manulife.ap.core.fund.summary.model.FundSummary;
import com.manulife.ap.core.fund.summary.model.FundSummaryKey;

import java.util.List;
import java.util.Set;

public interface FundSummaryRepository {
  List<FundSummary> findAllByFundSummaryKeyIn(Set<FundSummaryKey> fundSummaryKeys);
}