package com.manulife.ap.external.persistence.fund.root;

import com.manulife.ap.core.fund.root.model.Fund;
import com.manulife.ap.core.fund.root.service.FundRepository;
import com.manulife.ap.external.persistence.fund.root.model.mapper.FundEntityMapper;
import com.manulife.ap.external.persistence.fund.root.repository.FundEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class FundJpaRepository implements FundRepository {
  private final FundEntityRepository fundEntityRepository;

  @Override
  public List<Fund> findAllByFundIdIn(final Set<String> fundIds) {
    return Optional.ofNullable(fundIds)
      .map(id -> fundEntityRepository.findAllByIdFundIdIn(id)
        .stream()
        .map(entity -> FundEntityMapper.get().toDoaminObject(entity))
        .collect(Collectors.toList())
      )
      .orElse(Collections.emptyList());
  }
}