package com.manulife.ap.core.policy.fund.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyFundAllocation {
  private String policyNumber;
  private String fundId;
  private String fundVersion;
  private LocalDate effectiveDate;
  private String status;
  private AllocationType type;
  private String premiumGroup;
  private Double percentage;
}
