package com.manulife.ap.core.customer.root.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.manulife.ap.core.customer.address.model.CustomerAddress;
import com.manulife.ap.core.customer.policy.model.CustomerPolicy;


import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.time.Period;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Customer {
  private String clientNumber;
  private CustomerName name;
  private CustomerIdentity identity;
  private CustomerGender gender;
  private LocalDate dob;
  private Integer age;
  private List<CustomerPhone> phones;
  private List<CustomerAddress> addresses;
  private List<CustomerPolicy> policies;

  /**
   * Calculate the age of customer based on given date of birth and current date.
   * @param today Today date
   * @return age in Integer before next birthdate
   */
  public Integer getAgeAsOf(final LocalDate today){
    if (Objects.isNull(dob) || Objects.isNull(today)) {
      return -1;
    }

    int ageInYear = Period.between(dob, today).getYears();
    return ageInYear < 0 ? -1 : ageInYear;
  }
}
