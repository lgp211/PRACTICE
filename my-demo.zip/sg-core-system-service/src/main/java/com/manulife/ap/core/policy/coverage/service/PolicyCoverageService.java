package com.manulife.ap.core.policy.coverage.service;

import com.manulife.ap.core.policy.coverage.model.PolicyCoverage;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface PolicyCoverageService {
  Map<String, List<PolicyCoverage>> findCoveragesByPolicyNumbers(Set<String> policyNumber);
}
