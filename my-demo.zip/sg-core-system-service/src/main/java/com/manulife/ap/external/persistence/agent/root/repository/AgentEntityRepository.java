package com.manulife.ap.external.persistence.agent.root.repository;

import com.manulife.ap.external.persistence.agent.root.model.AgentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AgentEntityRepository
  extends JpaRepository<AgentEntity, String>, JpaSpecificationExecutor<AgentEntity> {

  List<AgentEntity> findAllByBranchCodeIn(List<String> branchCodes);

  List<AgentEntity> findAllByEmailAddress(String emailAddress);
}
