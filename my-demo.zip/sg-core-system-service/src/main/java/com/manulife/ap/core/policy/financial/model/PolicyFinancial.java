package com.manulife.ap.core.policy.financial.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyFinancial {
  private String policyNumber;
  private Double basicCashValue;
  private Double nonGuaranteedTerminalBonus;
  private Double surrenderValue;
  private Double couponBalance;
  private Double csaBalance;
  private Double netSurrenderValue;
  private Double outstandingLoan;
  private Double outstandingInterestFreeLoan;
  private Double totalAvailableLoan;
  private Double totalAvailableInterestFreeLoan;
}
