package com.manulife.ap.core.customer.policy.service;

import com.manulife.ap.core.customer.policy.model.CustomerPolicy;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class CustomerPolicyManager implements CustomerPolicyService {
  private final CustomerPolicyRepository repository;

  @Override
  public Map<String, List<CustomerPolicy>> findAllByClientNumberIn(final List<String> clientNumbers) {
    if (Objects.isNull(clientNumbers) || clientNumbers.isEmpty()) {
      return Collections.emptyMap();
    }

    return repository.findAllByClientNumberIn(clientNumbers).stream()
      .collect(groupingBy(CustomerPolicy::getClientNumber));
  }
}
