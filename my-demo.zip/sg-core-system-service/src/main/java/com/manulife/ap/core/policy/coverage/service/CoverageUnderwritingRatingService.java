package com.manulife.ap.core.policy.coverage.service;

import com.manulife.ap.core.policy.coverage.model.CoverageUnderwritingKey;
import com.manulife.ap.core.policy.coverage.model.CoverageUnderwritingRating;

import java.util.Map;
import java.util.Set;

public interface CoverageUnderwritingRatingService {
  Map<CoverageUnderwritingKey, CoverageUnderwritingRating> findRatingByUnderwritingKeys(Set<CoverageUnderwritingKey> coverageUnderwritingKeys);
}