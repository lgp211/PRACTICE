package com.manulife.ap.core.policy.transaction.service;

import com.manulife.ap.core.policy.transaction.model.PolicyTransaction;

import java.util.Map;
import java.util.Set;

public interface PolicyTransactionService {
  Map<String, PolicyTransaction> findTransactionByPolicyNumbers(Set<String> policyNumbers);
}
