package com.manulife.ap.core.policy.underwriting.service;

import com.manulife.ap.core.policy.underwriting.model.OtherUnderwriting;

import java.util.List;
import java.util.Set;

public interface OtherUnderwritingRepository {
  List<OtherUnderwriting> findAllByPolicyNumbers(Set<String> policyNumbers);
}
