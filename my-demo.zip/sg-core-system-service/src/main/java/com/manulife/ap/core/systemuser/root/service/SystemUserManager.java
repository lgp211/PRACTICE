package com.manulife.ap.core.systemuser.root.service;

import com.manulife.ap.core.systemuser.root.model.SystemUser;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Validated
public class SystemUserManager implements SystemUserService {
  private final SystemUserRepository systemUserRepository;

  @Override
  public List<SystemUser> findByUserIds(final List<String> userIds) {
    return Optional.ofNullable(userIds)
      .map(systemUserRepository::findByUserIds)
      .orElse(Collections.emptyList());
  }
}
