package com.manulife.ap.core.policy.underwriting.service;

import com.manulife.ap.core.policy.underwriting.model.OutstandingDocument;

import java.util.List;
import java.util.Set;

public interface OutstandingDocumentRepository {
  List<OutstandingDocument> findAllByPolicyNumbers(Set<String> policyNumbers);
}
