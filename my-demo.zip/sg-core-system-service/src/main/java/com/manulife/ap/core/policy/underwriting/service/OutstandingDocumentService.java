package com.manulife.ap.core.policy.underwriting.service;

import com.manulife.ap.core.policy.underwriting.model.OutstandingDocument;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface OutstandingDocumentService {
  Map<String, List<OutstandingDocument>> findAllByPolicyNumbers(Set<String> policyNumbers);
}
