package com.manulife.ap.core.common.model;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum FilterValueDataType {
  STRING,
  LOCAL_DATE
}
