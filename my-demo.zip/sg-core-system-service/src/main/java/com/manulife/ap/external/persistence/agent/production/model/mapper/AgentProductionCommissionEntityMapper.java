package com.manulife.ap.external.persistence.agent.production.model.mapper;

import com.manulife.ap.common.mapper.BooleanMapper;
import com.manulife.ap.common.mapper.BooleanMapping;
import com.manulife.ap.common.mapper.StringToBoolean;
import com.manulife.ap.core.agent.production.model.AgentProductionCommission;
import com.manulife.ap.external.persistence.agent.production.model.AgentProductionCommissionEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = {BooleanMapping.class})
public interface AgentProductionCommissionEntityMapper {
  static AgentProductionCommissionEntityMapper get() {
    return AgentProductionCommissionEntityMapper.ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final AgentProductionCommissionEntityMapper INSTANCE =
      Mappers.getMapper(AgentProductionCommissionEntityMapper.class);
    private ModelMapperInstance() {}
  }

  @Mapping(target = "month", source = "entity.id.productionMonth")
  @Mapping(target = "agentCode", source = "entity.id.agentCode")
  @Mapping(target = "policyNumber", source = "entity.id.policyNumber")
  @Mapping(target = "planCode", source = "entity.id.planCode")
  @Mapping(target = "planType", source = "entity.planType")
  @Mapping(target = "planName", source = "entity.planName")
  @Mapping(target = "currencyCode", source = "entity.currencyCode")
  @Mapping(target = "soldToFamily", source = "entity.familyIndicator", qualifiedBy = {BooleanMapper.class, StringToBoolean.class})
  @Mapping(target = "description", source = "entity.id.description")
  @Mapping(target = "splitRatio", source = "entity.splitRatio")
  @Mapping(target = "singlePremium.efyc", source = "entity.spEfyc")
  @Mapping(target = "singlePremium.afyc", defaultValue = "0")
  @Mapping(target = "singlePremium.nac", source = "entity.spNac")
  @Mapping(target = "singlePremium.caseCount", source = "entity.spCaseCount")
  @Mapping(target = "singlePremium.anp", source = "entity.spAnp")
  @Mapping(target = "singlePremium.premiumAmount", source = "entity.spPremiumAmount")
  @Mapping(target = "singlePremium.netApe", defaultValue = "0")
  @Mapping(target = "regularPremium.efyc", source = "entity.rpEfyc")
  @Mapping(target = "regularPremium.afyc", defaultValue = "0")
  @Mapping(target = "regularPremium.nac", source = "entity.rpNac")
  @Mapping(target = "regularPremium.caseCount", source = "entity.rpCaseCount")
  @Mapping(target = "regularPremium.anp", source = "entity.rpAnp")
  @Mapping(target = "regularPremium.premiumAmount", source = "entity.rpPremiumAmount")
  @Mapping(target = "regularPremium.netApe", defaultValue = "0")
  @Mapping(target = "total.efyc", source = "entity.efyc")
  @Mapping(target = "total.afyc", source = "entity.afyc")
  @Mapping(target = "total.nac", source = "entity.nac")
  @Mapping(target = "total.caseCount", source = "entity.caseCount")
  @Mapping(target = "total.anp", expression = "java(0.0)")
  @Mapping(target = "total.premiumAmount", expression = "java(0.0)")
  @Mapping(target = "total.netApe", source = "entity.netApe")
  AgentProductionCommission toAgentProductionCommission(AgentProductionCommissionEntity entity);
}
