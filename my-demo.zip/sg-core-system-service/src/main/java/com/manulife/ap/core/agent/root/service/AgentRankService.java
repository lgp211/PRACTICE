package com.manulife.ap.core.agent.root.service;

import com.manulife.ap.core.agent.root.model.AgentRank;

import java.util.List;

public interface AgentRankService {
  List<AgentRank> findAllByRankCodeIn(List<String> rankCodes);
}
