package com.manulife.ap.core.policy.underwriting.service;

import com.manulife.ap.core.policy.underwriting.model.PolicyUnderwritingChange;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class PolicyUnderwritingChangeManager implements PolicyUnderwritingChangeService {

  private final PolicyUnderwritingChangeRepository policyUnderwritingChangeRepository;

  @Override
  public Map<String, List<PolicyUnderwritingChange>> findAllByPolicyNumbers(final Set<String> policyNumbers) {
    return Optional.ofNullable(policyNumbers)
      .map(list -> policyUnderwritingChangeRepository.findAllByPolicyNumbers(policyNumbers)
        .parallelStream()
        .collect(groupingBy(PolicyUnderwritingChange::getPolicyNumber))
      )
      .orElse(Collections.emptyMap());
  }
}
