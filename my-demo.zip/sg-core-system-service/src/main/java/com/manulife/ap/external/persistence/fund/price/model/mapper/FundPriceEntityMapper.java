package com.manulife.ap.external.persistence.fund.price.model.mapper;

import com.manulife.ap.core.fund.price.model.FundPrice;
import com.manulife.ap.external.persistence.fund.price.model.FundPriceEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Collection;
import java.util.List;

@Mapper
public interface FundPriceEntityMapper {
  static FundPriceEntityMapper get() {
    return FundPriceEntityMapper.ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final FundPriceEntityMapper INSTANCE = Mappers.getMapper(FundPriceEntityMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "fundId", source = "entity.id.fundId")
  @Mapping(target = "fundVersion", source = "entity.id.fundVersion")
  @Mapping(target = "effectiveStartDate", source = "entity.id.effectiveStartDate")
  @Mapping(target = "sellPrice", source = "entity.sellPrice")
  @Mapping(target = "buyPrice", source = "entity.buyPrice")
  FundPrice toDoaminObject(FundPriceEntity entity);

  List<FundPrice> toFundPriceList(Collection<FundPriceEntity> entities);
}