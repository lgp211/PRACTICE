package com.manulife.ap.external.persistence.policy.financial.model.mapper;

import com.manulife.ap.core.policy.financial.model.PolicyFinancial;
import com.manulife.ap.external.persistence.policy.financial.model.PolicyFinancialEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface PolicyFinancialEntityMapper {

  static PolicyFinancialEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final PolicyFinancialEntityMapper INSTANCE = Mappers.getMapper(PolicyFinancialEntityMapper.class);

    private ModelMapperInstance() {
    }
  }
  @Mapping(target = "policyNumber", source = "entity.policyNumber")
  @Mapping(target = "basicCashValue", source = "entity.basicCashValue")
  @Mapping(target = "nonGuaranteedTerminalBonus", source = "entity.nonGuaranteedTerminalBonus")
  @Mapping(target = "surrenderValue", source = "entity.surrenderValue")
  @Mapping(target = "couponBalance", source = "entity.couponBalance")
  @Mapping(target = "csaBalance", source = "entity.csaBalance")
  @Mapping(target = "netSurrenderValue", source = "entity.surrenderValue")
  @Mapping(target = "outstandingLoan", source = "entity.outstandingLoan")
  @Mapping(target = "outstandingInterestFreeLoan", source = "entity.outstandingInterestFreeLoan")
  @Mapping(target = "totalAvailableLoan", source = "entity.totalAvailableLoan")
  @Mapping(target = "totalAvailableInterestFreeLoan", source = "entity.totalAvailableInterestFreeLoan")
  PolicyFinancial toPolicyFinancial(PolicyFinancialEntity entity);
}
