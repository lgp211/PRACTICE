package com.manulife.ap.core.agent.thirdparty.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;
import java.util.Optional;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AgentThirdPartyCompany {
  @Builder.Default
  private AgentThirdPartyCompanyKey key = AgentThirdPartyCompanyKey.builder().build();
  private String name;

  public String getCode() {
    return Optional.ofNullable(this.key)
      .map(AgentThirdPartyCompanyKey::getCode)
      .orElse(null);
  }

  /**
   * Return <code>true</code> if match with given company code.
   *
   * @param companyCode Company code to match
   * @return <code>true</code> if given company code match with current object; otherwise <code>false</code>.
   */
  public boolean match(final String companyCode) {
    return Objects.toString(companyCode, "")
      .equals(Objects.toString(this.key.getCode(), ""));
  }

  /**
   * Return true if given company code and id are matching.
   *
   * @param companyCode Company code
   * @param companyId Company ID
   * @return <code>true</code> if given company code and id match with current object; otherwise <code>false</code>.
   */
  public boolean match(final String companyCode, final String companyId) {
    return Objects.toString(companyCode, "").equals(this.key.getCode()) &&
      Objects.toString(companyId, "").equals(this.key.getId());
  }
}
