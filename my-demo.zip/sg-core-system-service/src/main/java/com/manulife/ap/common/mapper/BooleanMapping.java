package com.manulife.ap.common.mapper;

import com.google.common.base.Strings;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.stream.Stream;

@BooleanMapper
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class BooleanMapping {

  /**
   * Valid boolean in string: Y, Yes, T, True, 1 (all case insensitive)
   *
   * @param boolString Boolean in string
   * @return <code>true</code> if given boolString is valid; otherwise <code>false</code>.
   */
  @StringToBoolean
  public static boolean stringToBoolean(String boolString) {
    if (Strings.isNullOrEmpty(boolString)) {
      return false;
    }

    return Stream.of("Y", "Yes", "T", "True", "1")
      .anyMatch(boolString::equalsIgnoreCase);
  }
}
