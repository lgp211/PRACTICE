package com.manulife.ap.external.persistence.policy.coverage.repository;

import com.manulife.ap.external.persistence.policy.coverage.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface CoverageUnderwritingRatingEntityRepository extends JpaRepository<CoverageUnderwritingRatingEntity, CoverageUnderwritingRatingId> {
  List<CoverageUnderwritingRatingEntity> findAllByIdIn(Set<CoverageUnderwritingRatingId> coverageUnderwritingRatingId);
}

