package com.manulife.ap.external.persistence.policy.transaction.model.mapper;

import com.manulife.ap.common.mapper.LocalDateMapper;
import com.manulife.ap.common.mapper.LocalDateMapping;
import com.manulife.ap.common.mapper.StringToLocalDate;
import com.manulife.ap.core.policy.transaction.model.PolicyPremiumTransaction;
import com.manulife.ap.external.persistence.policy.transaction.model.PolicyPremiumTransactionEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Collection;
import java.util.List;

@Mapper(uses = LocalDateMapping.class)
public interface PolicyPremiumTransactionEntityMapper {

  static PolicyPremiumTransactionEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final PolicyPremiumTransactionEntityMapper INSTANCE = Mappers.getMapper(PolicyPremiumTransactionEntityMapper.class);

    private ModelMapperInstance() {
    }
  }
  @Mapping(target = "policyNumber", source = "policyPremiumTransaction.id.policyNumber")
  @Mapping(target = "date", source = "policyPremiumTransaction.id.date" , qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "shiNumber", source = "policyPremiumTransaction.id.shiNumber")
  @Mapping(target = "appliedAmount", source = "policyPremiumTransaction.appliedAmount")
  PolicyPremiumTransaction toPolicyPremiumTransaction(PolicyPremiumTransactionEntity policyPremiumTransaction);

  List<PolicyPremiumTransaction> toPolicyPremiumTransactionList(Collection<PolicyPremiumTransactionEntity> policyPremiumTransactionList);

}
