package com.manulife.ap.core.customer.root.service;

import com.manulife.ap.core.common.model.FilterCriteria;
import com.manulife.ap.core.customer.root.model.Customer;

import javax.validation.Valid;
import java.util.List;

public interface CustomerRepository {
  List<Customer> findAllByClientNumberIn(List<String> clientNumbers);

  List<Customer> findAllByCriteria(@Valid List<FilterCriteria> filterCriteriaList);
}
