package com.manulife.ap.core.policy.transaction.service;

import com.manulife.ap.core.policy.transaction.model.PolicyTransaction;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
public class PolicyTransactionManager implements PolicyTransactionService {

  @Override
  public Map<String, PolicyTransaction> findTransactionByPolicyNumbers(final Set<String> policyNumbers) {
    if (Objects.isNull(policyNumbers) || policyNumbers.isEmpty()) {
      return Collections.emptyMap();
    }

    Map<String, PolicyTransaction> transactionMap = new HashMap<>();
    policyNumbers.forEach(policyNumber ->
      transactionMap.put(policyNumber, PolicyTransaction.builder().policyNumber(policyNumber).build())
    );

    return transactionMap;
  }
}
