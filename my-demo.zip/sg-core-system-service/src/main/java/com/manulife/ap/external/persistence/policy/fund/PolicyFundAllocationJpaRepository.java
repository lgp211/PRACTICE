package com.manulife.ap.external.persistence.policy.fund;

import com.manulife.ap.core.policy.fund.model.PolicyFundAllocation;
import com.manulife.ap.core.policy.fund.service.PolicyFundAllocationRepository;
import com.manulife.ap.external.persistence.policy.fund.model.mapper.PolicyFundAllocationEntityMapper;
import com.manulife.ap.external.persistence.policy.fund.repository.PolicyFundAllocationEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Component
@RequiredArgsConstructor
public class PolicyFundAllocationJpaRepository implements PolicyFundAllocationRepository {

  private final PolicyFundAllocationEntityRepository policyFundAllocationEntityRepository;

  @Override
  public List<PolicyFundAllocation> findAllByPolicyNumbers(final Set<String> policyNumbers) {
    return Optional.ofNullable(policyNumbers)
      .map(policyFundAllocationEntityRepository::findAllByIdPolicyNumberIn)
      .map(entityList -> PolicyFundAllocationEntityMapper.get().toPolicyFundAllocationList(entityList))
      .orElse(Collections.emptyList());
  }
}
