package com.manulife.ap.core.policy.layer.service;

import com.manulife.ap.core.policy.layer.model.PolicyLayer;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface PolicyLayerService {
  Map<String, List<PolicyLayer>> findLayersByPolicyNumbers(Set<String> policyNumbers);
}
