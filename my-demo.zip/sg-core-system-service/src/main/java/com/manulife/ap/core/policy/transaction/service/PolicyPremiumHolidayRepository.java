package com.manulife.ap.core.policy.transaction.service;

import com.manulife.ap.core.policy.transaction.model.PolicyPremiumHoliday;

import java.util.List;
import java.util.Set;

public interface PolicyPremiumHolidayRepository {
  List<PolicyPremiumHoliday> findAllByPolicyNumbers(Set<String> policyNumbers);
}
