package com.manulife.ap.core.systemuser.root.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AwsLogin {
  private LocalDate lastLoginDate;
  private String lastLoginStatus;
  private Integer numberOfInvalidTrials;
}
