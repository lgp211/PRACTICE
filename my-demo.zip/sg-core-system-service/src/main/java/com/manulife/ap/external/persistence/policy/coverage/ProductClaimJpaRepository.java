package com.manulife.ap.external.persistence.policy.coverage;

import com.manulife.ap.core.policy.coverage.model.ProductClaim;
import com.manulife.ap.core.policy.coverage.model.ProductPlanKey;
import com.manulife.ap.core.policy.coverage.service.ProductClaimRepository;
import com.manulife.ap.external.persistence.policy.coverage.model.ProductClaimEntity;
import com.manulife.ap.external.persistence.policy.coverage.model.mapper.ProductClaimEntityMapper;
import com.manulife.ap.external.persistence.policy.coverage.repository.ProductClaimEntityRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class ProductClaimJpaRepository implements ProductClaimRepository {

  private final ProductClaimEntityRepository productClaimEntityRepository;

  @Override
  public List<ProductClaim> findByProductPlanKeys(Set<ProductPlanKey> productPlanKeys) {
    if (CollectionUtils.isEmpty(productPlanKeys)) {
      return Collections.emptyList();
    }

    List<ProductClaimEntity> claimEntityList = new ArrayList<>();
    productPlanKeys.forEach(productPlanKey ->
      claimEntityList.addAll(productClaimEntityRepository.findAllByIdPlanCodeAndIdPlanVersion(productPlanKey.getPlanCode(), productPlanKey.getPlanVersion()))
    );

    return claimEntityList.parallelStream()
      .map(entity -> ProductClaimEntityMapper.getInstance().toProductClaim(entity))
      .collect(Collectors.toList());
  }
}
