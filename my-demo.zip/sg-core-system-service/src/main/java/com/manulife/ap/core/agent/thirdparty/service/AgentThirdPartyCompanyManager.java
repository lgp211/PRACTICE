package com.manulife.ap.core.agent.thirdparty.service;

import com.manulife.ap.core.agent.thirdparty.model.AgentThirdPartyCompany;
import com.manulife.ap.core.agent.thirdparty.model.AgentThirdPartyCompanyKey;
import lombok.RequiredArgsConstructor;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

@RequiredArgsConstructor
public class AgentThirdPartyCompanyManager implements AgentThirdPartyCompanyService {
  private final AgentThirdPartyCompanyRepository agentThirdPartyCompanyRepository;

  @Override
  public List<AgentThirdPartyCompany> findAllByKeyIn(List<AgentThirdPartyCompanyKey> keys) {
    if (Objects.isNull(keys) || keys.isEmpty()) {
      return Collections.emptyList();
    }

    return agentThirdPartyCompanyRepository.findAllByKeyIn(keys);
  }
}
