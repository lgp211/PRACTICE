package com.manulife.ap.external.persistence.policy.coverage;

import com.manulife.ap.core.policy.coverage.model.CoverageLayer;
import com.manulife.ap.core.policy.coverage.model.CoverageLayerKey;
import com.manulife.ap.core.policy.coverage.service.CoverageLayerRepository;
import com.manulife.ap.external.persistence.policy.coverage.model.CoverageLayerEntity;
import com.manulife.ap.external.persistence.policy.coverage.model.mapper.CoverageLayerEntityMapper;
import com.manulife.ap.external.persistence.policy.coverage.repository.CoverageLayerEntityRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.stream.Collectors;

@Repository
@RequiredArgsConstructor
public class CoverageLayerJpaRepository implements CoverageLayerRepository {
  private final CoverageLayerEntityRepository coverageLayerEntityRepository;

  @Override
  public List<CoverageLayer> findAllByCoverageLayerKeyIn(final Set<CoverageLayerKey> coverageLayerKeys) {

    if (CollectionUtils.isEmpty(coverageLayerKeys)) {
      return Collections.emptyList();
    }

    List<CoverageLayerEntity> entities = new ArrayList<>();

    coverageLayerKeys.forEach(coverageLayerKey ->
      entities.addAll(
        coverageLayerEntityRepository.findAllByIdPolicyNumberAndIdClientNumberAndIdPlanCodeAndIdPlanVersionAndIdCoverageEffectiveDate(
          coverageLayerKey.getPolicyNumber(), coverageLayerKey.getClientNumber(), coverageLayerKey.getPlanCode(),
          coverageLayerKey.getPlanVersion(), coverageLayerKey.getCoverageEffectiveDate()
        )
      )
    );

    return entities.stream()
      .map(entity ->
        CoverageLayerEntityMapper.get().toCoverageLayer(entity)
      )
      .collect(Collectors.toList());
  }
}