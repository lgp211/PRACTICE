package com.manulife.ap.core.policy.coverage.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CoverageUnderwriting {
  private String policyNumber;
  private String planCode;
  private String planVersion;
  private CoverageUnderwritingRating rating;
  private CoverageUnderwritingStatus status;
}