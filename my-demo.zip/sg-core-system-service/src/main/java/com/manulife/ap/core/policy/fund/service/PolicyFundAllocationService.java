package com.manulife.ap.core.policy.fund.service;

import com.manulife.ap.core.policy.fund.model.PolicyFundAllocation;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface PolicyFundAllocationService {
  Map<String, List<PolicyFundAllocation>> findAllByPolicyNumbers(Set<String> policyNumbers);
}
