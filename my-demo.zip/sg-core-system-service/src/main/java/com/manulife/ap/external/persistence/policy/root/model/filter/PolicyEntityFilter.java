package com.manulife.ap.external.persistence.policy.root.model.filter;

import com.manulife.ap.core.common.model.FilterValueDataType;
import com.manulife.ap.core.policy.common.model.PolicyFilter;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;
import java.util.stream.Stream;

@AllArgsConstructor
@Getter
public enum PolicyEntityFilter {

  STATUS (PolicyFilter.STATUS, "status", FilterValueDataType.STRING),
  PRIMARY_SERVICING_AGENT (PolicyFilter.PRIMARY_SERVICING_AGENT, "primaryServicingAgent", FilterValueDataType.STRING),
  PAID_TO_DATE_RANGE (PolicyFilter.PAID_TO_DATE_RANGE, "paidToDate", FilterValueDataType.LOCAL_DATE);

  private final PolicyFilter filterType;
  private final String columnName;
  private final FilterValueDataType columnDataType;

  public static String getColumnNameByFilter(final String filterName) {
    return Stream.of(values())
      .filter(filter -> filter.filterType.name().equalsIgnoreCase(Objects.toString(filterName, "")))
      .findFirst()
      .map(PolicyEntityFilter::getColumnName)
      .orElseThrow(IllegalArgumentException::new);
  }

  public static FilterValueDataType getColumnDataTypeByFilter(final String filterName) {
    return Stream.of(values())
      .filter(filter -> filter.filterType.name().equalsIgnoreCase(Objects.toString(filterName, "")))
      .findFirst()
      .map(PolicyEntityFilter::getColumnDataType)
      .orElseThrow(IllegalArgumentException::new);
  }
}
