package com.manulife.ap.core.policy.root.service;

import com.manulife.ap.core.common.model.FilterCriteria;
import com.manulife.ap.core.policy.root.model.Policy;

import java.util.List;

public interface PolicyRepository {
  List<Policy> findByPolicyNumbers(List<String> policyNumbers);

  List<Policy> findAllByCriteria(List<FilterCriteria> filterCriteriaList);
}
