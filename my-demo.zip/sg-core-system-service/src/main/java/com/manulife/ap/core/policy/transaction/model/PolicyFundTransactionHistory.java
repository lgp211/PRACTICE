package com.manulife.ap.core.policy.transaction.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyFundTransactionHistory {
  private String policyNumber;
  private String transactionId;
  private Integer fundTransactionNumber;
  private String fundId;
  private String fundVersion;
  private TransactionType type;
  private LocalDate date;
  private TransactionCode code;
  private Double amount;
}
