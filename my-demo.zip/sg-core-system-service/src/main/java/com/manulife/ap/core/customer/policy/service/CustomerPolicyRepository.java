package com.manulife.ap.core.customer.policy.service;

import com.manulife.ap.core.customer.policy.model.CustomerPolicy;

import java.util.List;

public interface CustomerPolicyRepository {
  List<CustomerPolicy> findAllByClientNumberIn(List<String> clientNumbers);
}
