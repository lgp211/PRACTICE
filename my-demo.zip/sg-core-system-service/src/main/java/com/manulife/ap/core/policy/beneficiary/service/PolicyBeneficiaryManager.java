package com.manulife.ap.core.policy.beneficiary.service;

import com.manulife.ap.core.policy.beneficiary.model.PolicyBeneficiary;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class PolicyBeneficiaryManager implements PolicyBeneficiaryService {
  private final PolicyBeneficiaryRepository policyBeneficiaryRepository;

  public Map<String, List<PolicyBeneficiary>> findAllByPolicyNumbersIn(final Set<String> policyNumbers) {
    if (Objects.isNull(policyNumbers) || policyNumbers.isEmpty()) {
      return Collections.emptyMap();
    }

    return policyBeneficiaryRepository
      .findAllByPolicyNumberIn(policyNumbers)
      .stream()
      .collect(groupingBy(PolicyBeneficiary::getPolicyNumber));
  }
}