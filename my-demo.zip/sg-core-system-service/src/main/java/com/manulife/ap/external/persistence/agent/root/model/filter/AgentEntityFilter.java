package com.manulife.ap.external.persistence.agent.root.model.filter;

import com.manulife.ap.core.agent.root.model.AgentFilter;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;
import java.util.stream.Stream;

@AllArgsConstructor
@Getter
public enum AgentEntityFilter {

  UNIT_CODE (AgentFilter.UNIT_CODE, "unitCode"),
  STATUS (AgentFilter.STATUS, "status");

  private final AgentFilter filterType;
  private final String columnName;

  public static String getColumnNameByFilter(final String filterName) {
    return Stream.of(values())
      .filter(filter -> filter.filterType.getName().equalsIgnoreCase(Objects.toString(filterName, "")))
      .findFirst()
      .map(AgentEntityFilter::getColumnName)
      .orElseThrow(IllegalArgumentException::new);
  }
}
