package com.manulife.ap.external.persistence.policy.coverage.repository;

import com.manulife.ap.external.persistence.policy.coverage.model.CoverageLayerEntity;
import com.manulife.ap.external.persistence.policy.coverage.model.CoverageLayerId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface CoverageLayerEntityRepository extends JpaRepository<CoverageLayerEntity, CoverageLayerId> {
  List<CoverageLayerEntity> findAllByIdPolicyNumberAndIdClientNumberAndIdPlanCodeAndIdPlanVersionAndIdCoverageEffectiveDate(
    String policyNumber, String clientNumber, String planCode, String planVersion, LocalDate coverageEffectiveDate);
}