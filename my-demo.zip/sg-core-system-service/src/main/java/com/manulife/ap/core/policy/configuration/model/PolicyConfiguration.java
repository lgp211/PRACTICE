package com.manulife.ap.core.policy.configuration.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyConfiguration {
  private DividendConfiguration dividend;
  private DeathBenefitConfiguration deathBenefit;
  private NewFundOfferConfiguration nfo;
  private AnnuityConfiguration annuity;
  private AccumulationConfiguration accumulation;
  private BillingConfiguration billing;
  private PaymentConfiguration payment;
  private InitialPublicOfferingConfiguration ipo;
  private GiroConfig giro;
  private RebalancingConfig rebalancing;
  private PayForPerformance payForPerformance;
  private PayoutConfiguration payout;
  private TrustConfiguration trust;
}
