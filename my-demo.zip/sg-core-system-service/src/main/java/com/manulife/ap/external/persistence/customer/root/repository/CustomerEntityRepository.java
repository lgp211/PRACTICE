package com.manulife.ap.external.persistence.customer.root.repository;

import com.manulife.ap.external.persistence.customer.root.model.CustomerEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface CustomerEntityRepository
  extends JpaRepository<CustomerEntity, String>, JpaSpecificationExecutor<CustomerEntity> {
}
