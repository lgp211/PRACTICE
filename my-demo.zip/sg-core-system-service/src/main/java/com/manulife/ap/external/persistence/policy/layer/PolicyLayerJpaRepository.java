package com.manulife.ap.external.persistence.policy.layer;

import com.manulife.ap.core.policy.layer.model.PolicyLayer;
import com.manulife.ap.core.policy.layer.service.PolicyLayerRepository;
import com.manulife.ap.external.persistence.policy.layer.model.mapper.PolicyLayerEntityMapper;
import com.manulife.ap.external.persistence.policy.layer.repository.PolicyLayerEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Component
@RequiredArgsConstructor
public class PolicyLayerJpaRepository implements PolicyLayerRepository {

  private final PolicyLayerEntityRepository policyLayerEntityRepository;

  @Override
  public List<PolicyLayer> findLayersByPolicyNumbers(final Set<String> policyNumbers) {
    return Optional.ofNullable(policyNumbers)
      .map(policyLayerEntityRepository::findAllByIdPolicyNumberIn)
      .map(entityList -> PolicyLayerEntityMapper.get().toPolicyLayerList(entityList))
      .orElse(Collections.emptyList());
  }
}
