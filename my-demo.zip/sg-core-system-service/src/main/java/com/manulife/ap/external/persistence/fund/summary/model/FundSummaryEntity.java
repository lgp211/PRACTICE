package com.manulife.ap.external.persistence.fund.summary.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TFUND_SUMMARY")
public class FundSummaryEntity {

  @EmbeddedId
  private FundSummaryId id;

  @Column(name = "FND_BAL")
  private Double fundBalance;
}