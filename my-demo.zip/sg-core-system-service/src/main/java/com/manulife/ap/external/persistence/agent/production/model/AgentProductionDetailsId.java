package com.manulife.ap.external.persistence.agent.production.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Embeddable
public class AgentProductionDetailsId implements Serializable {
  @Column(name = "PRODN_MTH")
  private String productionMonth;

  @Column(name = "POL_NUM")
  private String policyNumber;

  @Column(name = "PLAN_CODE")
  private String planCode;

  @Column(name = "TXN_DT")
  private String date;

  @Column(name = "TXN_DESC")
  private String description;

  @Column(name = "CONS_TYP")
  private String conservationType;

  @Column(name = "AGT_CD")
  private String agentCode;
}
