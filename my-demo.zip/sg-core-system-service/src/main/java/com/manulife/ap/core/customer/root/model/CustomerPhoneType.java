package com.manulife.ap.core.customer.root.model;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum CustomerPhoneType {
  PRIMARY,
  MOBILE,
  FAX,
  OTHER
}
