package com.manulife.ap.external.persistence.policy.coverage;

import com.manulife.ap.core.policy.coverage.model.CoverageUnderwritingStatus;
import com.manulife.ap.core.policy.coverage.service.CoverageUnderwritingStatusRepository;
import com.manulife.ap.external.persistence.policy.coverage.model.mapper.CoverageUnderwritingStatusEntityMapper;
import com.manulife.ap.external.persistence.policy.coverage.repository.CoverageUnderwritingEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Repository
@RequiredArgsConstructor
public class CoverageUnderwritingStatusJpaRepository implements CoverageUnderwritingStatusRepository {
  private final CoverageUnderwritingEntityRepository coverageUnderwritingEntityRepository;

  @Override
  public List<CoverageUnderwritingStatus> findAllByPolicyNumberIn(final Set<String> policyNumbers) {
    if (Objects.isNull(policyNumbers) || policyNumbers.isEmpty()) {
      return Collections.emptyList();
    }

    return coverageUnderwritingEntityRepository.findAllById(policyNumbers)
      .stream()
      .map(entity -> CoverageUnderwritingStatusEntityMapper.get().toCoverageUnderwritingStatus(entity))
      .collect(Collectors.toList());
  }
}