package com.manulife.ap.external.persistence.customer.root.model.filter;

import com.manulife.ap.core.customer.common.model.CustomerFilter;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;
import java.util.stream.Stream;

@AllArgsConstructor
@Getter
public enum CustomerEntityFilter {

  NAME (CustomerFilter.NAME, "name"),
  IDENTITY_NUMBER (CustomerFilter.IDENTITY_NUMBER, "identityNumber");

  private final CustomerFilter filterType;
  private final String columnName;

  public static String getColumnNameByFilter(final String filterName) {
    return Stream.of(values())
      .filter(filter -> filter.filterType.name().equalsIgnoreCase(Objects.toString(filterName, "")))
      .findFirst()
      .map(CustomerEntityFilter::getColumnName)
      .orElseThrow(IllegalArgumentException::new);
  }
}
