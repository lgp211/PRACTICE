package com.manulife.ap.external.persistence.policy.coverage.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TNT_UW")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CoverageUnderwritingEntity {

  @Id
  @Column(name = "POL_NUM")
  private String policyNumber;

  @Column(name = "UW_DISP_STAT")
  private String status;
}
