package com.manulife.ap.external.persistence.agent.root.repository;

import com.manulife.ap.external.persistence.agent.root.model.AgentStatusEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AgentStatusEntityRepository extends JpaRepository<AgentStatusEntity, String> {
}
