package com.manulife.ap.external.persistence.policy.coverage.repository;

import com.manulife.ap.external.persistence.policy.coverage.model.PolicyCoverageEntity;
import com.manulife.ap.external.persistence.policy.coverage.model.PolicyCoverageId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface PolicyCoverageEntityRepository extends JpaRepository<PolicyCoverageEntity, PolicyCoverageId> {
  List<PolicyCoverageEntity> findAllByIdPolicyNumberIn(Set<String> policyNumbers);
}
