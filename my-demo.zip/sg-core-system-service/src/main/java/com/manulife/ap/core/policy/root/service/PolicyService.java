package com.manulife.ap.core.policy.root.service;

import com.manulife.ap.core.common.model.FilterCriteria;
import com.manulife.ap.core.policy.root.model.Policy;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

public interface PolicyService {
  List<Policy> findByPolicyNumbers(List<String> policyNumbers);

  List<Policy> findAllByCriteria(
    @Valid
    @NotNull(message = "Search criteria cannot be null")
    @NotEmpty(message = "Search criteria cannot be empty")
      List<FilterCriteria> filterCriteriaList);
}
