package com.manulife.ap.external.persistence.agent.candidate;

import com.manulife.ap.core.agent.candidate.model.AgentCandidate;
import com.manulife.ap.core.agent.candidate.service.AgentCandidateRepository;
import com.manulife.ap.external.persistence.agent.candidate.model.mapper.AgentCandidateEntityMapper;
import com.manulife.ap.external.persistence.agent.candidate.repository.AgentCandidateEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class AgentCandidateJpaRepository implements AgentCandidateRepository {
  private final AgentCandidateEntityRepository agentCandidateEntityRepository;

  @Override
  public List<AgentCandidate> findAllByCandidateNumberIn(List<String> candidateNumbers) {
    if (Objects.isNull(candidateNumbers) || candidateNumbers.isEmpty()) {
      return Collections.emptyList();
    }

    return agentCandidateEntityRepository.findAllById(candidateNumbers)
      .parallelStream()
      .map(candidateEntity -> AgentCandidateEntityMapper.get().toAgentCandidate(candidateEntity))
      .collect(Collectors.toList());
  }
}
