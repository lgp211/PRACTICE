package com.manulife.ap.external.persistence.policy.coverage.model.mapper;

import com.manulife.ap.common.mapper.LocalDateMapper;
import com.manulife.ap.common.mapper.LocalDateMapping;
import com.manulife.ap.common.mapper.StringToLocalDate;
import com.manulife.ap.core.policy.coverage.model.PolicyCoverage;
import com.manulife.ap.external.persistence.policy.coverage.model.PolicyCoverageEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Collection;
import java.util.List;

@Mapper(uses = LocalDateMapping.class)
public interface PolicyCoverageEntityMapper {
  static PolicyCoverageEntityMapper get() {
    return PolicyCoverageEntityMapper.ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final PolicyCoverageEntityMapper INSTANCE = Mappers.getMapper(PolicyCoverageEntityMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "policyNumber", source = "entity.id.policyNumber")
  @Mapping(target = "clientNumber", source = "entity.id.clientNumber")
  @Mapping(target = "type.code", source = "entity.coverageType")
  @Mapping(target = "plan.code", source = "entity.id.planCode")
  @Mapping(target = "plan.version", source = "entity.id.planVersion")
  @Mapping(target = "effectiveDate", source = "entity.id.effectiveDate" , qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "status.code", source = "entity.status")
  @Mapping(target = "expiryDate", source = "entity.expiryDate" , qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "reason.code", source = "entity.reason")
  @Mapping(target = "premium.duration", source = "entity.duration")
  @Mapping(target = "premium.discount.amount", source = "entity.discountAmount")
  @Mapping(target = "premium.discount.percentage", source = "entity.discountPercentage")
  @Mapping(target = "options.pua.totalAmount",  source = "entity.totalAmount")
  @Mapping(target = "options.pua.currentAmount",  source = "entity.currentAmount")
  @Mapping(target = "jointClientNumber", source = "entity.jointClientNumber")
  @Mapping(target = "benefit.duration", source = "entity.benefitDuration")
  @Mapping(target = "benefit.faceAmount", source = "entity.faceAmount")
  @Mapping(target = "smoker.code", source = "entity.smokerCode")
  @Mapping(target = "effectiveAge", source = "entity.effectiveAge")
  @Mapping(target = "campaign.discount", source = "entity.campaignDiscount")
  PolicyCoverage toDomainObject(PolicyCoverageEntity entity);

  List<PolicyCoverage> toDomainObjectList(Collection<PolicyCoverageEntity> policyCoverageEntityList);
}
