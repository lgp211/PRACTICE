package com.manulife.ap.core.policy.coverage.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CoverageLayerKey {
  private String policyNumber;
  private String clientNumber;
  private String planCode;
  private String planVersion;
  private LocalDate coverageEffectiveDate;
}