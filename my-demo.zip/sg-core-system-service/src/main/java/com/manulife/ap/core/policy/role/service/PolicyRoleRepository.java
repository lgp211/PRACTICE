package com.manulife.ap.core.policy.role.service;

import com.manulife.ap.core.policy.role.model.PolicyRole;

import java.util.List;
import java.util.Set;

public interface PolicyRoleRepository {
  List<PolicyRole> findAllByPolicyNumbers(Set<String> policyNumbers);
}
