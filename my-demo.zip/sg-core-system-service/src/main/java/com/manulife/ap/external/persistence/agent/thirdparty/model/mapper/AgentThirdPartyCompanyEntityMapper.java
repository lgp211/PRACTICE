package com.manulife.ap.external.persistence.agent.thirdparty.model.mapper;

import com.manulife.ap.core.agent.thirdparty.model.AgentThirdPartyCompany;
import com.manulife.ap.external.persistence.agent.thirdparty.model.AgentThirdPartyCompanyEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AgentThirdPartyCompanyEntityMapper {
  static AgentThirdPartyCompanyEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final AgentThirdPartyCompanyEntityMapper INSTANCE = Mappers.getMapper(AgentThirdPartyCompanyEntityMapper.class);
    private ModelMapperInstance() {}
  }

  @Mapping(target = "key.code", source = "entity.id.companyCode")
  @Mapping(target = "key.id", source = "entity.id.companyId")
  @Mapping(target = "name", source = "entity.name")
  AgentThirdPartyCompany toAgentThirdPartyCompany(AgentThirdPartyCompanyEntity entity);
}
