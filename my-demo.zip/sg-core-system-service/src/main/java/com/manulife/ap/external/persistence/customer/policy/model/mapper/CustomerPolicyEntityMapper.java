package com.manulife.ap.external.persistence.customer.policy.model.mapper;

import com.manulife.ap.common.mapper.*;
import com.manulife.ap.core.customer.policy.model.CustomerPolicy;
import com.manulife.ap.external.persistence.customer.policy.model.CustomerPolicyEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = {LocalDateMapping.class})
public interface CustomerPolicyEntityMapper {
  static CustomerPolicyEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final CustomerPolicyEntityMapper INSTANCE = Mappers.getMapper(CustomerPolicyEntityMapper.class);
    private ModelMapperInstance() {}
  }

  @Mapping(target = "clientNumber", source = "entity.id.clientNumber")
  @Mapping(target = "policyNumber", source = "entity.id.policyNumber")
  @Mapping(target = "linkType.code", source = "entity.id.linkType")
  @Mapping(target = "correspondingAddressType", source = "entity.correspondingAddressType")
  @Mapping(target = "residentialAddressType", source = "entity.residentialAddressType")
  CustomerPolicy toCustomerPolicy(CustomerPolicyEntity entity);
}
