package com.manulife.ap.core.policy.root.model.field;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum PolicyAgentType {

  PRIMARY_SERVICING_AGENT("primaryServicingAgent"),
  SECONDARY_SERVICING_AGENT("secondaryServicingAgent"),
  PRIMARY_WRITING_AGENT("primaryWritingAgent"),
  SECONDARY_WRITING_AGENT("secondaryWritingAgent");

  public final String value;
}