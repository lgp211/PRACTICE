package com.manulife.ap.external.persistence.policy.coverage.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "TCOVERAGES")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@SecondaryTable(name = "TCOVERAGES_SG")
public class PolicyCoverageEntity {
  @EmbeddedId
  private PolicyCoverageId id;

  @Column(name = "CVG_TYP")
  private String coverageType;

  @Column(name = "CVG_STAT_CD")
  private String status;

  @Column(name = "XPRY_DT")
  private String expiryDate;

  @Column(name = "CVG_REASN")
  private String reason;

  @Column(name = "PREM_DUR")
  private String duration;

  @Column(name = "DSCNT_PREM")
  private String discountAmount;

  @Column(name = "DSCNT_PCT")
  private String discountPercentage;

  @Column(name = "PUA_TOT_AMT")
  private String totalAmount;

  @Column(name = "PUA_CRNT_AMT")
  private String currentAmount;

  @Column(name = "JOINT_CLI_NUM")
  private String jointClientNumber;

  @Column(name = "BNFT_DUR")
  private Integer benefitDuration;

  @Column(name = "FACE_AMT")
  private Double faceAmount;

  @Column(name = "SMKR_CODE")
  private String smokerCode;

  @Column(name = "CVG_EFF_AGE")
  private Integer effectiveAge;

  @Column(name = "CMPN_DSCNT", table = "TCOVERAGES_SG")
  private Double campaignDiscount;
}
