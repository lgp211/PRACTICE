package com.manulife.ap.external.persistence.policy.coverage;

import com.manulife.ap.core.policy.coverage.model.ProductClaimGroup;
import com.manulife.ap.core.policy.coverage.model.ProductPlanKey;
import com.manulife.ap.core.policy.coverage.service.ProductClaimGroupRepository;
import com.manulife.ap.external.persistence.policy.coverage.model.ProductClaimGroupId;
import com.manulife.ap.external.persistence.policy.coverage.model.mapper.ProductClaimGroupEntityMapper;
import com.manulife.ap.external.persistence.policy.coverage.model.mapper.ProductPlanGroupKeyMapper;
import com.manulife.ap.external.persistence.policy.coverage.repository.ProductClaimGroupEntityRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class ProductClaimGroupJpaRepository implements ProductClaimGroupRepository {

  private final ProductClaimGroupEntityRepository productClaimGroupEntityRepository;

  @Override
  public List<ProductClaimGroup> findByProductPlanKeys(Set<ProductPlanKey> productPlanKeys) {
    if (CollectionUtils.isEmpty(productPlanKeys)) {
      return Collections.emptyList();
    }

    Set<ProductClaimGroupId> productClaimGroupIds =
      ProductPlanGroupKeyMapper.get().toProductClaimGroupIdSet(productPlanKeys);

    return productClaimGroupEntityRepository.findAllByIdIn(productClaimGroupIds).parallelStream()
      .map(entity -> ProductClaimGroupEntityMapper.getInstance().toProductClaimGroup(entity))
      .collect(Collectors.toList());
  }
}
