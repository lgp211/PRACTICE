package com.manulife.ap.core.fund.price.service;

import com.manulife.ap.core.fund.price.model.FundPrice;
import com.manulife.ap.core.fund.price.model.FundPriceKey;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class FundPriceManager implements FundPriceService{
  private final FundPriceRepository fundPriceRepository;

  @Override
  public Map<FundPriceKey, List<FundPrice>> findAllByFundPriceKeyIn(Set<FundPriceKey> fundPriceKeys) {
    if (Objects.isNull(fundPriceKeys) || fundPriceKeys.isEmpty()) {
      return Collections.emptyMap();
    }

    return fundPriceRepository.findAllByFundPriceKeyIn(fundPriceKeys)
      .stream()
      .collect(groupingBy(fundPrice ->
          FundPriceKey.builder()
            .fundId(fundPrice.getFundId())
            .fundVersion(fundPrice.getFundVersion())
            .build()
      ));
  }
}