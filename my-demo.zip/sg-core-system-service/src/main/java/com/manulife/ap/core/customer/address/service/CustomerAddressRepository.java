package com.manulife.ap.core.customer.address.service;

import com.manulife.ap.core.customer.address.model.CustomerAddress;

import java.util.List;

public interface CustomerAddressRepository {
  List<CustomerAddress> findAllByClientNumberIn(List<String> clientNumbers);
}
