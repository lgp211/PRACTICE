package com.manulife.ap.external.persistence.policy.coverage;

import com.manulife.ap.core.policy.coverage.model.PolicyCoverage;
import com.manulife.ap.core.policy.coverage.service.PolicyCoverageRepository;
import com.manulife.ap.external.persistence.policy.coverage.model.mapper.PolicyCoverageEntityMapper;
import com.manulife.ap.external.persistence.policy.coverage.repository.PolicyCoverageEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class PolicyCoverageJpaRepository implements PolicyCoverageRepository {
  private final PolicyCoverageEntityRepository policyCoverageEntityRepository;

  @Override
  public List<PolicyCoverage> findCoveragesByPolicyNumbers(Set<String> policyNumbers) {
    return policyCoverageEntityRepository.findAllByIdPolicyNumberIn(policyNumbers)
      .stream()
      .map(coverageEntity -> PolicyCoverageEntityMapper.get().toDomainObject(coverageEntity))
      .collect(Collectors.toList());
  }
}
