package com.manulife.ap.core.agent.hierarchy.service;

import com.manulife.ap.core.agent.hierarchy.model.Agency;

import java.util.List;

public interface AgentHierarchyRepository {
  List<Agency> findAllAgenciesByAgencyCodesIn(List<String> agencyCodes);

  List<Agency> findAllAgenciesByManagerIn(List<String> managerAgentCodes);
}
