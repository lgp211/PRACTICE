package com.manulife.ap.core.policy.role.service;

import com.manulife.ap.core.policy.role.model.PolicyRole;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
public class PolicyRoleManager implements PolicyRoleService {

  private final PolicyRoleRepository policyRoleRepository;

  @Override
  public Map<String, List<PolicyRole>> findAllByPolicyNumbers(Set<String> policyNumbers) {
    if (Objects.isNull(policyNumbers) || policyNumbers.isEmpty()) {
      return Collections.emptyMap();
    }

    HashMap<String, List<PolicyRole>> roleMap = new HashMap<>();
    List<PolicyRole> policyRoles = policyRoleRepository.findAllByPolicyNumbers(policyNumbers);

    policyRoles.forEach(policyRole ->
      roleMap.computeIfAbsent(
        policyRole.getPolicyNumber(),
        k -> new ArrayList<>()
      ).add(policyRole)
    );

    return roleMap;
  }
}
