package com.manulife.ap.core.policy.coverage.model;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CoverageType {
  private String code;
}
