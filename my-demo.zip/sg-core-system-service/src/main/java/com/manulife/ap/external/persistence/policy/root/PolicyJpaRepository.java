package com.manulife.ap.external.persistence.policy.root;

import com.manulife.ap.core.common.model.FilterCriteria;
import com.manulife.ap.core.policy.root.model.Policy;
import com.manulife.ap.core.policy.root.service.PolicyRepository;
import com.manulife.ap.external.persistence.common.GenericSpecification;
import com.manulife.ap.external.persistence.policy.common.PolicySpecificationFactory;
import com.manulife.ap.external.persistence.policy.root.model.PolicyEntity;
import com.manulife.ap.external.persistence.policy.root.model.mapper.PolicyEntityMapper;
import com.manulife.ap.external.persistence.policy.root.repository.PolicyEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class PolicyJpaRepository implements PolicyRepository {
  private final PolicyEntityRepository policyEntityRepository;

  @Override
  public List<Policy> findByPolicyNumbers(final List<String> policyNumbers) {
    return Optional.ofNullable(policyNumbers)
        .map(policyEntityRepository::findAllById)
        .map(entityList -> PolicyEntityMapper.get().toDomainObjectList(entityList))
        .orElse(Collections.emptyList());
  }

  @Override
  public List<Policy> findAllByCriteria(final List<FilterCriteria> filterCriteriaList) {
    return Optional.of(filterCriteriaList)
      .map(list -> {
        GenericSpecification<PolicyEntity> specification =
          PolicySpecificationFactory.createSpecificationForPolicyEntity(list);

        return policyEntityRepository.findAll(specification)
          .parallelStream()
          .map(customerEntity -> PolicyEntityMapper.get().toDomainObject(customerEntity))
          .collect(Collectors.toList());
      })
      .orElse(Collections.emptyList());
  }
}
