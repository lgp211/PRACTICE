package com.manulife.ap.core.systemuser.root.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SystemUser {
  private String userId;
  private String role;
  private RecordStatus status;
  private TeamIdentification teamId;
  private String name;
  private String defaultPrinter;
  private String operatorId;
  private Integer nextComproSequence;
  private LocalDate passwordExpiryDate;
  private String printReportAccess;
  private String currentFunction;
  private String extensionNumber;
  private String designation;
  private String signer;
  private UndoRedo undoRedoDetails;
  private AwsLogin awsLoginDetails;

}
