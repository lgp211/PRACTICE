package com.manulife.ap.external.persistence.fund.summary;

import com.manulife.ap.core.fund.summary.model.FundSummary;
import com.manulife.ap.core.fund.summary.model.FundSummaryKey;
import com.manulife.ap.core.fund.summary.service.FundSummaryRepository;
import com.manulife.ap.external.persistence.fund.summary.model.FundSummaryEntity;
import com.manulife.ap.external.persistence.fund.summary.model.mapper.FundSummaryEntityMapper;
import com.manulife.ap.external.persistence.fund.summary.repository.FundSummaryEntityRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class FundSummaryJpaRepository implements FundSummaryRepository {
  private final FundSummaryEntityRepository fundSummaryEntityRepository;

  @Override
  public List<FundSummary> findAllByFundSummaryKeyIn(Set<FundSummaryKey> fundSummaryKeys) {
    if (CollectionUtils.isEmpty(fundSummaryKeys)) {
      return Collections.emptyList();
    }

    List<FundSummaryEntity> entities = new ArrayList<>();

    fundSummaryKeys.forEach(fundSummaryKey ->
      entities.addAll(
        fundSummaryEntityRepository.findAllByIdFundIdAndIdFundVersion(
          fundSummaryKey.getFundId(), fundSummaryKey.getFundVersion()
        )
      )
    );

    return entities.stream()
      .map(entity ->
        FundSummaryEntityMapper.get().toDoaminObject(entity)
      )
      .collect(Collectors.toList());
  }
}