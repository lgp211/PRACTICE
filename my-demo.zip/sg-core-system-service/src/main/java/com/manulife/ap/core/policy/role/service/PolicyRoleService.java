package com.manulife.ap.core.policy.role.service;

import com.manulife.ap.core.policy.role.model.PolicyRole;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface PolicyRoleService {

  Map<String, List<PolicyRole>> findAllByPolicyNumbers(Set<String> policyNumbers);
}
