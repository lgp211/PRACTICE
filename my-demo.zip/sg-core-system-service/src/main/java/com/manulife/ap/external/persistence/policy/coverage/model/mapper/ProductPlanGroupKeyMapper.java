package com.manulife.ap.external.persistence.policy.coverage.model.mapper;

import com.manulife.ap.core.policy.coverage.model.ProductPlanKey;
import com.manulife.ap.external.persistence.policy.coverage.model.ProductClaimGroupId;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Set;

@Mapper
public interface ProductPlanGroupKeyMapper {
  static ProductPlanGroupKeyMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final ProductPlanGroupKeyMapper INSTANCE = Mappers.getMapper(ProductPlanGroupKeyMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "planCode", source = "key.planCode")
  @Mapping(target = "planVersion", source = "key.planVersion")
  ProductClaimGroupId toProductClaimGroupId(ProductPlanKey key);

  Set<ProductClaimGroupId> toProductClaimGroupIdSet(Set<ProductPlanKey> keys);
}
