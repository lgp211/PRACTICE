package com.manulife.ap.external.persistence.policy.role.repository;

import com.manulife.ap.external.persistence.policy.role.model.PolicyRoleEntity;
import com.manulife.ap.external.persistence.policy.role.model.PolicyRoleId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface PolicyRoleEntityRepository extends JpaRepository<PolicyRoleEntity, PolicyRoleId> {
  List<PolicyRoleEntity> findAllByIdPolicyNumberIn(Set<String> policyNumbers);
}
