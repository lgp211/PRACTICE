package com.manulife.ap.external.persistence.agent.thirdparty.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "TAMS_3RD_PARTY_CO_SG")
public class AgentThirdPartyCompanyEntity {
  @EmbeddedId
  private AgentThirdPartyCompanyId id;

  @Column(name = "CO_NAME")
  private String name;
}
