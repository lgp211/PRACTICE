package com.manulife.ap.core.policy.transaction.model;

import com.manulife.ap.core.policy.layer.model.PolicyLayerType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyMonthiversaryCharges {
  private String policyNumber;
  private String mvySeq;
  private String deferralReason;
  private LocalDate layerEffectiveDate;
  private PolicyLayerType layerType;
  private Integer testLevel;
  private Integer processSeq;
  private String dbpIndicator;
  private Double totalAmount;
  private LocalDate currentMvyDate;
}