package com.manulife.ap.external.persistence.customer.address.repository;

import com.manulife.ap.external.persistence.customer.address.model.CustomerAddressEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomerAddressEntityRepository extends JpaRepository<CustomerAddressEntity, String> {
    List<CustomerAddressEntity> findAllByIdClientNumberIn(List<String> clientNumber);
}
