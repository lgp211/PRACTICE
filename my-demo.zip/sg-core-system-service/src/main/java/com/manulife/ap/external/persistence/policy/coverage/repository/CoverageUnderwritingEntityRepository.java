package com.manulife.ap.external.persistence.policy.coverage.repository;

import com.manulife.ap.external.persistence.policy.coverage.model.CoverageUnderwritingEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CoverageUnderwritingEntityRepository extends JpaRepository<CoverageUnderwritingEntity, String> {
}
