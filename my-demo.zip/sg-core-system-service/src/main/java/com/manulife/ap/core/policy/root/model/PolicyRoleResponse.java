package com.manulife.ap.core.policy.root.model;


import com.manulife.ap.core.customer.root.model.Customer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyRoleResponse {

    private Customer customer;
    private Policy policy;
}
