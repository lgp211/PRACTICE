package com.manulife.ap.core.supporting.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RecordStatus {
  public static final String ACTIVE = "A";
  public static final String INACTIVE = "I";

  private String value;

  public boolean isActive() {
    return ACTIVE.equalsIgnoreCase(String.valueOf(value));
  }
}
