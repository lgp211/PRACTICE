package com.manulife.ap.external.persistence.policy.layer.repository;

import com.manulife.ap.external.persistence.policy.layer.model.PolicyLayerEntity;
import com.manulife.ap.external.persistence.policy.layer.model.PolicyLayerId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface PolicyLayerEntityRepository extends JpaRepository<PolicyLayerEntity, PolicyLayerId> {
  List<PolicyLayerEntity> findAllByIdPolicyNumberIn(Set<String> policyNumbers);
}
