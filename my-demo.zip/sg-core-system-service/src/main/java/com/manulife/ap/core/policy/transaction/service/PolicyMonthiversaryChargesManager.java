package com.manulife.ap.core.policy.transaction.service;

import com.manulife.ap.core.policy.transaction.model.PolicyMonthiversaryCharges;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class PolicyMonthiversaryChargesManager implements PolicyMonthiversaryChargesService {
  private final PolicyMonthiversaryChargesRepository policyMonthiversaryChargesRepository;

  public Map<String, List<PolicyMonthiversaryCharges>> findAllByPolicyNumberIn(final Set<String> policyNumbers) {

    return Optional.ofNullable(policyNumbers)
      .map(list -> policyMonthiversaryChargesRepository.findAllByPolicyNumberIn(list)
        .stream()
        .collect(groupingBy(PolicyMonthiversaryCharges::getPolicyNumber))
      )
      .orElse(Collections.emptyMap());
  }
}