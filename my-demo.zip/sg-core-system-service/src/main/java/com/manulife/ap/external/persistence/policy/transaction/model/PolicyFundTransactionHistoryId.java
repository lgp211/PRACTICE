package com.manulife.ap.external.persistence.policy.transaction.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyFundTransactionHistoryId implements Serializable {
  @Column(name = "POL_NUM")
  private String policyNumber;

  @Column(name = "TRXN_ID")
  private String transactionId;

  @Column(name = "FTR_NUM")
  private Integer fundTransactionNumber;
}
