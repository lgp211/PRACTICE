package com.manulife.ap.external.persistence.policy.coverage.model.mapper;

import com.manulife.ap.common.mapper.LocalDateMapper;
import com.manulife.ap.common.mapper.LocalDateMapping;
import com.manulife.ap.common.mapper.StringToLocalDate;
import com.manulife.ap.core.policy.coverage.model.CoverageLayer;
import com.manulife.ap.external.persistence.policy.coverage.model.CoverageLayerEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Collection;
import java.util.List;

@Mapper(uses = LocalDateMapping.class)
public interface CoverageLayerEntityMapper {
  static CoverageLayerEntityMapper get() {
    return CoverageLayerEntityMapper.ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final CoverageLayerEntityMapper INSTANCE = Mappers.getMapper(CoverageLayerEntityMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "policyNumber", source = "entity.id.policyNumber")
  @Mapping(target = "clientNumber", source = "entity.id.clientNumber")
  @Mapping(target = "planCode", source = "entity.id.planCode")
  @Mapping(target = "planVersion", source = "entity.id.planVersion")
  @Mapping(target = "coverageEffectiveDate", source = "entity.id.coverageEffectiveDate" , qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "effectiveDate", source = "entity.id.layerEffectiveDate", qualifiedBy = {LocalDateMapper.class, StringToLocalDate.class})
  @Mapping(target = "status.code", source = "entity.statusCode")
  @Mapping(target = "smoker.code", source = "entity.smokerCode")
  CoverageLayer toCoverageLayer(CoverageLayerEntity entity);

  List<CoverageLayer> toCoverageLayerList(Collection<CoverageLayerEntity> coverageLayerEntityList);
}