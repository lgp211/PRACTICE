package com.manulife.ap.external.persistence.policy.role.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "TCLIENT_POLICY_LINKS")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyRoleEntity {
  @EmbeddedId
  private PolicyRoleId id;
}
