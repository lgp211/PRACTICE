package com.manulife.ap.core.policy.transaction.service;

import com.manulife.ap.core.policy.transaction.model.PolicyGiroTransaction;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface PolicyGiroTransactionService {
  Map<String, List<PolicyGiroTransaction>> findAllByPolicyNumberIn(Set<String> policyNumbers);
}