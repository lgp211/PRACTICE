package com.manulife.ap.core.fund.price.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FundPrice {
  private String fundId;
  private String fundVersion;
  private LocalDate effectiveStartDate;
  private Double buyPrice;
  private Double sellPrice;

  public boolean isKeyMatching(FundPriceKey fundPriceKey) {
    return this.fundId.equals(fundPriceKey.getFundId()) &&
      this.fundVersion.equals(fundPriceKey.getFundVersion());
  }
}