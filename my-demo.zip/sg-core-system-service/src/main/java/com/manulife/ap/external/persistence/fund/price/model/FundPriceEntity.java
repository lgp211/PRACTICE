package com.manulife.ap.external.persistence.fund.price.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TFUND_PRICES")
public class FundPriceEntity {

  @EmbeddedId
  private FundPriceId id;

  @Column(name = "BUY_PRIC")
  private Double buyPrice;

  @Column(name = "SELL_PRIC")
  private Double sellPrice;
}