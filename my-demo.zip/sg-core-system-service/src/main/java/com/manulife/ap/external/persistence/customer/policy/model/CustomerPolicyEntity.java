package com.manulife.ap.external.persistence.customer.policy.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "TCLIENT_POLICY_LINKS")
public class CustomerPolicyEntity {
  @EmbeddedId
  private CustomerPolicyId id;

  @Column(name = "ADDR_TYP")
  private String correspondingAddressType;

  @Column(name = "RES_ADDR_TYP")
  private String residentialAddressType;

}
