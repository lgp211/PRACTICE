package com.manulife.ap.core.policy.coverage.service;

import com.manulife.ap.core.policy.coverage.model.ProductClaimGroup;
import com.manulife.ap.core.policy.coverage.model.ProductPlanKey;

import java.util.List;
import java.util.Set;

public interface ProductClaimGroupRepository {
  List<ProductClaimGroup> findByProductPlanKeys(Set<ProductPlanKey> productPlanKeys);
}
