package com.manulife.ap.external.persistence.policy.coverage.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "TNT_RATE")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CoverageUnderwritingRatingEntity {
  @EmbeddedId
  private CoverageUnderwritingRatingId id;

  @Column(name = "RATING")
  private String rating;
}
