package com.manulife.ap.external.persistence.policy.layer.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyLayerId implements Serializable {

  @Column(name = "POL_NUM")
  private String policyNumber;

  @Column(name = "LAYER_TYP")
  private String type;

  @Column(name = "LAYER_EFF_DT")
  private String effectiveDate;
}
