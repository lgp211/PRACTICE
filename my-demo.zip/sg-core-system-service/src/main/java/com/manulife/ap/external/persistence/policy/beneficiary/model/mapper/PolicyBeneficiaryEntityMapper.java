package com.manulife.ap.external.persistence.policy.beneficiary.model.mapper;

import com.manulife.ap.core.policy.beneficiary.model.PolicyBeneficiary;
import com.manulife.ap.external.persistence.policy.beneficiary.model.PolicyBeneficiaryEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Collection;
import java.util.List;

@Mapper
public interface PolicyBeneficiaryEntityMapper {
  static PolicyBeneficiaryEntityMapper get() {
    return PolicyBeneficiaryEntityMapper.ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final PolicyBeneficiaryEntityMapper INSTANCE = Mappers.getMapper(PolicyBeneficiaryEntityMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "policyNumber", source = "entity.id.policyNumber")
  @Mapping(target = "type.code", source = "entity.id.beneficiaryType")
  @Mapping(target = "code.code", source = "entity.beneficiaryCode")
  @Mapping(target = "name", source = "entity.beneficiaryName")
  @Mapping(target = "party.code", source = "entity.beneficiaryParty")
  @Mapping(target = "percentage", source = "entity.beneficiaryPercentage")
  PolicyBeneficiary toPolicyBeneficiary(PolicyBeneficiaryEntity entity);

  List<PolicyBeneficiary> toPolicyBeneficiaryList(Collection<PolicyBeneficiaryEntity> policyBeneficiaryEntities);
}