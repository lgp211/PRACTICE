package com.manulife.ap.core.policy.transaction.service;

import com.manulife.ap.core.policy.transaction.model.PolicyMonthiversaryCharges;

import java.util.List;
import java.util.Set;

public interface PolicyMonthiversaryChargesRepository {
  List<PolicyMonthiversaryCharges> findAllByPolicyNumberIn(final Set<String> policyNumbers);
}