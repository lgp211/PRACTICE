package com.manulife.ap.core.product.root.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductKey {
  @NotBlank(message = "Plan code is mandatory")
  private String planCode;
  @NotBlank(message = "Plan version is mandatory")
  private String planVersion;
  @NotBlank(message = "Currency code is mandatory")
  private String currencyCode;
}
