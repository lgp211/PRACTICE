package com.manulife.ap.external.persistence.policy.coverage.model.mapper;

import com.manulife.ap.core.policy.coverage.model.ProductPlanKey;
import com.manulife.ap.external.persistence.policy.coverage.model.ProductClaimId;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Set;

@Mapper
public interface ProductPlanKeyMapper {
  static ProductPlanKeyMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final ProductPlanKeyMapper INSTANCE = Mappers.getMapper(ProductPlanKeyMapper.class);

    private ModelMapperInstance() {
    }
  }

  @Mapping(target = "planCode" ,source = "key.planCode")
  @Mapping(target = "planVersion" ,source = "key.planVersion")
  ProductClaimId toProductClaimId(ProductPlanKey key);

  Set<ProductClaimId> toProductClaimIdSet(Set<ProductPlanKey> keys);
}
