package com.manulife.ap.core.policy.root.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyPremium {
  private Double modeAmount;
  private Double planAmount;
  private Double discountAmount;
  private Double suspenseAmount;
  private Double suspensePolicy;
  private PremiumHoliday holiday;
}
