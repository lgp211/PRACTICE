package com.manulife.ap.external.persistence.policy.root.repository;

import com.manulife.ap.external.persistence.policy.root.model.PolicyEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface PolicyEntityRepository
  extends JpaRepository<PolicyEntity, String>, JpaSpecificationExecutor<PolicyEntity> {
}
