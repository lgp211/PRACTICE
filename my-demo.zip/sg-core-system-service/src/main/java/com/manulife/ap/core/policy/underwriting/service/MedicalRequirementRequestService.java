package com.manulife.ap.core.policy.underwriting.service;

import com.manulife.ap.core.policy.underwriting.model.MedicalRequirementRequest;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface MedicalRequirementRequestService {
  Map<String, List<MedicalRequirementRequest>> findAllByPolicyNumbers(Set<String> policyNumbers);
}
