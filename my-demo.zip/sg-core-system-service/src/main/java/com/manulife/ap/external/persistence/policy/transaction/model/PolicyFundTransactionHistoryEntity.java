package com.manulife.ap.external.persistence.policy.transaction.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TFUND_TRXN_HISTORIES")
public class PolicyFundTransactionHistoryEntity {

  @EmbeddedId
  private PolicyFundTransactionHistoryId id;

  @Column(name = "FND_ID")
  private String fundId;

  @Column(name = "FND_VERS")
  private String fundVersion;

  @Column(name = "TRXN_TYP")
  private String transactionType;

  @Column(name = "TRXN_DT")
  private String transactionDate;

  @Column(name = "TRXN_CD")
  private String transactionCode;

  @Column(name = "TRXN_AMT")
  private Double amount;
}
