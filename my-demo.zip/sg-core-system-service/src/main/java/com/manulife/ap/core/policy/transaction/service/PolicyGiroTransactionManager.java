package com.manulife.ap.core.policy.transaction.service;

import com.manulife.ap.core.policy.transaction.model.PolicyGiroTransaction;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
public class PolicyGiroTransactionManager implements PolicyGiroTransactionService {
  private final PolicyGiroTransactionRepository policyGiroTransactionRepository;

  public Map<String, List<PolicyGiroTransaction>> findAllByPolicyNumberIn(final Set<String> policyNumbers) {

    return Optional.ofNullable(policyNumbers)
      .map(list -> policyGiroTransactionRepository.findAllByPolicyNumberIn(list)
        .stream()
        .collect(groupingBy(PolicyGiroTransaction::getPolicyNumber))
      )
      .orElse(Collections.emptyMap());
  }
}