package com.manulife.ap.core.policy.underwriting.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SupplementaryQuestion {
  private String policyNumber;
  private Integer sequenceNumber;
  private String question;
  private String remarks;
  private LocalDate startDate;
  private LocalDate endDate;
  private String requirementStatus;
}
