package com.manulife.ap.external.persistence.agent.root.model.mapper;

import com.manulife.ap.core.agent.root.model.AgentStatus;
import com.manulife.ap.external.persistence.agent.root.model.AgentStatusEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AgentStatusEntityMapper {
  static AgentStatusEntityMapper get() {
    return ModelMapperInstance.INSTANCE;
  }

  final class ModelMapperInstance {
    private static final AgentStatusEntityMapper INSTANCE = Mappers.getMapper(AgentStatusEntityMapper.class);
    private ModelMapperInstance() {}
  }

  @Mapping(target = "code", source = "entity.code")
  @Mapping(target = "description", source = "entity.description")
  AgentStatus toAgentStatus(AgentStatusEntity entity);
}
