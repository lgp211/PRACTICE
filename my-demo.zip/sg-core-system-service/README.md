# Manulife Singapore - Core System APIs

These System APIs provide a means for insulating the data consumers from the complexity or changes to the underlying
systems. Once built, many consumers can access data without any need to know the details of the underlying systems.
These System APIs are find-grained, business process-independent, and highly reusable.

## Domain Scope

- [Policy](https://confluence.ap.manulife.com/display/SCS/Policy+Service)
- [Customer](https://confluence.ap.manulife.com/display/SCS/Customer+Service)
- [Agent](https://confluence.ap.manulife.com/display/SCS/Agent+Service)

## Design Principles

- Data consumers shall not aware of any details of underlying systems that provide data.
- Data consumers shall not be impacted if any changes happen to underlying systems.
- Data consumers shall be shields from any form of technical challenges and chaos of underlying systems.

<br>

## Developer Guide to System APIs

These System APIs are built using [GraphQL](https://graphql.org/), a query language for APIs and a runtime that
fulfilling those queries with domain data.

- Go to [GraphQL Playground](https://github.com/graphql/graphql-playground) to start interact with those available
  System APIs

```
https://${app-domain-url}/playground
```

- To understand more about available domain data in graph data structure, you can browse at

```
https://${app-domain-url}/voyager
```

<br>

## Non-Functional Requirements (NFR)

- Latency:
- Throughput:
- Apdex:
- Memory:
- CPU:
- Load Time:
- Concurrency:

## Build, Test and Deploy

### Build

RSF provides you option to use Kubernetes or Pivotal technologies for service discovery

- To use Pivotal based technology stack, use following dependency

```
    <dependency>
        <groupId>com.manulife.ap</groupId>
        <artifactId>rsf-pivotal</artifactId>
        <version>1.0.0.RC1</version>
        <type>pom</type>
    </dependency>
```

*Compile*

Following is a one-line maven command that embraces shift-left strategy in allowing developer to get a rapid feedback so
that he/she could improve their work quality at early stage of development.

```
mvnw clean verify -DexcludedGroups=integration-test surefire-report:report sonar:sonar 
```

This one-line maven command will accomplish following jobs:

- Run all unit test cases (tagged with `unit-test`)
- Skip all integration test cases (tagged with `integration-test`)
- Run all acceptance test cases (created with [Cucumber](https://www.baeldung.com/cucumber-spring-integration)
  framework)
- Verify with [JaCoCo rules](https://www.eclemma.org/jacoco/trunk/doc/check-mojo.html) (meet minimum code coverage at
  class level)
- [**TODO**] Verify with [Snyk](https://snyk.io/) (find and fix security vulnerabilities in open source libraries)
- Generate JaCoCo report at `${basedir}/target/site/jacoco/index.html`
- Generate Surefire report at `${basedir}/target/site/surefire-report.html`
- Generate Cucumber report at `${basedir}/target/cucumber-reports/cucumber-html-reports/overview-features.html`
- Upload code quality scan result to SonarQube instance for further analysis.

  > Important Notes
  > 1. This command shall finish its jobs within 5 minutes, preferably 2 minutes on average.

*Run locally*

```
# (Spring Boot 2.x or above)
mvnw spring-boot:run -Dspring-boot.run.profiles=local
```

After application started successfully, you can interact with GraphQL API via `http://localhost:8082/playground`

### Deploy to PCF

```
cf push -f manifest-dev.yml
```

<br><br>

## Consuming System APIs

> **Problem Statement**<br>
> API behavior is typically described in documentation pages which list available endpoints, request data structures and expected response data structures, along with sample query and responses.
> <br><br>
> But, documentation written separately do not shield the consumers of the APIs from changes in the API. API producers may need to change the response data structure or rename an endpoint altogether to keep up with business requirements.

### Consumer-Driven Contract (CDC) Testing

_Consumer driven contract testing_ is a type of contract testing that ensures that a provider is compatible with the
expectations that the consumer has of it.

Following are few simple steps to incorporate your test cases into our API:

1. Create Jira task at https://jira.ap.manulife.com/projects/SCS/summary
2. Clone this repository to your local machine
   ```shell
   git clone ssh://git@git.ap.manulife.com:8080/scs/sg-core-system-service.git
   ```
<br>

3. Create your context folder at following path (if not exist yet):
   ```
   ${PROJECT}/src/test/resources/contracts/{DOMAIN}/{YOUR_CONTEXT}

   where DOMAIN = policy, customer, agent, product, fund

   e.g. ${PROJECT}/src/test/resources/contracts/policy/eclaims

   ```
<br>  
 
4. Create your contract using [Spring Cloud Contract DSL](https://docs.spring.io/spring-cloud-contract/docs/current/reference/html/project-features.html#features-graphql) in your context folder.
   ```yaml
     # Sample file at ${PROJECT}/src/test/resources/contracts/policy/samples/ShouldReturnPolicyModelWhenPolicyNumberFound.yml
     name: "Should Return Policy Model When Policy Number Found"
     description: "Should return a policy model when policy number is found."
     request:
       method: "POST"
       url: "/graphql"
       headers:
         Content-Type: "application/json"
       body:
         query: "query queryPolicy($policyNumber: ID!) { policy(policyNumber: $policyNumber) {  policyNumber  } }"
         variables:
           policyNumber: "P001"
         operationName: "queryPolicy"
       matchers:
         headers:
           - key: "Content-Type"
             regex: "application/json.*"
             regexType: "as_string"
     response:
       status: 200
       headers:
         Content-Type: "application/json"
       bodyFromFile: response/ShouldReturnPolicyModelWhenPolicyNumberFound_response.json
       matchers:
         headers:
           - key: "Content-Type"
             regex: "application/json.*"
             regexType: "as_string"
     metadata:
       verifier:
         tool: "graphql"
   ```
<br>  

5. Raise pull request for code review.

## References

1. [System APIs Official Page](https://confluence.ap.manulife.com/display/SCS/System+APIs) 
