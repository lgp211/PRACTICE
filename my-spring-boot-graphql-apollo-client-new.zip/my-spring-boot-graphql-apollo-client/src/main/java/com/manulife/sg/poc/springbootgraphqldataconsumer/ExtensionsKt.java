package com.manulife.sg.poc.springbootgraphqldataconsumer;

import com.apollographql.apollo.ApolloCall;
import com.apollographql.apollo.ApolloCall.Callback;
import com.apollographql.apollo.api.Response;
import com.apollographql.apollo.exception.ApolloException;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
        mv = {1, 5, 1},
        k = 2,
        d1 = {"\u0000\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\"\u0010\u0000\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00030\u00020\u0001\"\u0004\b\u0000\u0010\u0003*\b\u0012\u0004\u0012\u0002H\u00030\u0004¨\u0006\u0005"},
        d2 = {"toCompletableFuture", "Ljava/util/concurrent/CompletableFuture;", "Lcom/apollographql/apollo/api/Response;", "T", "Lcom/apollographql/apollo/ApolloCall;", "my-apollo-client-maven-plugin-tests"}
)
public final class ExtensionsKt {
    @NotNull
    public static final CompletableFuture toCompletableFuture(@NotNull final ApolloCall $this$toCompletableFuture) {
        Intrinsics.checkNotNullParameter($this$toCompletableFuture, "$this$toCompletableFuture");
        final CompletableFuture completableFuture = new CompletableFuture();
        completableFuture.whenComplete((BiConsumer)(new BiConsumer() {
            // $FF: synthetic method
            // $FF: bridge method
            public void accept(Object var1, Object var2) {
                this.accept((Response)var1, (Throwable)var2);
            }

            public final void accept(Response $noName_0, Throwable $noName_1) {
                if (completableFuture.isCancelled()) {
                    $this$toCompletableFuture.cancel();
                }

            }
        }));
        $this$toCompletableFuture.enqueue((Callback)(new Callback() {
            public void onResponse(@NotNull Response response) {
                Intrinsics.checkNotNullParameter(response, "response");
                completableFuture.complete(response);
            }

            public void onFailure(@NotNull ApolloException e) {
                Intrinsics.checkNotNullParameter(e, "e");
                completableFuture.completeExceptionally((Throwable)e);
            }
        }));
        return completableFuture;
    }
}
