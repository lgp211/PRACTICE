package com.manulife.sg.poc.springbootgraphqldataconsumer.resttemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.manulife.sg.poc.springbootgraphqldataconsumer.request.GraphQLQueryPayload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
public class GraphQLRestClient {

  @Autowired
  private RestTemplate restTemplate;

  public ResponseEntity<String> call() throws JsonProcessingException {

    // Step 1: Construct GraphQL request payload
    Map<String, String> variables = new HashMap<>();
    variables.put("policyNumber", "P001");

    GraphQLQueryPayload<String> payload =
        GraphQLQueryPayload.<String>builder()
            .operationName("queryPolicy")
            .variables(variables)
            .query("query queryPolicy($policyNumber: ID!) { policyById(policyNumber: $policyNumber) {  policyNumber status { code description } } }")
            .build();

    System.out.println("******* " + payload.toString());
    System.out.println(new ObjectMapper().writeValueAsString(payload));

    // Step 2: Construct HTTP entity with header and payload
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    //headers.setContentType(MediaType.valueOf("application/graphql"));
    HttpEntity<String> entity = new HttpEntity<>(new ObjectMapper().writeValueAsString(payload), headers);

    /*String query1 = "{\n" +
            "  \"query\": query {\n" +
            "    \"policyById(policyNumber: \"P001\") {\n" +
            "      \"policyNumber\": \n" +
            "        {\n" +
            "          \"code\": \n" +
            "        {\n" +
            "          \"description\"\n" +
            "        }\n" +
            "        }\n" +
            "    }\n" +
            "  }\n" +
            "}";*/

    //OK
    /*String query1 = "{\n" +
            "    policyById(policyNumber: \"P001\"){\n" +
            "      policyNumber\n" +
            "    }\n" +
            "  }";*/

    //OK
    //String query1 = "{"policyById (policyNumber: \"P001\"){"policyNumber"}""}";
    /*String query1 = "{\n" +
            "  \"query\": query {\n" +
            "    \"policyById\"(\"policyNumber\": \"P001\"){\n" +
            "      \"policyNumber\"\n" +
            "    }\n" +
            "    }\n" +
            "  }";*/

    /*String query1 = "{\"query\":\"{\\n  policyById(policyNumber: \\\"P001\\\") {\\n    policyNumber\\n  }\\n}\\n\"}";
    HttpEntity<String> entity = new HttpEntity<>(query1, headers);*/

    // Step 3: Call via RestTemplate
    return restTemplate.exchange(
        "http://localhost:8082/graphql",
        HttpMethod.POST,
        entity,
        String.class);
  }

  @Bean
  public RestTemplate restTemplate() {
    return new RestTemplate();
  }
}
