package com.manulife.sg.poc.springbootgraphqldataconsumer.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GraphQLQueryPayload<T> {
  private String query;
  private String operationName;
  private Map<String, T> variables;
}
