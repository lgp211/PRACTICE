package com.manulife.sg.poc.springbootgraphqldataconsumer.feign;

import com.manulife.sg.poc.springbootgraphqldataconsumer.request.GraphQLQueryPayload;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@FeignClient(name = "GraphQL", url = "http://localhost:8082/")
public interface GraphQLFeignClient {

  @PostMapping(value = "/graphql", produces = "application/json")
  String queryPolicy(GraphQLQueryPayload<String> payload);

  @PostMapping(value = "/graphql", produces = "application/json")
  String queryPolicies(GraphQLQueryPayload<List<String>> payload);
}
