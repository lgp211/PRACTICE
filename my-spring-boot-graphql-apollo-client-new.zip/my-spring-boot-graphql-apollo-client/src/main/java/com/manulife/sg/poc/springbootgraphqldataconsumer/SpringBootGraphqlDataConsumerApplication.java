package com.manulife.sg.poc.springbootgraphqldataconsumer;

import com.apollographql.apollo.ApolloCall;
import com.apollographql.apollo.ApolloClient;
import com.apollographql.apollo.ApolloQueryCall;
import com.apollographql.apollo.api.Response;
import com.apollographql.apollo.exception.ApolloException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.manulife.sg.poc.graphql.client.AgentByIdQuery;
import com.manulife.sg.poc.graphql.client.QueryPolicyQuery;
import com.manulife.sg.poc.springbootgraphqldataconsumer.feign.GraphQLFeignClient;
import com.manulife.sg.poc.springbootgraphqldataconsumer.request.GraphQLQueryPayload;
import com.manulife.sg.poc.springbootgraphqldataconsumer.resttemplate.GraphQLRestClient;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import okhttp3.OkHttpClient;

import java.sql.SQLOutput;
import java.util.*;
import java.util.concurrent.CompletableFuture;

@SpringBootApplication
@RestController
@EnableFeignClients
@Slf4j
public class SpringBootGraphqlDataConsumerApplication extends CompletableFuture {

	@Autowired
	private GraphQLFeignClient graphQLFeignClient;

	@Autowired
	private GraphQLRestClient graphQLRestClient;

	public static void main(String[] args) {
		SpringApplication.run(SpringBootGraphqlDataConsumerApplication.class, args);
	}

	@GetMapping("/resttemplate")
	public String resttemplate() throws JsonProcessingException {
		return graphQLRestClient.call().getBody();
	}

	@GetMapping("/feign/policy")
	public String feignPolicy() {

		Map<String, String> variables = new HashMap<>();
		variables.put("policyNumber", "P001");

		GraphQLQueryPayload<String> payload =
				GraphQLQueryPayload.<String>builder()
						.operationName("queryPolicy")
						.variables(variables)
						//.query("query queryPolicy($policyNumber: ID!) { policyById(policyNumber: $policyNumber) {  policyNumber status { code description } } }")
						.query("query queryPolicy($policyNumber: ID!) { policyById(policyNumber: $policyNumber) {  policyNumber status { code description } currency{ code description } effectiveDate terminationDate sliActivationDate } }")
						.build();

		return graphQLFeignClient.queryPolicy(payload);
	}

	@GetMapping("/feign/policies")
	public String feignPolicies() {

		Map<String, List<String>> variables = new HashMap<>();
		variables.put("policyNumbers", Arrays.asList("P001","P002","P003"));

		/*GraphQLQueryPayload<List<String>> payload =
			GraphQLQueryPayload.<List<String>>builder()
				.operationName("queryPolicies")
				.variables(variables)
				.query("query queryPolicies($policyNumbers: [String!]!) { policies(policyNumbers: $policyNumbers) {  policyNumber status { code description } } }")
				.build();*/

		GraphQLQueryPayload<List<String>> payload =
				GraphQLQueryPayload.<List<String>>builder()
						.operationName("queryPolicies")
						.variables(variables)
						.query("query queryPolicies($policyNumbers: [ID!]!) { policies(policyNumbers: $policyNumbers) {  policyNumber status { code description } } }")
						.build();

		return graphQLFeignClient.queryPolicies(payload);
	}

	@GetMapping("/apollo/agents")
	public String apolloAgents() {
		ApolloClient client =
			ApolloClient.builder()
				.serverUrl("http://localhost:8082/graphql")
				/*.okHttpClient(new OkHttpClient.Builder()
						.build())*/
				.build();

		client.query(new AgentByIdQuery("A001"))
			.enqueue(new ApolloCall.Callback<AgentByIdQuery.Data>() {
				@Override
				public void onResponse(@NotNull Response<AgentByIdQuery.Data> response) {
					log.info("Apollo Response: {}", response);
				}

				@Override
				public void onFailure(@NotNull ApolloException e) {
					log.error("Apollo Exception: {}", e.getMessage());
				}
			});

		return "Success Apollo Client!";
	}

	@GetMapping("/apollo/agent")
	public AgentByIdQuery.Data apolloAgent() {
		ApolloClient client =
				ApolloClient.builder()
						.serverUrl("https://sg-core-system-service-sit-ut16.apps.sea.preview.pcf.manulife.com/graphql")
						.okHttpClient(new OkHttpClient.Builder()
								.build())
						.build();

		final List<AgentByIdQuery.Data> agentList = new ArrayList<>();
		/*ApolloQueryCall var2 = client.query(new AgentByIdQuery("A001"));
		Response res = (Response)ExtensionsKt.toCompletableFuture((ApolloCall) var2).join();*/
		Response res = (Response)ExtensionsKt.toCompletableFuture((ApolloCall) client.query(new AgentByIdQuery("A001"))).join();
		System.out.println("res: " + res);
		System.out.println("res.data(): " + res.data());
		AgentByIdQuery.Data result = (AgentByIdQuery.Data) res.data();
		System.out.println(result.agentById().agentCode());
		System.out.println(result.agentById().name().fullName());

		client.query(new AgentByIdQuery("A001"))
				.enqueue(new ApolloCall.Callback<AgentByIdQuery.Data>() {
					@Override
					public void onResponse(@NotNull Response<AgentByIdQuery.Data> response) {
						agentList.add(response.data());
						//System.out.println("++++agentList: " + agentList);
						//log.info("Apollo Response: {}", response);
					}

					@Override
					public void onFailure(@NotNull ApolloException e) {
						log.error("Apollo Exception: {}", e.getMessage());
					}
				});

		//System.out.println("*****agentList: " + agentList);

		//return "Success Apollo Client!";
		return result;
	}

	@GetMapping("/apollo/policies")
	public String apolloPolicies() {
		ApolloClient client =
				ApolloClient.builder()
						.serverUrl("http://localhost:8082/graphql")
						/*.okHttpClient(new OkHttpClient.Builder()
                                .build())*/
						.build();

		final List<QueryPolicyQuery.Data> agentList = new ArrayList<>();
		/*ApolloQueryCall var2 = client.query(new AgentByIdQuery("A001"));
		Response res = (Response)ExtensionsKt.toCompletableFuture((ApolloCall) var2).join();*/
		Response res = (Response)ExtensionsKt.toCompletableFuture((ApolloCall) client.query(new QueryPolicyQuery("P001"))).join();
		System.out.println("res: " + res);

		client.query(new QueryPolicyQuery("P001"))
				.enqueue(new ApolloCall.Callback<QueryPolicyQuery.Data>() {
					@Override
					public void onResponse(@NotNull Response<QueryPolicyQuery.Data> response) {
						log.info("Apollo Response: {}", response);
					}

					@Override
					public void onFailure(@NotNull ApolloException e) {
						log.error("Apollo Exception: {}", e.getMessage());
					}
				});

		return "Success Apollo Client of Policy!";
	}
}
