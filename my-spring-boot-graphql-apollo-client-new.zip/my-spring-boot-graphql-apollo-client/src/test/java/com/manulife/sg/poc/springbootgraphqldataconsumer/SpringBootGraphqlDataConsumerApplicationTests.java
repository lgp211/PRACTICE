package com.manulife.sg.poc.springbootgraphqldataconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootGraphqlDataConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
