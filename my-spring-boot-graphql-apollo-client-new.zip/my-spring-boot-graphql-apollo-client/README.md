# Spring Boot GraphQL Data Consumer

## Supported GraphQL Clients

- RestTemplate
- Feign Client
- Apollo Client

## How to run

1. Run maven command below to start application
```shell
mvn spring-boot:run
```
2. Open any web browser to trigger API calls:
    - RestTemplate - ```/resttemplate```
    - Feign Client - ```/feign/policy``` or ```/feign/policices```
    - Apollo Client - ```/apollo/agents```

## References

1. https://confluence.ap.manulife.com/display/SISE/How+to+Consume+Data+from+GraphQL+APIs