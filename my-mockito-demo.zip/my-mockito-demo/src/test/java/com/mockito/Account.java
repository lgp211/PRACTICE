package com.mockito;

public class Account {

}
