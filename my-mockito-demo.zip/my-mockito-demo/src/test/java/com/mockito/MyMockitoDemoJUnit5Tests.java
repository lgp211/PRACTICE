package com.mockito;

import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.servlet.http.HttpServletRequest;

import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Matchers.anyString;
import static org.junit.Assert.*;

//@SpringBootTest
//@RunWith(MockitoJUnitRunner.class)
@ExtendWith(MockitoExtension.class)
public class MyMockitoDemoJUnit5Tests {

    /*@Test
    void contextLoads() {
    }*/

    private AccountDao accountDao;
    private HttpServletRequest request;
    private AcountLoginController accountLoginController;

    @BeforeEach
    public void setUp(){
        this.accountDao = Mockito.mock(AccountDao.class);
        this.request = Mockito.mock(HttpServletRequest.class);
        //this.accountLoginController = Mockito.mock(AcountLoginController.class);
        this.accountLoginController = new AcountLoginController(accountDao);
        System.out.println(request);
    }

    @Test
    public void testLoginSuccess(){
        Account account = new Account();
        Mockito.when(request.getParameter("username")).thenReturn("bruce");
        Mockito.when(request.getParameter("password")).thenReturn("password");
        Mockito.when(accountDao.findAccount(anyString(),anyString())).thenReturn(account);

        String result = accountLoginController.login(request);
        System.out.println(result);
        MatcherAssert.assertThat(result, equalTo("/index"));
    }

    @Test
    public void testLoginFailure(){
        Account account = new Account();
        Mockito.when(request.getParameter("username")).thenReturn("bruce");
        Mockito.when(request.getParameter("password")).thenReturn("password");
        Mockito.when(accountDao.findAccount(anyString(),anyString())).thenReturn(null);

        String result = accountLoginController.login(request);
        System.out.println(result);
        MatcherAssert.assertThat(result, equalTo("/login"));
    }

    @Test
    public void testException(){
        Account account = new Account();
        Mockito.when(request.getParameter("username")).thenReturn(null);
        Mockito.when(request.getParameter("password")).thenReturn(null);
        Mockito.when(accountDao.findAccount(anyString(),anyString())).thenReturn(null);

        String result = accountLoginController.login(request);
        System.out.println(result);
        MatcherAssert.assertThat(result, equalTo("/505"));
    }
}
