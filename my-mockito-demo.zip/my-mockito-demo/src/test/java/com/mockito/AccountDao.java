package com.mockito;

public class AccountDao {
    public Account findAccount(String username, String password){
        throw new UnsupportedOperationException();
    }
}
