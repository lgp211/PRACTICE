package com.mockito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyMockitoDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyMockitoDemoApplication.class, args);
    }

}
