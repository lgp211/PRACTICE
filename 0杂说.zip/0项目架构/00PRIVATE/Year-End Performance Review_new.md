# Year-End Performance Review
## Execution Summary
- AKS Training & AKS Demo Building

  Attended the AKS Training Workshop and built up the AKS Demos accordingly. 

- BFF Service Development, Implementation, Testing and Deployment

  Developed the SGFinDex Bff Service according to the requirements.
-  Code review , code quality assurance
-  

## Execution Details

- AKS Training & AKS Demo Building

  - AKS Training

    I have done the of 5-day AKS training workshop and have a deeper understanding of AKS. It helps to save a lot of time when implementing the SGFinDex project.

  - AKS Demo Building

    I have built the AKS demos, pushed to artifactory repository, deployed into AKS and published to APIM. So that I can grasp the whole DevOps workflow for AKS development.

- BFF Service Development, Implementation, Testing and Deployment

  - TDD&BDD

    I applied TDD & BDD methodologies to create proper specifications for how my code should be written and implemented. The code has been optimized by the unit testing, integration testing, etc. Some exceptions and issues(like NullPointerException) also have been fixed by the testing, Optional and Lambda, etc. TDD&BDD help to have better program design and higher code quality so that I have more confident with my design and code. They definitely improved our customer experiences.

  - Agile

    I completed all the Sprint tasks assigned to me. Agile process has been taken well in our SGFinDex project(current overall agile health is 7.28), which is also benefit for my BFF Service implementation, e.g. it gave me more transparency and better understanding of the project so that I can be more efficient and collaborative with our team members. And the iterative process of Agile also helps to increase the flexibility and build knowledge and skillset.

  - GraphQL & Apollo Client

    I learned and grasped the framework of GraphQL and Apollo client and use them to implement the BFF Service. I solved some challenges, such as capturing the Apollo response. It is good fit for our complex microservices project of SGFinDex and can fetch data with a single API call.

  - AKS Dev

    I finished the sprints of AKS development and deployment. I have a better understanding of the advantages of AKS for maintaining kubernetes and APIs. AKS helps to accelerate the app deployment including auto upgrades, patching and self-healing.

