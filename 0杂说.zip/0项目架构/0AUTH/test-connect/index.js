const crypto = require('crypto');
var qs = require('qs');
var fs = require('fs');

console.log('start');
try {
    var req = generateAuthorizationHeader(
        'https://stg.fpdsapim.myinfo.gov.sg/provider/v1/useridentity',
        '',
        'POST',
        '',
        'L2',
        'STG_SGFINDEX_MANULIFE',
        'private_key_uat.pem',
        ''
    );
    console.log('Authorization: ' + req);
} catch(err) {
    console.log('Error: ' + err);
}
console.log('done');

  // generates the security headers for calling API gateway
  function generateAuthorizationHeader(url, params, method, strContentType, authType, appId, keyCertContent, passphrase) {
    if (authType == "L2") {
      return generateRS256Header(url, params, method, strContentType, appId, keyCertContent, passphrase);
    } else {
      return "";
    }
  };

  function nonce() {
    return crypto.randomBytes(16).toString('hex');
  }

  // Signing Your Requests
  function generateRS256Header(url, params, method, strContentType, appId, keyCertContent, keyCertPassphrase) {
    var nonceValue = nonce();
    var timestamp = (new Date).getTime();

    // A) Construct the Authorisation Token Parameters
    var defaultAuthHeaders = {
      "app_id": appId, // App ID assigned to your application
      "nonce": nonceValue, // secure random number
      "signature_method": "RS256",
      "state": "123",
      "timestamp": timestamp // Unix epoch time,
    };
    console.log('defaultAuthHeaders: ' + defaultAuthHeaders);
    console.log('nonce: ' + defaultAuthHeaders.nonce);

    // B) Forming the Base String
    // Base String is a representation of the entire request (ensures message integrity)

    // i) Normalize request parameters
    // var baseParams = sortJSON(_.merge(defaultAuthHeaders, params));

    var baseParamsStr = qs.stringify(defaultAuthHeaders);
    console.log('stringify baseParamsStr: ' + baseParamsStr);
    baseParamsStr = decodeURI(baseParamsStr); // url safe
    console.log('decode baseParamsStr: ' + baseParamsStr);

    // ii) concatenate request elements (HTTP method + url + base string parameters)
    var baseString = method.toUpperCase() + "&" + url + "&" + baseParamsStr;
    console.log('baseString: ' + baseString);

    // C) Signing Base String to get Digital Signature
    var signWith = {
      key: fs.readFileSync(keyCertContent, 'utf8')
    }; // Provides private key

    // Load pem file containing the x509 cert & private key & sign the base string with it to produce the Digital Signature
    var signature = crypto.createSign('RSA-SHA256')
      .update(baseString)
      .sign(signWith, 'base64');

    // D) Assembling the Authorization Header
    var strAuthHeader = "PKI_SIGN app_id=\"" + appId + // Defaults to 1st part of incoming request hostname
      "\",timestamp=\"" + timestamp +
      "\",nonce=\"" + nonceValue +
      "\",signature_method=\"RS256\"" +
      ",signature=\"" + signature +
      "\"";

    return strAuthHeader;
  };
